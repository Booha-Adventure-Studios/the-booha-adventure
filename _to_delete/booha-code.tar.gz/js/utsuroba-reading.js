/*
 * Utsuroba Reading Engine — Pass 4
 *
 * This module owns the reading UI and episode contract. Utsuroba only tells it
 * which drifter/quest is active and what to do when the episode is complete.
 */
(function () {
  let overlay = null;
  let style = null;
  let open = false;
  let closeCallback = null;
  let previousFocus = null;

  /* Pass 4: same motif palette used for orbs (karasuki.js) and the Three
     Echoes tracker (utsuroba.js), reused here so a memory's color identity
     is consistent everywhere a kid sees it. */
  const MOTIF_COLORS = {
    lantern:    { ring: '#ffd966', glow: 'rgba(255,217,102,.5)' },
    candy:      { ring: '#ff85a1', glow: 'rgba(255,133,161,.5)' },
    reflection: { ring: '#a8edff', glow: 'rgba(168,237,255,.5)' },
    window:     { ring: '#8ff0d0', glow: 'rgba(143,240,208,.5)' },
    thorn:      { ring: '#d9503a', glow: 'rgba(217,80,58,.5)' },
    ribbon:     { ring: '#d9a8ff', glow: 'rgba(217,168,255,.5)' },
  };
  const POSTCARD_STAMPS = { lantern: '✦', candy: '●', reflection: '◈', window: '▱', thorn: '✣', ribbon: '❧' };

  /* Round 2 Pass 18: this screen's own instructional chrome (mode badges,
     onboarding, calibration, vocab/postcard/sequence task copy) was hardcoded
     plain Japanese with no furigana at all — unlike the episode content,
     none of these strings are shared/multi-consumer, so it's safe to run
     them straight through the shared sentence() renderer instead of writing
     <ruby> by hand. Falls back to plain text if the helper hasn't loaded. */
  const FURI = (window.UtsuFurigana && window.UtsuFurigana.sentence)
    ? window.UtsuFurigana
    : { sentence: function (value) { return String(value == null ? '' : value); } };

  function escapeText(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function focusFirstControl() {
    if (!overlay) return;
    const controls = Array.from(overlay.querySelectorAll('button:not([disabled])'));
    const control = controls.find(button => {
      const details = button.closest('details');
      return (!details || details.open) && button.getClientRects().length > 0;
    }) || controls[0];
    if (control && typeof control.focus === 'function') requestAnimationFrame(() => control.focus());
  }

  function trapFocus(event) {
    if (event.key !== 'Tab' || !overlay) return;
    const controls = Array.from(overlay.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
      .filter(control => {
        const details = control.closest('details');
        return (!details || details.open) && control.getClientRects().length > 0;
      });
    if (!controls.length) return;
    const first = controls[0];
    const last = controls[controls.length - 1];
    if (!overlay.contains(document.activeElement)) {
      event.preventDefault();
      first.focus();
    } else if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  function installStyle() {
    if (style) return;
    style = document.createElement('style');
    style.textContent = `
      #utsuroba-reading-challenge .reading-card{position:relative;width:min(920px,100%);max-height:calc(100vh - 36px);overflow:auto;background:linear-gradient(160deg,#171020,#0b0712 65%,#130b1b);border:1px solid rgba(220,160,255,.45);border-radius:16px;padding:clamp(20px,3vw,34px);box-shadow:0 0 70px rgba(100,30,160,.34);box-sizing:border-box;}
      #utsuroba-reading-challenge .reading-close{position:absolute;right:14px;top:12px;background:transparent;border:0;color:rgba(255,255,255,.55);font-size:18px;cursor:pointer;padding:8px;}
      #utsuroba-reading-challenge button:focus-visible{outline:3px solid #ffdf9b;outline-offset:3px;}
      #utsuroba-reading-challenge{overscroll-behavior:contain;}
      #utsuroba-reading-challenge .reading-eyebrow{color:#d8a8ff;font:700 11px/1.4 monospace;letter-spacing:.16em;text-transform:uppercase;margin-bottom:8px;}
      #utsuroba-reading-challenge .reading-support-badge{display:inline-block;margin:0 0 9px;padding:4px 8px;border:1px solid rgba(216,168,255,.35);border-radius:999px;color:#e4c2ff;font:700 10px/1.35 monospace;letter-spacing:.06em;}
      #utsuroba-reading-challenge .reading-support-badge.independent{border-color:rgba(255,203,117,.48);color:#ffe0a0;}
      #utsuroba-reading-challenge h2{margin:0 0 8px;color:#fff4ff;font-size:clamp(1.25rem,3vw,2rem);}
      #utsuroba-reading-challenge h2 span{display:block;color:rgba(255,220,255,.58);font-size:.52em;font-weight:400;margin-top:4px;}
      #utsuroba-reading-challenge .reading-header{display:flex;align-items:flex-start;justify-content:space-between;gap:clamp(10px,3vw,20px);}
      #utsuroba-reading-challenge .reading-header-text{flex:1;min-width:0;padding-right:38px;}
      #utsuroba-reading-challenge .reading-portrait{flex-shrink:0;width:clamp(60px,13vw,100px);height:clamp(60px,13vw,100px);margin-top:22px;border-radius:14px;overflow:hidden;background:radial-gradient(circle at 35% 28%,rgba(255,255,255,.14),rgba(0,0,0,.4));border:2px solid var(--portrait-ring,#d8a8ff);box-shadow:0 0 20px var(--portrait-glow,rgba(216,168,255,.4)),inset 0 0 12px rgba(0,0,0,.4);}
      #utsuroba-reading-challenge .reading-portrait img{width:100%;height:100%;object-fit:contain;display:block;filter:drop-shadow(0 2px 6px rgba(0,0,0,.55));}
      #utsuroba-reading-challenge .reading-portrait-hero{width:clamp(84px,18vw,132px);height:clamp(84px,18vw,132px);margin:0 auto 14px;border-radius:18px;overflow:hidden;background:radial-gradient(circle at 35% 28%,rgba(255,255,255,.14),rgba(0,0,0,.4));border:2px solid var(--portrait-ring,#d8a8ff);box-shadow:0 0 28px var(--portrait-glow,rgba(216,168,255,.45)),inset 0 0 14px rgba(0,0,0,.4);}
      #utsuroba-reading-challenge .reading-portrait-hero img{width:100%;height:100%;object-fit:contain;display:block;filter:drop-shadow(0 2px 8px rgba(0,0,0,.55));}
      #utsuroba-reading-challenge .reading-complete .reading-portrait-hero{margin-top:4px;}
      #utsuroba-reading-challenge h3{margin:5px 0 2px;color:#fff;font-size:clamp(1rem,2.3vw,1.25rem);}
      #utsuroba-reading-challenge .reading-intro{margin:0;color:#f5e8ff;line-height:1.5;font-size:clamp(.86rem,1.8vw,1rem);}
      #utsuroba-reading-challenge .reading-jp{margin:2px 0 12px;color:rgba(245,232,255,.6);font-size:.86rem;line-height:1.5;}
      #utsuroba-reading-challenge .reading-vocab{margin:14px 0 18px;border:1px solid rgba(216,168,255,.2);border-radius:9px;background:rgba(255,255,255,.035);}
      #utsuroba-reading-challenge .reading-vocab summary{cursor:pointer;padding:10px 12px;color:#e4c2ff;font-size:.78rem;font-weight:700;list-style-position:inside;}
      #utsuroba-reading-challenge .reading-vocab summary span{display:block;margin:3px 0 0 18px;color:rgba(245,232,255,.56);font-size:.76rem;font-weight:400;}
      #utsuroba-reading-challenge .reading-vocab-body{padding:0 12px 12px;}
      #utsuroba-reading-challenge .reading-vocab-list{display:flex;flex-wrap:wrap;gap:7px;}
      #utsuroba-reading-challenge .reading-vocab-word{padding:6px 9px;border:1px solid rgba(216,168,255,.35);border-radius:999px;background:rgba(216,168,255,.08);color:#fff;cursor:pointer;font:700 .74rem Georgia,serif;}
      #utsuroba-reading-challenge .reading-vocab-word:hover,#utsuroba-reading-challenge .reading-vocab-word:focus-visible{border-color:#d8a8ff;background:rgba(216,168,255,.2);outline:none;}
      #utsuroba-reading-challenge .reading-vocab-detail{min-height:34px;margin-top:10px;padding:8px 10px;border-left:2px solid #ffcb75;background:rgba(255,203,117,.07);color:#ffe7b2;font-size:.78rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-vocab-detail strong{color:#fff;font-size:.86rem;}
      #utsuroba-reading-challenge .reading-vocab-detail small{display:block;margin-top:3px;color:rgba(255,231,178,.65);font-size:.95em;}
      #utsuroba-reading-challenge .reading-transcript{display:grid;gap:8px;margin:18px 0 20px;padding:14px;background:rgba(255,255,255,.045);border:1px solid rgba(220,160,255,.16);border-radius:10px;}
      #utsuroba-reading-challenge .reading-line{padding-left:12px;border-left:2px solid rgba(216,168,255,.45);}
      #utsuroba-reading-challenge .reading-line.is-evidence{border-left-color:#ffcb75;background:rgba(255,203,117,.12);box-shadow:inset 3px 0 0 #ffcb75;padding-top:5px;padding-bottom:5px;border-radius:0 5px 5px 0;animation:readingEvidenceIn .32s ease-out both;}
      #utsuroba-reading-challenge .reading-speaker{color:#d8a8ff;font-size:.74rem;font-weight:700;letter-spacing:.05em;}
      #utsuroba-reading-challenge .reading-en{color:#fff;font-size:.9rem;line-height:1.35;margin-top:2px;}
      #utsuroba-reading-challenge .reading-question-label{color:#ffcb75;font:700 10px/1.4 monospace;letter-spacing:.14em;margin-top:8px;}
      #utsuroba-reading-challenge .reading-choices{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:14px;}
      #utsuroba-reading-challenge .reading-choice{min-height:72px;text-align:left;padding:11px 12px;background:rgba(255,255,255,.06);border:1px solid rgba(220,160,255,.34);border-radius:9px;color:#fff;cursor:pointer;font:inherit;transition:transform .15s,border-color .15s,background .15s;}
      #utsuroba-reading-challenge .reading-choice:hover{transform:translateY(-2px);background:rgba(216,168,255,.14);border-color:#d8a8ff;}
      #utsuroba-reading-challenge .reading-choice small{display:block;color:rgba(255,255,255,.48);font-size:.72rem;line-height:1.35;margin-top:5px;}
      #utsuroba-reading-challenge .reading-interaction{margin-top:14px;padding:12px;border:1px solid rgba(255,203,117,.24);border-radius:10px;background:rgba(255,203,117,.045);}
      #utsuroba-reading-challenge .reading-interaction-instruction{margin:0 0 10px;color:#ffe0a0;font-size:.78rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-interaction-instruction small{display:block;margin-top:3px;color:rgba(255,231,178,.58);font-size:.95em;}
      #utsuroba-reading-challenge .reading-sequence-picked{min-height:34px;margin-bottom:10px;padding:7px 9px;border-radius:7px;background:rgba(0,0,0,.2);color:rgba(255,255,255,.62);font-size:.75rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-sequence-picked strong{color:#fff0c9;}
      #utsuroba-reading-challenge .reading-sequence-options{display:grid;gap:7px;}
      #utsuroba-reading-challenge .reading-task-choice,#utsuroba-reading-challenge .reading-line-choice{width:100%;text-align:left;padding:9px 10px;border:1px solid rgba(216,168,255,.32);border-radius:7px;background:rgba(255,255,255,.055);color:#fff;cursor:pointer;font:inherit;line-height:1.35;transition:background .15s,border-color .15s,transform .15s;}
      #utsuroba-reading-challenge .reading-task-choice:hover,#utsuroba-reading-challenge .reading-line-choice:hover{background:rgba(216,168,255,.14);border-color:#d8a8ff;transform:translateX(2px);}
      #utsuroba-reading-challenge .reading-task-choice small{display:block;margin-top:3px;color:rgba(255,255,255,.48);font-size:.72rem;}
      #utsuroba-reading-challenge .reading-line-choice{display:block;margin-top:7px;border-left:3px solid rgba(216,168,255,.5);}
      #utsuroba-reading-challenge .reading-line-choice .line-speaker{display:block;color:#d8a8ff;font-size:.7rem;font-weight:700;letter-spacing:.04em;}
      #utsuroba-reading-challenge .reading-line-choice .line-text{display:block;margin-top:2px;color:#fff;font-size:.82rem;}
      #utsuroba-reading-challenge .reading-sequence-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;}
      #utsuroba-reading-challenge .reading-task-action{padding:7px 11px;border:1px solid rgba(216,168,255,.4);border-radius:6px;background:rgba(216,168,255,.08);color:#f3ddff;cursor:pointer;font:700 .72rem Georgia,serif;}
      #utsuroba-reading-challenge .reading-task-action.primary{border-color:#ffcb75;background:rgba(255,203,117,.12);color:#ffe7b2;}
      #utsuroba-reading-challenge .reading-task-action:hover,#utsuroba-reading-challenge .reading-task-action:focus-visible{background:rgba(216,168,255,.2);outline:none;}
      #utsuroba-reading-challenge .reading-task-action.primary:hover{background:rgba(255,203,117,.22);}
      #utsuroba-reading-challenge .reading-picked-answer{margin:0 0 10px;padding:8px 10px;border-left:3px solid #ffcb75;background:rgba(255,203,117,.08);color:#ffe7b2;font-size:.8rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-picked-answer small{display:block;margin-top:3px;color:rgba(255,231,178,.58);font-size:.9em;}
      #utsuroba-reading-challenge .reading-feedback{margin-top:12px;padding:10px 12px;border-left:3px solid #ffcb75;background:rgba(255,203,117,.08);color:#ffe7b2;font-size:.82rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-feedback small{display:block;color:rgba(255,231,178,.68);margin-top:3px;font-size:.95em;}
      #utsuroba-reading-challenge .reading-evidence-btn{display:block;margin-top:8px;padding:6px 10px;border:1px solid rgba(255,203,117,.48);border-radius:6px;background:rgba(255,203,117,.08);color:#ffe7b2;cursor:pointer;font:700 .72rem Georgia,serif;}
      #utsuroba-reading-challenge .reading-evidence-btn:hover,#utsuroba-reading-challenge .reading-evidence-btn:focus-visible{background:rgba(255,203,117,.18);outline:none;}
      #utsuroba-reading-challenge ruby{ruby-position:over;line-height:1.45;}
      #utsuroba-reading-challenge ruby rt{font-size:clamp(11px,.82em,15px);opacity:.95;}
      #utsuroba-reading-challenge .reading-progress{position:relative;margin-top:14px;padding:8px 9px 7px;text-align:right;color:rgba(255,255,255,.66);font:700 11px monospace;border:1px solid rgba(255,203,117,.2);border-radius:8px;background:rgba(255,203,117,.045);overflow:hidden;}
      #utsuroba-reading-challenge .reading-progress::before{content:'✦';position:absolute;left:9px;top:7px;color:#ffcb75;text-shadow:0 0 10px rgba(255,203,117,.8);animation:readingStarPulse 1.8s ease-in-out infinite;}
      #utsuroba-reading-challenge .reading-progress-top{position:relative;z-index:1;}
      #utsuroba-reading-challenge .reading-progress small{display:block;margin-top:3px;color:rgba(255,231,178,.68);font-size:.98em;font-weight:400;}
      #utsuroba-reading-challenge .reading-progress-track{position:relative;height:4px;margin-top:7px;border-radius:9px;background:rgba(255,255,255,.12);overflow:hidden;}
      #utsuroba-reading-challenge .reading-progress-fill{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#9f69cb,#ffcb75);box-shadow:0 0 12px rgba(255,203,117,.6);transition:width .35s ease;}
      @keyframes readingStarPulse{0%,100%{opacity:.65;transform:scale(.85)}50%{opacity:1;transform:scale(1.15)}}
      #utsuroba-reading-challenge .reading-mechanic{margin:18px 0 20px;padding:13px 14px 15px;background:rgba(255,255,255,.035);border:1px solid rgba(255,203,117,.22);border-radius:12px;}
      #utsuroba-reading-challenge .reading-mechanic-heading{display:flex;justify-content:space-between;gap:12px;color:#ffdf9b;font:700 10px/1.4 monospace;letter-spacing:.14em;text-transform:uppercase;}
      #utsuroba-reading-challenge .reading-mechanic-heading span{color:rgba(255,223,155,.58);font-weight:400;letter-spacing:.04em;text-transform:none;}
      #utsuroba-reading-challenge .reading-mechanic-intro{margin:6px 0 2px;color:#fff4d7;font-size:.8rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-mechanic-intro-jp{margin:0;color:rgba(255,231,178,.6);font-size:.78rem;line-height:1.45;}
      #utsuroba-reading-challenge .reading-theatre-stage,#utsuroba-reading-challenge .reading-mechanic-board{position:relative;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:13px;padding:12px 8px 8px;overflow:hidden;border:1px solid rgba(216,168,255,.18);border-radius:9px;background:radial-gradient(circle at 50% 0%,rgba(255,213,111,.18),transparent 42%),linear-gradient(180deg,#211832,#0d0916);}
      #utsuroba-reading-challenge .reading-mechanic-evidence-board{background:linear-gradient(160deg,rgba(102,179,255,.12),transparent 45%),linear-gradient(180deg,#152238,#0b1019);}
      #utsuroba-reading-challenge .reading-mechanic-emotion-thread{background:linear-gradient(160deg,rgba(255,145,175,.13),transparent 45%),linear-gradient(180deg,#281a2b,#100c16);}
      #utsuroba-reading-challenge .reading-theatre-stage::before{content:"";position:absolute;left:50%;top:0;width:2px;height:100%;background:linear-gradient(180deg,rgba(255,223,155,.55),transparent 70%);box-shadow:0 0 22px 9px rgba(255,203,117,.09);transform:translateX(-50%);pointer-events:none;}
      #utsuroba-reading-challenge .reading-theatre-act{position:relative;z-index:1;min-height:92px;padding:10px 8px;border:1px solid rgba(255,255,255,.1);border-radius:7px;background-color:rgba(0,0,0,.22);background-size:cover;background-position:center;opacity:.48;transition:all .28s ease;box-sizing:border-box;}
      #utsuroba-reading-challenge .reading-theatre-act .act-title,#utsuroba-reading-challenge .reading-theatre-act .act-caption{text-shadow:0 1px 4px rgba(0,0,0,.7);}
      #utsuroba-reading-challenge .reading-theatre-act.is-current{opacity:1;border-color:rgba(255,203,117,.72);background:rgba(255,203,117,.1);box-shadow:0 0 18px rgba(255,203,117,.12);animation:readingActPulse 1.8s ease-in-out infinite;}
      #utsuroba-reading-challenge .reading-theatre-act.is-restored{opacity:1;border-color:rgba(216,168,255,.62);background:rgba(216,168,255,.1);}
      #utsuroba-reading-challenge .reading-theatre-act.is-restored::after{content:"✓";position:absolute;right:7px;top:5px;color:#ffe39c;font-weight:700;}
      #utsuroba-reading-challenge .reading-theatre-act .act-number{color:#ffcb75;font:700 .68rem monospace;letter-spacing:.1em;}
      #utsuroba-reading-challenge .reading-theatre-act .act-title{display:block;margin-top:7px;color:#fff;font-size:.78rem;line-height:1.25;}
      #utsuroba-reading-challenge .reading-theatre-act .act-title-jp{display:block;margin-top:4px;color:rgba(255,231,178,.62);font-size:.75rem;line-height:1.35;}
      #utsuroba-reading-challenge .reading-theatre-act .act-caption{display:block;margin-top:8px;color:rgba(255,255,255,.76);font-size:.68rem;line-height:1.3;}
      #utsuroba-reading-challenge .reading-theatre-act .act-caption-jp{display:block;margin-top:3px;color:rgba(255,231,178,.52);font-size:.7rem;line-height:1.35;}
      #utsuroba-reading-challenge .reading-theatre-locked{margin:8px 0 0;color:rgba(255,255,255,.34);font-size:.67rem;line-height:1.3;}
      #utsuroba-reading-challenge .reading-theatre-status{margin:8px 0 0;text-align:center;color:#ffdf9b;font-size:.72rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-theatre-status small{display:block;color:rgba(255,231,178,.58);font-size:.95em;}
      @keyframes readingActPulse{0%,100%{transform:translateY(0)}50%{transform:translateY(-2px)}}
      @keyframes readingEvidenceIn{from{opacity:.45;transform:translateX(-4px)}to{opacity:1;transform:translateX(0)}}
      #utsuroba-reading-challenge .reading-complete{text-align:center;padding:clamp(36px,8vw,82px) clamp(20px,6vw,80px);}
      #utsuroba-reading-challenge .reading-success{color:#ffe8a8;font-size:clamp(1rem,2.5vw,1.35rem);line-height:1.5;margin:22px auto 4px;max-width:650px;}
      #utsuroba-reading-challenge .reading-primary{margin-top:24px;padding:12px 24px;border:1px solid #ffcb75;border-radius:8px;background:linear-gradient(135deg,#ffe7a8,#c78b31);color:#241507;font:700 .9rem Georgia,serif;cursor:pointer;}
      #utsuroba-reading-challenge .reading-secondary{margin-top:24px;padding:11px 20px;border:1px solid rgba(216,168,255,.55);border-radius:8px;background:rgba(216,168,255,.08);color:#f3ddff;font:700 .86rem Georgia,serif;cursor:pointer;}
      #utsuroba-reading-challenge .reading-secondary:hover{background:rgba(216,168,255,.18);border-color:#d8a8ff;}
      #utsuroba-reading-challenge .reading-complete-actions{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;}
      #utsuroba-reading-challenge .reading-postcard{position:relative;isolation:isolate;margin:18px 0;padding:15px;text-align:left;border:1px solid var(--postcard-ring,rgba(216,168,255,.28));border-left:3px solid var(--postcard-ring,rgba(216,168,255,.5));border-radius:10px;background:linear-gradient(145deg,rgba(255,252,242,.1),rgba(255,255,255,.025)),repeating-linear-gradient(0deg,rgba(255,255,255,.025) 0 1px,transparent 1px 4px);box-shadow:0 0 22px var(--postcard-glow,rgba(216,168,255,.12));overflow:hidden;}
      #utsuroba-reading-challenge .reading-postcard::before{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;background:radial-gradient(circle at 90% 12%,var(--postcard-glow,rgba(216,168,255,.16)),transparent 32%),linear-gradient(120deg,transparent 0 68%,rgba(255,255,255,.035) 68% 69%,transparent 69%);opacity:.9;}
      #utsuroba-reading-challenge .reading-postcard-stamp{position:absolute;top:10px;right:12px;display:grid;place-items:center;width:28px;height:28px;border:1px dashed var(--postcard-ring,#d8a8ff);border-radius:5px;color:var(--postcard-ring,#d8a8ff);font:700 1rem Georgia,serif;transform:rotate(7deg);opacity:.86;box-shadow:inset 0 0 0 2px rgba(255,255,255,.035);}
      #utsuroba-reading-challenge .reading-postcard-heading{padding-right:42px;color:var(--postcard-ring,#e4c2ff);font:700 .78rem Georgia,serif;}
      #utsuroba-reading-challenge .reading-postcard-heading span{display:block;margin-top:3px;color:rgba(245,232,255,.5);font-size:.88em;font-weight:400;}
      #utsuroba-reading-challenge .reading-postcard-instruction{margin:8px 0;color:rgba(245,232,255,.7);font-size:.8rem;line-height:1.45;}
      #utsuroba-reading-challenge .reading-postcard-instruction small{display:block;margin-top:3px;color:rgba(245,232,255,.54);font-size:.95em;}
      #utsuroba-reading-challenge .reading-postcard-picked{min-height:34px;margin-bottom:9px;padding:7px 9px;border-radius:7px;background:rgba(0,0,0,.2);color:rgba(255,255,255,.68);font-size:.74rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-postcard-option{display:block;width:100%;margin-top:7px;padding:8px 9px;text-align:left;border:1px solid var(--postcard-ring,#d8a8ff);border-radius:6px;background:rgba(255,255,255,.05);color:#fff;cursor:pointer;font:inherit;font-size:.75rem;line-height:1.35;}
      #utsuroba-reading-challenge .reading-postcard-option:hover,#utsuroba-reading-challenge .reading-postcard-option:focus-visible{background:rgba(255,255,255,.12);border-color:var(--postcard-ring,#d8a8ff);outline:none;}
      #utsuroba-reading-challenge .reading-postcard-option small{display:block;margin-top:3px;color:rgba(255,255,255,.48);font-size:.9em;}
      #utsuroba-reading-challenge .reading-postcard-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:9px;}
      #utsuroba-reading-challenge .reading-postcard-save{padding:7px 11px;border:1px solid #ffcb75;border-radius:6px;background:rgba(255,203,117,.12);color:#ffe7b2;cursor:pointer;font:700 .72rem Georgia,serif;}
      #utsuroba-reading-challenge .reading-postcard-save:hover,#utsuroba-reading-challenge .reading-postcard-save:focus-visible{background:rgba(255,203,117,.22);outline:none;}
      #utsuroba-reading-challenge .reading-postcard-success{padding:8px 9px;border-left:3px solid var(--postcard-ring,#ffcb75);color:#ffe7b2;font-size:.76rem;line-height:1.45;}
      #utsuroba-reading-challenge .reading-postcard-success small{display:block;margin-top:3px;color:rgba(255,231,178,.58);font-size:.9em;}
      #utsuroba-reading-challenge .reading-review-note{margin:14px auto 0;color:rgba(245,232,255,.48);font-size:.72rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-lens{margin:18px 0 0;padding:13px;text-align:left;border:1px solid rgba(216,168,255,.24);border-radius:10px;background:rgba(216,168,255,.045);}
      #utsuroba-reading-challenge .reading-lens-heading{margin:0;color:#e4c2ff;font:700 .78rem Georgia,serif;line-height:1.4;}
      #utsuroba-reading-challenge .reading-lens-heading small{display:block;margin-top:3px;color:rgba(245,232,255,.58);font-size:.95em;font-weight:400;}
      #utsuroba-reading-challenge .reading-lens-options{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-top:10px;}
      #utsuroba-reading-challenge .reading-lens-option{padding:8px 9px;text-align:left;border:1px solid rgba(216,168,255,.3);border-radius:7px;background:rgba(255,255,255,.05);color:#fff;cursor:pointer;font:700 .7rem Georgia,serif;line-height:1.3;}
      #utsuroba-reading-challenge .reading-lens-option:hover,#utsuroba-reading-challenge .reading-lens-option:focus-visible{background:rgba(216,168,255,.14);border-color:#d8a8ff;outline:none;}
      #utsuroba-reading-challenge .reading-lens-option small{display:block;margin-top:3px;color:rgba(255,255,255,.56);font-size:.95em;font-weight:400;}
      #utsuroba-reading-challenge .reading-onboarding{text-align:left;padding:clamp(24px,5vw,46px);}
      #utsuroba-reading-challenge .reading-onboarding-intro{margin:0 0 18px;color:#f5e8ff;font-size:.9rem;line-height:1.5;}
      #utsuroba-reading-challenge .reading-onboarding-intro small{display:block;margin-top:3px;color:rgba(245,232,255,.6);font-size:.92em;}
      #utsuroba-reading-challenge .reading-onboarding-steps{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;margin:0 0 20px;}
      #utsuroba-reading-challenge .reading-onboarding-step{padding:11px 10px;border:1px solid rgba(216,168,255,.24);border-radius:9px;background:rgba(255,255,255,.045);}
      #utsuroba-reading-challenge .reading-onboarding-step b{display:block;color:#ffcb75;font:700 .7rem monospace;letter-spacing:.1em;}
      #utsuroba-reading-challenge .reading-onboarding-step strong{display:block;margin-top:6px;color:#fff;font-size:.76rem;line-height:1.3;}
      #utsuroba-reading-challenge .reading-onboarding-step small{display:block;margin-top:4px;color:rgba(255,231,178,.62);font-size:.76rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-calibration{padding:13px;border:1px solid rgba(255,203,117,.27);border-radius:10px;background:rgba(255,203,117,.045);}
      #utsuroba-reading-challenge .reading-calibration-heading{margin:0;color:#ffe0a0;font-size:.8rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-calibration-heading small{display:block;margin-top:3px;color:rgba(255,231,178,.62);font-size:.95em;}
      #utsuroba-reading-challenge .reading-calibration-options{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:11px;}
      #utsuroba-reading-challenge .reading-calibration-option{min-height:78px;padding:10px;text-align:left;border:1px solid rgba(216,168,255,.34);border-radius:8px;background:rgba(255,255,255,.055);color:#fff;cursor:pointer;font:inherit;line-height:1.35;}
      #utsuroba-reading-challenge .reading-calibration-option:hover,#utsuroba-reading-challenge .reading-calibration-option:focus-visible{background:rgba(216,168,255,.15);border-color:#d8a8ff;outline:none;}
      #utsuroba-reading-challenge .reading-calibration-option strong{display:block;color:#fff0c9;font-size:.8rem;}
      #utsuroba-reading-challenge .reading-calibration-option small{display:block;margin-top:5px;color:rgba(255,255,255,.6);font-size:.8rem;line-height:1.4;}
      #utsuroba-reading-challenge .reading-onboarding-note{margin:13px 0 0;color:rgba(245,232,255,.56);font-size:.78rem;line-height:1.45;}
      #utsuroba-reading-challenge .reading-loading{text-align:center;padding:80px 24px;color:#f1dcff;}
      @media(max-width:700px){#utsuroba-reading-challenge{padding:10px;}#utsuroba-reading-challenge .reading-choices{grid-template-columns:1fr;}#utsuroba-reading-challenge .reading-onboarding-steps,.reading-calibration-options,.reading-lens-options{grid-template-columns:1fr;}#utsuroba-reading-challenge .reading-card{max-height:calc(100vh - 20px);padding:20px 16px;}#utsuroba-reading-challenge .reading-close{min-width:44px;min-height:44px;}#utsuroba-reading-challenge .reading-header{flex-direction:row-reverse;}#utsuroba-reading-challenge .reading-header-text{padding-right:0;}#utsuroba-reading-challenge .reading-portrait{width:52px;height:52px;margin-top:24px;}}
      @media(max-height:520px) and (orientation:landscape){#utsuroba-reading-challenge{align-items:flex-start;padding:8px;}#utsuroba-reading-challenge .reading-card{max-height:calc(100vh - 16px);padding:16px 18px;}}
      @media(prefers-reduced-motion:reduce){#utsuroba-reading-challenge *,#utsuroba-reading-challenge *::before,#utsuroba-reading-challenge *::after{animation-duration:.01ms !important;animation-iteration-count:1 !important;scroll-behavior:auto !important;transition-duration:.01ms !important;}}
    `;
    document.head.appendChild(style);
  }

  function close() {
    const callback = closeCallback;
    closeCallback = null;
    open = false;
    if (overlay) overlay.remove();
    if (style) style.remove();
    overlay = null;
    style = null;
    if (callback) callback();
    if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus();
    previousFocus = null;
  }

  async function start(options) {
    const opts = options || {};
    if (open) close();
    previousFocus = document.activeElement;
    closeCallback = typeof opts.onClose === 'function' ? opts.onClose : null;
    open = true;
    installStyle();

    overlay = document.createElement('div');
    overlay.id = 'utsuroba-reading-challenge';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', 'Reading memory');
    overlay.tabIndex = -1;
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9600;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(4,0,12,.90);font-family:Georgia,serif;color:#f7f2e8;';
    overlay.innerHTML = `<div class="reading-card reading-loading">Opening the memory…<br><span>${FURI.sentence('記憶を開いています…', { '記憶': 'きおく', '開': 'ひら' })}</span></div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('keydown', event => {
      if (event.key === 'Escape') { event.preventDefault(); close(); return; }
      trapFocus(event);
    });

    let episode;
    try {
      await window.UTSUROBA_EPISODES_READY;
      episode = window.UTSUROBA_EPISODES_RESOLVE
        ? window.UTSUROBA_EPISODES_RESOLVE(opts.quest && opts.quest.episodeId, opts.quest && opts.quest.readingDifficulty)
        : window.UTSUROBA_EPISODES[opts.quest && opts.quest.episodeId];
      if (!episode) throw new Error(`Unknown episode: ${opts.quest && opts.quest.episodeId}`);
    } catch (error) {
      console.error('[Utsuroba Reading] Could not open episode:', error);
      overlay.innerHTML = `<div class="reading-card reading-loading">This memory is cloudy. Please try again.<br><span>${FURI.sentence('記憶がぼやけています。もう一度試してください。', { '記憶': 'きおく', '試': 'ため' })}</span><br><button class="reading-primary" id="reading-error-close">Close / ${FURI.sentence('閉じる', { '閉': 'と' })}</button></div>`;
      overlay.querySelector('#reading-error-close').addEventListener('click', close);
      focusFirstControl();
      return false;
    }

    const replayLens = opts.reviewLens && episode.replayLenses?.[opts.reviewLens]
      ? episode.replayLenses[opts.reviewLens] : null;
    const questions = replayLens ? [replayLens] : episode.checks;
    let questionIndex = replayLens ? 0 : (Number.isInteger(opts.quest && opts.quest.readingIndex)
      ? opts.quest.readingIndex : 0);
    const mechanic = episode.mechanic || null;
    let mechanicIndex = mechanic && Number.isInteger(opts.quest && opts.quest.mechanicIndex)
      ? opts.quest.mechanicIndex
      : (mechanic && Number.isInteger(opts.quest && opts.quest.theatreIndex)
        ? opts.quest.theatreIndex : questionIndex);
    let lastFeedback = '';
    let lastFeedbackJP = '';
    let showEvidence = false;
    let sequenceSelection = [];
    let inferenceAnswerChosen = false;
    let supportLevel = opts.adaptiveMode === 'independent' ? 'independent' : 'guided';
    const onboardingState = opts.onboarding || {};
    const needsOnboarding = !opts.reviewOnly && !opts.skipOnboarding && onboardingState.seen !== true;
    let mistakeCount = 0;
    let usedEvidence = false;
    let postcardOpen = false;
    let postcardSelection = [];
    let postcardBuilt = false;
    let postcardSaved = !!(opts.quest && opts.quest.postcard && opts.quest.postcard.text);
    let postcardFeedback = '';

    function reviewModeLabel() {
      if (replayLens) return `${replayLens.label} / ${replayLens.labelJP}`;
      if (supportLevel === 'independent') return `ON YOUR OWN / ${FURI.sentence('自力復習', { '自力': 'じりき', '復習': 'ふくしゅう' })}`;
      return `WITH HELP / ${FURI.sentence('案内付き復習', { '案内': 'あんない', '付き': 'つき', '復習': 'ふくしゅう' })}`;
    }

    function renderLensReplay() {
      if (!opts.reviewOnly || replayLens || !episode.replayLenses) return '';
      return `<section class="reading-lens"><p class="reading-lens-heading">Choose how to read it again.<small>${FURI.sentence('読み返す視点を選びましょう。', { '読み返す': 'よみかえす', '視点': 'してん', '選びましょう': 'えらびましょう' })}</small></p><div class="reading-lens-options"><button class="reading-lens-option" type="button" data-reading-lens="detail">Find the Detail<small>${FURI.sentence('細部ハント', { '細部': 'さいぶ' })}</small></button><button class="reading-lens-option" type="button" data-reading-lens="emotion">Find the Feeling<small>${FURI.sentence('気持ちハント', { '気持ち': 'きもち' })}</small></button><button class="reading-lens-option" type="button" data-reading-lens="inference">Guess Why<small>${FURI.sentence('推測ハント', { '推測': 'すいそく' })}</small></button></div></section>`;
    }

    function startLensReplay(lens) {
      if (!episode.replayLenses?.[lens]) return;
      if (typeof opts.onReadingEvent === 'function') opts.onReadingEvent('lens');
      start({
        ...opts,
        reviewLens: lens,
        skipOnboarding: true,
        quest: { ...(opts.quest || {}), readingIndex: 0, mechanicIndex: 0 }
      });
    }

    function renderOnboarding() {
      overlay.innerHTML = `
        <div class="reading-card reading-onboarding">
          <button class="reading-close" id="reading-onboarding-close" type="button" aria-label="Close reading guide">✕</button>
          <div class="reading-header">
            <div class="reading-header-text">
              <div class="reading-eyebrow">READING MAP / ${FURI.sentence('読み方', { '読み方': 'よみかた' })}</div>
              <h2>How to read a memory <span>${FURI.sentence('記憶の読み方', { '記憶': 'きおく', '読み方': 'よみかた' })}</span></h2>
              <p class="reading-onboarding-intro">Read the English lines, use help when you need it, and choose answers from the evidence.<small>${FURI.sentence('英語の文を読み、必要なときにヘルプを使い、手がかりから答えを選びます。', { '英語': 'えいご', '文': 'ぶん', '読み': 'よみ', '必要': 'ひつよう', '使い': 'つかい', '手がかり': 'てがかり', '答え': 'こたえ', '選びます': 'えらびます' })}</small></p>
            </div>
            ${renderPortrait('inline')}
          </div>
          <div class="reading-onboarding-steps">
            <article class="reading-onboarding-step"><b>STEP 1</b><strong>Read the lines.</strong><small>${FURI.sentence('文を読みます。', { '文': 'ぶん', '読みます': 'よみます' })}</small></article>
            <article class="reading-onboarding-step"><b>STEP 2</b><strong>Notice the details.</strong><small>${FURI.sentence('細かい点に気づきます。', { '細かい': 'こまかい', '点': 'てん', '気づきます': 'きづきます' })}</small></article>
            <article class="reading-onboarding-step"><b>STEP 3</b><strong>Show your evidence.</strong><small>${FURI.sentence('証拠を示します。', { '証拠': 'しょうこ', '示します': 'しめします' })}</small></article>
          </div>
          <section class="reading-calibration">
            <p class="reading-calibration-heading">Choose your first reading style.<small>${FURI.sentence('最初の読み方を選びましょう。', { '最初': 'さいしょ', '読み方': 'よみかた', '選びましょう': 'えらびましょう' })}</small></p>
            <div class="reading-calibration-options">
              <button class="reading-calibration-option" type="button" data-reading-calibration="guided"><strong>Guided</strong><small>Show evidence after a mistake. Good when you want support.<br>${FURI.sentence('間違えたら証拠を見ます。サポートがほしい人向けです。', { '間違えたら': 'まちがえたら', '証拠': 'しょうこ', '見ます': 'みます', '人向け': 'ひとむけ' })}</small></button>
              <button class="reading-calibration-option" type="button" data-reading-calibration="independent"><strong>Try first</strong><small>Try without evidence at first. Good when you want a challenge.<br>${FURI.sentence('最初は証拠を見ずに挑戦します。挑戦したい人向けです。', { '最初': 'さいしょ', '証拠': 'しょうこ', '見ずに': 'みずに', '挑戦': 'ちょうせん', '人向け': 'ひとむけ' })}</small></button>
            </div>
          </section>
          <p class="reading-onboarding-note">You can still ask for evidence after two mistakes.<br>${FURI.sentence('二回間違えたら、証拠を見ることができます。', { '二回': 'にかい', '間違えたら': 'まちがえたら', '証拠': 'しょうこ', '見る': 'みる' })}</p>
        </div>`;
      overlay.querySelector('#reading-onboarding-close').addEventListener('click', close);
      overlay.querySelectorAll('[data-reading-calibration]').forEach(button => button.addEventListener('click', () => {
        supportLevel = button.dataset.readingCalibration === 'independent' ? 'independent' : 'guided';
        if (typeof opts.persistOnboarding === 'function') {
          opts.persistOnboarding({ seen: true, calibration: supportLevel });
        }
        render();
      }));
      focusFirstControl();
    }

    function renderPortrait(variant) {
      const drifter = opts.drifter;
      const src = drifter && (drifter.sprite2 || drifter.sprite1);
      if (!src) return '';
      const motif = episode.worldEcho && episode.worldEcho.motif;
      const colors = MOTIF_COLORS[motif] || { ring: '#d8a8ff', glow: 'rgba(216,168,255,.4)' };
      const className = variant === 'hero' ? 'reading-portrait-hero' : 'reading-portrait';
      return `<div class="${className}" style="--portrait-ring:${colors.ring};--portrait-glow:${colors.glow}"><img src="${escapeText(src)}" alt="${escapeText(drifter.name || '')}"></div>`;
    }

    function sceneImageFor(index) {
      const trailEntry = Array.isArray(episode.trail) ? episode.trail[index] : null;
      const roomId = trailEntry && trailEntry.roomId;
      const rooms = window.UTSUROBA_DATA && window.UTSUROBA_DATA.rooms;
      const room = roomId && rooms ? rooms[roomId] : null;
      return room && room.bg ? room.bg : null;
    }

    function renderVocabulary() {
      if (!Array.isArray(episode.vocabulary) || !episode.vocabulary.length) return '';
      const words = episode.vocabulary.map((item, index) => `
        <button class="reading-vocab-word" type="button" data-vocab="${index}">${escapeText(item.word)}</button>`).join('');
      const summary = supportLevel === 'independent'
        ? `Word help is optional. Try to remember first. / ${FURI.sentence('まず思い出してから、言葉のヘルプを使いましょう。', { '思い出して': 'おもいだして', '言葉': 'ことば', '使いましょう': 'つかいましょう' })}`
        : `Tap a word for a simple meaning. / ${FURI.sentence('言葉をタップすると意味が出ます。', { '言葉': 'ことば', '意味': 'いみ', '出ます': 'でます' })}`;
      return `
        <details class="reading-vocab" id="reading-vocabulary">
          <summary>Word help / ${FURI.sentence('言葉のヘルプ', { '言葉': 'ことば' })}<span>${summary}</span></summary>
          <div class="reading-vocab-body">
            <div class="reading-vocab-list">${words}</div>
            <div class="reading-vocab-detail" id="reading-vocab-detail">Choose a word to see help.<small>${FURI.sentence('言葉を一つ選んでください。', { '言葉': 'ことば', '一つ': 'ひとつ', '選んで': 'えらんで' })}</small></div>
          </div>
        </details>`;
    }

    function bindVocabulary() {
      const vocabulary = overlay.querySelector('#reading-vocabulary');
      if (!vocabulary || !Array.isArray(episode.vocabulary)) return;
      const detail = vocabulary.querySelector('#reading-vocab-detail');
      vocabulary.querySelectorAll('[data-vocab]').forEach(button => {
        button.addEventListener('click', () => {
          const item = episode.vocabulary[Number(button.dataset.vocab)];
          if (!item || !detail) return;
          detail.innerHTML = `<strong>${escapeText(item.word)}</strong> — ${escapeText(item.definition)}<small>${escapeText(item.definitionJP)}</small>`;
        });
      });
    }

    function renderMechanic(restoredCount) {
      if (!mechanic) return '';
      const items = mechanic.acts || mechanic.items || mechanic.beats || [];
      if (!items.length) return '';
      const className = mechanic.type === 'memory-theatre'
        ? 'reading-theatre-stage'
        : `reading-mechanic-board reading-mechanic-${escapeText(mechanic.type)}`;
      const cards = items.map((item, index) => {
        const state = index < restoredCount ? 'is-restored' : (index === restoredCount ? 'is-current' : 'is-locked');
        const locked = index > restoredCount;
        const numberLabel = mechanic.type === 'memory-theatre' ? 'ACT' : (mechanic.type === 'evidence-board' ? 'CLUE' : 'BEAT');
        /* Pass 4: revealed acts show the actual room the memory happened in
           (reusing the same room art Karasuki already loads) instead of a
           flat text tile — locked acts stay plain so the scene is still a
           small reveal, not a spoiler. */
        const scene = !locked ? sceneImageFor(index) : null;
        const sceneStyle = scene
          ? ` style="background-image:linear-gradient(180deg,rgba(10,6,16,.55),rgba(10,6,16,.85)),url('${escapeText(scene)}')"`
          : '';
        return `
          <div class="reading-theatre-act ${state}"${sceneStyle}>
            <span class="act-number">${numberLabel} ${String(index + 1).padStart(2, '0')}</span>
            <span class="act-title">${escapeText(item.title)}</span>
            <span class="act-title-jp">${escapeText(item.titleJP)}</span>
            ${locked
              ? `<span class="reading-theatre-locked">Answer the next question to reveal this piece.<br>${FURI.sentence('次の問題に答えると手がかりが現れます。', { '次': 'つぎ', '問題': 'もんだい', '答える': 'こたえる', '手がかり': 'てがかり', '現れます': 'あらわれます' })}</span>`
              : `<span class="act-caption">${escapeText(item.caption)}</span><span class="act-caption-jp">${escapeText(item.captionJP)}</span>`}
          </div>`;
      }).join('');
      const complete = restoredCount >= items.length;
      const statusJP = complete ? mechanic.completeJP : `${restoredCount} / ${items.length} 発見`;
      const statusEN = complete ? mechanic.complete : `${restoredCount} / ${items.length} ${mechanic.type === 'memory-theatre' ? 'acts restored' : 'pieces revealed'}`;
      return `
        <section class="reading-mechanic" aria-label="${escapeText(mechanic.name)}">
          <div class="reading-mechanic-heading">${escapeText(mechanic.name)} <span>${escapeText(mechanic.nameJP)}</span></div>
          <p class="reading-mechanic-intro">${escapeText(mechanic.instruction)}</p>
          <p class="reading-mechanic-intro-jp">${escapeText(mechanic.instructionJP)}</p>
          <div class="${className}">${cards}</div>
          <div class="reading-theatre-status">${escapeText(statusEN)}<small>${escapeText(statusJP)}</small></div>
        </section>`;
    }

    function renderPostcard() {
      const postcard = episode.postcard;
      if (!postcard || replayLens) return '';
      const motif = episode.worldEcho && episode.worldEcho.motif;
      const colors = MOTIF_COLORS[motif] || { ring: '#d8a8ff', glow: 'rgba(216,168,255,.4)' };
      const stamp = POSTCARD_STAMPS[motif] || '✦';
      const frame = content => `<section class="reading-postcard" style="--postcard-ring:${colors.ring};--postcard-glow:${colors.glow};"><span class="reading-postcard-stamp" aria-hidden="true">${stamp}</span>${content}</section>`;
      if (!postcardOpen) {
        return frame(`<div class="reading-postcard-heading">${escapeText(postcard.title)}<span>${escapeText(postcard.titleJP)}</span></div><button class="reading-secondary" id="reading-postcard-open" type="button">Write a postcard / ${FURI.sentence('文章カードを書く', { '文章': 'ぶんしょう', '書く': 'かく' })}</button>`);
      }
      if (postcardSaved) {
        return frame(`<div class="reading-postcard-success"><strong>Postcard saved.</strong> You can read it again in your Journal.<small>${FURI.sentence('保存しました。Journalで読み返せます。', { '保存しました': 'ほぞんしました', '読み返せます': 'よみかえせます' })}</small></div>`);
      }
      if (postcardBuilt) {
        const text = postcardSelection.map(index => postcard.chunks[index]).join(' ');
        return frame(`<div class="reading-postcard-heading">${escapeText(postcard.title)}<span>${escapeText(postcard.titleJP)}</span></div><p class="reading-postcard-instruction">Your postcard:<small>${FURI.sentence('あなたの文章カード：', { '文章': 'ぶんしょう' })}</small></p><div class="reading-postcard-picked">${escapeText(text)}</div><div class="reading-postcard-actions"><button class="reading-postcard-save" id="reading-postcard-save" type="button">Save postcard / ${FURI.sentence('保存する', { '保存する': 'ほぞんする' })}</button><button class="reading-task-action" id="reading-postcard-reset" type="button">Try again / ${FURI.sentence('もう一度', { '一度': 'いちど' })}</button></div>`);
      }
      const chunks = postcard.chunks.map((chunk, index) => postcardSelection.includes(index) ? '' : `<button class="reading-postcard-option" type="button" data-postcard-chunk="${index}">${escapeText(chunk)}<small>${escapeText(postcard.chunksJP[index] || '')}</small></button>`).join('');
      const picked = postcardSelection.length
        ? postcardSelection.map((index, order) => `<strong>${order + 1}.</strong> ${escapeText(postcard.chunks[index])}`).join('<br>')
        : 'Your summary will appear here.';
      return frame(`<div class="reading-postcard-heading">${escapeText(postcard.title)}<span>${escapeText(postcard.titleJP)}</span></div><p class="reading-postcard-instruction">${escapeText(postcard.instruction)}<small>${escapeText(postcard.instructionJP)}</small></p>${postcardFeedback ? `<div class="reading-postcard-success">${postcardFeedback}</div>` : ''}<div class="reading-postcard-picked">${picked}</div><div class="reading-postcard-options">${chunks || '<span style="color:rgba(255,255,255,.55);font-size:.74rem;">All pieces selected. Check your summary.</span>'}</div><div class="reading-postcard-actions"><button class="reading-task-action" id="reading-postcard-reset" type="button">Start over / ${FURI.sentence('最初から', { '最初': 'さいしょ' })}</button><button class="reading-task-action primary" id="reading-postcard-check" type="button">Check summary / ${FURI.sentence('まとめを確認', { '確認': 'かくにん' })}</button></div>`);
    }

    function savePostcard() {
      const postcard = episode.postcard;
      if (!postcard || !postcardSaved) {
        const payload = { text: postcardSelection.map(index => postcard.chunks[index]).join(' '), savedAt: Date.now() };
        if (opts.persist) opts.persist({ postcard: payload });
        if (typeof opts.onPostcardSave === 'function') opts.onPostcardSave(payload);
        postcardSaved = true;
      }
      render();
    }

    const finish = () => {
      if (opts.reviewOnly) {
        if (typeof opts.onReviewComplete === 'function') {
          opts.onReviewComplete({
            supportLevel,
            mistakes: mistakeCount,
            usedEvidence,
            totalQuestions: questions.length,
          });
        }
        close();
        return;
      }
      const onComplete = opts.onComplete;
      close();
      if (onComplete) onComplete();
    };

    const review = () => {
      questionIndex = 0;
      mechanicIndex = 0;
      lastFeedback = '';
      lastFeedbackJP = '';
      sequenceSelection = [];
      inferenceAnswerChosen = false;
      mistakeCount = 0;
      usedEvidence = false;
      postcardOpen = false;
      postcardSelection = [];
      postcardBuilt = false;
      postcardFeedback = '';
      if (opts.persist) {
        const progress = { state: 'reading', readingState: 'review', readingIndex: 0, mechanicIndex: 0 };
        if (mechanic && mechanic.type === 'memory-theatre') progress.theatreIndex = 0;
        opts.persist(progress);
      }
      render();
    };

    function resetQuestionInteraction() {
      sequenceSelection = [];
      inferenceAnswerChosen = false;
    }

    function renderLineChoices(question, mode) {
      const selectedLine = mode === 'inference' ? question.supportingLine : question.matchLine;
      const instruction = mode === 'inference'
        ? 'Now choose the line that proves your idea.'
        : 'Tap the exact line that contains the answer.';
      const instructionJP = mode === 'inference'
        ? FURI.sentence('次に、考えを証明する行を選びましょう。', { '次に': 'つぎに', '考え': 'かんがえ', '証明する': 'しょうめいする', '行': 'ぎょう', '選びましょう': 'えらびましょう' })
        : FURI.sentence('答えが書かれている行をタップしましょう。', { '答え': 'こたえ', '書かれている': 'かかれている', '行': 'ぎょう' });
      const lines = episode.lines.map((line, index) => `
        <button class="reading-line-choice" type="button" data-line-choice="${index}">
          <span class="line-speaker">${escapeText(line.speaker)}</span>
          <span class="line-text">${escapeText(line.en)}</span>
        </button>`).join('');
      return `<div class="reading-interaction reading-line-interaction" data-correct-line="${Number.isInteger(selectedLine) ? selectedLine : -1}">
        <p class="reading-interaction-instruction">${instruction}<small>${instructionJP}</small></p>
        <div class="reading-line-choices">${lines}</div>
      </div>`;
    }

    function renderInteraction(question) {
      if (question.type === 'sequence') {
        const choices = question.choices.map((choice, index) => {
          if (sequenceSelection.includes(index)) return '';
          return `<button class="reading-task-choice" type="button" data-sequence-choice="${index}"><span>${escapeText(choice)}</span><small>${escapeText(question.choicesJP[index] || '')}</small></button>`;
        }).join('');
        const picked = sequenceSelection.length
          ? sequenceSelection.map((index, order) => `<strong>${order + 1}.</strong> ${escapeText(question.choices[index])}`).join('<br>')
          : 'Your order will appear here.';
        return `<div class="reading-interaction reading-sequence-interaction">
          <p class="reading-interaction-instruction">Tap each event in the order it happened.<small>${FURI.sentence('出来事が起きた順番にタップしましょう。', { '出来事': 'できごと', '起きた': 'おきた', '順番': 'じゅんばん' })}</small></p>
          <div class="reading-sequence-picked">${picked}</div>
          <div class="reading-sequence-options">${choices || '<span style="color:rgba(255,255,255,.55);font-size:.75rem;">All events selected. Check your order.</span>'}</div>
          <div class="reading-sequence-actions"><button class="reading-task-action" type="button" id="reading-sequence-reset">Start over / ${FURI.sentence('最初から', { '最初': 'さいしょ' })}</button><button class="reading-task-action primary" type="button" id="reading-sequence-submit">Check order / ${FURI.sentence('順番を確認', { '順番': 'じゅんばん', '確認': 'かくにん' })}</button></div>
        </div>`;
      }
      if (question.type === 'detail') return renderLineChoices(question, 'detail');
      if (question.type === 'inference') {
        if (!inferenceAnswerChosen) {
          const choices = question.choices.map((choice, index) => `<button class="reading-task-choice" type="button" data-inference-choice="${index}"><span>${escapeText(choice)}</span><small>${escapeText(question.choicesJP[index] || '')}</small></button>`).join('');
          return `<div class="reading-interaction reading-inference-interaction"><p class="reading-interaction-instruction">Choose the meaning you infer from the conversation.<small>${FURI.sentence('会話から分かる意味を選びましょう。', { '会話': 'かいわ', '分かる': 'わかる', '意味': 'いみ', '選びましょう': 'えらびましょう' })}</small></p><div class="reading-sequence-options">${choices}</div></div>`;
        }
        const chosen = question.choices[question.correct];
        return `<div class="reading-interaction reading-inference-interaction"><p class="reading-picked-answer">Your idea: ${escapeText(chosen)}<small>${FURI.sentence('あなたの考え：', { '考え': 'かんがえ' })}${escapeText(question.choicesJP[question.correct] || '')}</small></p>${renderLineChoices(question, 'inference')}</div>`;
      }
      const choices = question.choices.map((choice, i) => `<button class="reading-choice" data-choice="${i}"><span>${escapeText(choice)}</span><small>${escapeText(question.choicesJP[i] || '')}</small></button>`).join('');
      return `<div class="reading-choices">${choices}</div>`;
    }

    function advanceQuestion(question) {
      if (window.UtsuSfx) window.UtsuSfx.correct(episode.worldEcho && episode.worldEcho.motif);
      questionIndex += 1;
      showEvidence = false;
      resetQuestionInteraction();
      if (mechanic && question.revealAct != null) {
        mechanicIndex = Math.max(mechanicIndex, question.revealAct + 1);
        lastFeedback = question.restoreText || 'The scene returns.';
        lastFeedbackJP = question.restoreTextJP || '場面が戻ります。';
      } else {
        lastFeedback = '';
        lastFeedbackJP = '';
      }
      if (opts.persist) {
        const progress = { readingIndex: questionIndex, mechanicIndex };
        if (mechanic && mechanic.type === 'memory-theatre') progress.theatreIndex = mechanicIndex;
        opts.persist(progress);
      }
      render();
    }

    function showWrong(question) {
      if (window.UtsuSfx) window.UtsuSfx.wrong();
      mistakeCount += 1;
      showEvidence = false;
      lastFeedback = `Not quite. Look again at the lines. ${question.evidence}`;
      lastFeedbackJP = question.evidenceJP || 'もう一度、会話を読み直しましょう。';
      setTimeout(render, 320);
    }

    const render = () => {
      const question = questions[questionIndex];
      const evidenceLines = question && Array.isArray(question.evidenceLines) ? question.evidenceLines : [];
      const lines = episode.lines.map((line, lineIndex) => `
        <div class="reading-line${showEvidence && evidenceLines.includes(lineIndex) ? ' is-evidence' : ''}" data-line-index="${lineIndex}">
          <div class="reading-speaker">${escapeText(line.speaker)}</div>
          <div class="reading-en">${escapeText(line.en)}</div>
        </div>`).join('');

      if (!question) {
        const modeLabel = opts.reviewOnly
          ? reviewModeLabel()
          : `FIRST READING / ${FURI.sentence('はじめての読書', { '読書': 'どくしょ' })}`;
        const reviewResult = opts.reviewOnly
          ? `${mistakeCount === 0 && !usedEvidence ? 'You remembered it well.' : 'You used help when you needed it.'}<small>${mistakeCount === 0 && !usedEvidence ? FURI.sentence('ヒントなしで思い出せました。', { '思い出せました': 'おもいだせました' }) : FURI.sentence('必要なときにサポートを使いました。', { '必要': 'ひつよう', '使いました': 'つかいました' })}</small>`
          : '';
        const completeActions = opts.reviewOnly
          ? `<button class="reading-secondary" id="reading-review-btn">Read again / ${FURI.sentence('もう一度読む', { '一度': 'いちど', '読む': 'よむ' })}</button><button class="reading-primary" id="reading-return-btn">Close journal review / ${FURI.sentence('ノートを閉じる', { '閉じる': 'とじる' })}</button>`
          : `<button class="reading-secondary" id="reading-review-btn">Review reading / ${FURI.sentence('読み返す', { '読み返す': 'よみかえす' })}</button><button class="reading-primary" id="reading-return-btn">Restore memory / ${FURI.sentence('記憶を戻す', { '記憶': 'きおく', '戻す': 'もどす' })}</button>`;
        const completeNote = opts.reviewOnly
          ? `This is a quiet review. It does not change your quest.<br>${FURI.sentence('これは読み返しです。クエストは変わりません。', { '読み返し': 'よみかえし', '変わりません': 'かわりません' })}`
          : `Review as many times as you like before restoring the memory.<br>${FURI.sentence('記憶を戻す前に、何度でも読み返せます。', { '記憶': 'きおく', '戻す前に': 'もどすまえに', '何度でも': 'なんども', '読み返せます': 'よみかえせます' })}`;
        overlay.innerHTML = `
          <div class="reading-card reading-complete">
            ${renderPortrait('hero')}
            <div class="reading-eyebrow">${escapeText(episode.eyebrow)}</div>
            <div class="reading-support-badge${supportLevel === 'independent' ? ' independent' : ''}">${modeLabel}</div>
            <h2>${escapeText(episode.title)}</h2>
            ${renderVocabulary()}
            ${renderMechanic(mechanic ? (mechanic.acts || mechanic.items || mechanic.beats || []).length : mechanicIndex)}
            <p class="reading-success">${escapeText(episode.success)}</p>
            <p class="reading-jp">${escapeText(episode.successJP)}</p>
            ${reviewResult ? `<p class="reading-review-note">${reviewResult}</p>` : ''}
            ${renderPostcard()}
            ${renderLensReplay()}
            <div class="reading-complete-actions">
              ${completeActions}
            </div>
            <p class="reading-review-note">${completeNote}</p>
          </div>`;
        overlay.querySelector('#reading-return-btn').addEventListener('click', finish);
        overlay.querySelector('#reading-review-btn').addEventListener('click', review);
        overlay.querySelectorAll('[data-reading-lens]').forEach(button => button.addEventListener('click', () => startLensReplay(button.dataset.readingLens)));
        const postcardOpenButton = overlay.querySelector('#reading-postcard-open');
        if (postcardOpenButton) postcardOpenButton.addEventListener('click', () => { postcardOpen = true; render(); });
        overlay.querySelectorAll('[data-postcard-chunk]').forEach(button => button.addEventListener('click', () => {
          const index = Number(button.dataset.postcardChunk);
          if (!postcardSelection.includes(index)) { postcardSelection.push(index); postcardFeedback = ''; render(); }
        }));
        const postcardResetButton = overlay.querySelector('#reading-postcard-reset');
        if (postcardResetButton) postcardResetButton.addEventListener('click', () => { postcardSelection = []; postcardBuilt = false; postcardFeedback = ''; render(); });
        const postcardCheckButton = overlay.querySelector('#reading-postcard-check');
        if (postcardCheckButton) postcardCheckButton.addEventListener('click', () => {
          const postcard = episode.postcard;
          const expected = Array.isArray(postcard?.order) ? postcard.order : [];
          if (postcardSelection.length === expected.length && postcardSelection.every((value, index) => value === expected[index])) {
            postcardBuilt = true;
            postcardFeedback = `<strong>That summary makes sense.</strong><small>${FURI.sentence('このまとめで大丈夫です。', { '大丈夫': 'だいじょうぶ' })}</small>`;
          } else {
            postcardFeedback = `<strong>Try a different order.</strong> Read the memory once more.<small>${FURI.sentence('別の順番を試しましょう。もう一度記憶を読みましょう。', { '別': 'べつ', '順番': 'じゅんばん', '試しましょう': 'ためしましょう', '一度': 'いちど', '記憶': 'きおく', '読みましょう': 'よみましょう' })}</small>`;
          }
          render();
        });
        const postcardSaveButton = overlay.querySelector('#reading-postcard-save');
        if (postcardSaveButton) postcardSaveButton.addEventListener('click', savePostcard);
        bindVocabulary();
        focusFirstControl();
        return;
      }

      overlay.innerHTML = `
        <div class="reading-card">
          <button class="reading-close" id="reading-close-btn">✕</button>
          <div class="reading-header">
            <div class="reading-header-text">
              <div class="reading-eyebrow">${escapeText(episode.eyebrow)}</div>
              <div class="reading-support-badge${supportLevel === 'independent' ? ' independent' : ''}">${opts.reviewOnly ? reviewModeLabel() : `FIRST READING / ${FURI.sentence('はじめての読書', { '読書': 'どくしょ' })}`}</div>
              <h2>${escapeText(episode.title)} <span>${escapeText(episode.titleJP)}</span></h2>
              <p class="reading-intro">${escapeText(episode.intro)}</p>
              <p class="reading-jp">${escapeText(episode.introJP)}</p>
            </div>
            ${renderPortrait('inline')}
          </div>
          ${renderVocabulary()}
          ${renderMechanic(mechanicIndex)}
          <div class="reading-transcript">${lines}</div>
          <div class="reading-question-label">${escapeText(question.label)} · ${escapeText(question.labelJP)}</div>
          <h3>${escapeText(question.prompt)}</h3>
          <p class="reading-jp">${escapeText(question.promptJP)}</p>
          ${lastFeedback ? `<div class="reading-feedback" role="status" aria-live="polite">${escapeText(lastFeedback)}<small>${escapeText(lastFeedbackJP)}</small>${supportLevel === 'guided' || mistakeCount >= 2 ? `<button class="reading-evidence-btn" id="reading-evidence-btn" type="button">Show evidence / ${FURI.sentence('証拠を見る', { '証拠': 'しょうこ', '見る': 'みる' })}</button>` : ''}</div>` : ''}
          ${renderInteraction(question)}
          <div class="reading-progress" role="status" aria-live="polite"><div class="reading-progress-top">Question ${questionIndex + 1} of ${questions.length}<small>${FURI.sentence('問題', { '問題': 'もんだい' })} ${questionIndex + 1} / ${questions.length}</small></div><div class="reading-progress-track" aria-hidden="true"><span class="reading-progress-fill" style="width:${Math.round(((questionIndex + 1) / Math.max(1, questions.length)) * 100)}%"></span></div></div>
        </div>`;

      overlay.querySelector('#reading-close-btn').addEventListener('click', close);
      bindVocabulary();
      const evidenceButton = overlay.querySelector('#reading-evidence-btn');
      if (evidenceButton) evidenceButton.addEventListener('click', () => {
        usedEvidence = true;
        if (typeof opts.onReadingEvent === 'function') opts.onReadingEvent('evidence');
        showEvidence = true;
        render();
        const firstEvidence = overlay.querySelector('.reading-line.is-evidence');
        if (firstEvidence) firstEvidence.scrollIntoView({ block: 'center', behavior: 'smooth' });
      });
      overlay.querySelectorAll('[data-sequence-choice]').forEach(button => button.addEventListener('click', () => {
        const choice = Number(button.dataset.sequenceChoice);
        if (!sequenceSelection.includes(choice)) {
          sequenceSelection.push(choice);
          render();
        }
      }));
      const sequenceReset = overlay.querySelector('#reading-sequence-reset');
      if (sequenceReset) sequenceReset.addEventListener('click', () => { sequenceSelection = []; lastFeedback = ''; lastFeedbackJP = ''; render(); });
      const sequenceSubmit = overlay.querySelector('#reading-sequence-submit');
      if (sequenceSubmit) sequenceSubmit.addEventListener('click', () => {
        const expected = Array.isArray(question.sequenceOrder) ? question.sequenceOrder : question.choices.map((_, index) => index);
        if (sequenceSelection.length === expected.length && sequenceSelection.every((value, index) => value === expected[index])) advanceQuestion(question);
        else showWrong(question);
      });
      overlay.querySelectorAll('[data-line-choice]').forEach(button => button.addEventListener('click', () => {
        const lineIndex = Number(button.dataset.lineChoice);
        const expected = question.type === 'inference' ? question.supportingLine : question.matchLine;
        if (lineIndex === expected) advanceQuestion(question);
        else showWrong(question);
      }));
      overlay.querySelectorAll('[data-inference-choice]').forEach(button => button.addEventListener('click', () => {
        const choice = Number(button.dataset.inferenceChoice);
        if (choice === question.correct) {
          inferenceAnswerChosen = true;
          lastFeedback = 'Good. Now prove your idea with a line.';
          lastFeedbackJP = 'いいですね。次に、証拠の行を選びましょう。';
          render();
        } else showWrong(question);
      }));
      overlay.querySelectorAll('[data-choice]').forEach(button => button.addEventListener('click', () => {
        const choice = Number(button.dataset.choice);
        if (choice === question.correct) advanceQuestion(question);
        else showWrong(question);
      }));
      focusFirstControl();
    };

    if (opts.persist) {
      const progress = { state: 'reading', readingState: 'active', readingIndex: questionIndex, mechanicIndex };
      if (mechanic && mechanic.type === 'memory-theatre') progress.theatreIndex = mechanicIndex;
      opts.persist(progress);
    }
    if (needsOnboarding) renderOnboarding();
    else { render(); focusFirstControl(); }
    return true;
  }

  window.UtsurobaReading = {
    start,
    close,
    isOpen: () => open
  };
})();
