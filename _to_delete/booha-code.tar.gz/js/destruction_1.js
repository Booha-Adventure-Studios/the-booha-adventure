
/* =====================================================
   BOOHA DESTRUCTION  —  destruction_1.js  (v4)

   CHANGES FROM v3:
   1. Block traits & resist system
      - cloneBlock() reads def.traits[] and def.resist{}
      - hasTrait(), getResist(), powerBlocked() helpers
      - damageBlock() accepts power param; skips/scales damage
      - blockCollide() passes power; checks immune before FX
      - updateBurning() checks burnimmune before tick
   2. Visual feedback on resistant/immune blocks
      - drawBlocks() renders a tinted border on blocks with traits
      - Colour-coded per dominant immunity type
   ===================================================== */
(() => {
  'use strict';

  const CFG    = window.BOOHA_CFG   || {};
  const ASSETS = CFG.assets         || {};
  const AUDIO  = CFG.audio          || {};

  // ── Layout constants ────────────────────────────────
  const W = 1280, H = 720;
  const FLOOR_Y    = H - 80;
  const SLING_X    = 190;
  const SLING_Y    = FLOOR_Y - 118;
  const MAX_PULL   = 148;
  const B_RADIUS   = 34;
  const GRAVITY    = 0.48;
  const AIR        = 0.999;
  const BOUNCE     = 0.72;
  const MIN_IMPACT = 3.8;
  const REST_THR   = 0.35;
  const SETTLE_NEED = 38;
  const NEXT_MS    = 950;
  const HIT_COOL   = 90;
  const FIXED_STEP = 1000 / 60;
  const MAX_RUN_LIVES = 3;
  const GAME_ID = 'bonus:booha_destruction';

  // A block should feel seated, not magically supported by a tiny corner.
  // 42% still allows intentional leaning stacks without making the support
  // graph read as a pile of unrelated floating props.
  const SUPPORT_OVERLAP = 0.42;
  const FALL_CRUSH_SPEED = 9;
  const FLOOR_THRESHOLD = 6;

  const IS_MOBILE = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent)
    || window.innerWidth < 768;
  const REDUCED_MOTION = !!(window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const LOW_POWER = IS_MOBILE || REDUCED_MOTION ||
    (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
  // Canvas 2D effects are fill-rate heavy on scaled iPad displays. Start
  // conservatively and let the governor earn quality back after the scene is
  // proven stable. The game should feel responsive before it feels flashy.
  const BURST_SCALE = LOW_POWER ? 0.42 : 0.68;
  const PERF = {
    fxScale: LOW_POWER ? 0.42 : 0.68,
    targetScale: LOW_POWER ? 0.5 : 0.82,
    slowFrames: 0,
    fastFrames: 0,
    frameMs: 0,
    updateMs: 0,
    renderMs: 0,
    frames: 0,
    maxFrameMs: 0,
    qualityChanges: 0,
  };
  let needsRender = true;
  let staticRenderKey = '';
  let toastWasVisible = false;
  let exitConfirmOpen = false;
  let pauseOpen = false;
  let hallReturnState = null;

  // ── Canvas ──────────────────────────────────────────
  const canvas = document.getElementById(CFG.canvasId || 'gameCanvas');
  if (!canvas) { console.error('Booha: no canvas'); return; }
  const ctx = canvas.getContext('2d');
  canvas.width  = W;
  canvas.height = H;
  let backgroundCache = null;
  let playBackgroundCache = null;
  const tintedBackgroundCache = new Map();
  let viewportBackdropCache = null;
  let viewportBackdropHeight = 0;
  let hudMeterGradient = null;
  let hudMeterGradientWidth = 0;
  let goalGradient = null;
  let goalGradientWidth = 0;
  let VIEW_H = H;
  let SCENE_Y = 0;
  let FULL_BLEED = false;

  // ── Phase enum ──────────────────────────────────────
  const P = { TITLE:'title', HALL:'hall', BRIEF:'brief', PLAY:'play', WIN:'win', FAIL:'fail' };

  // ── FX pools ────────────────────────────────────────
  const sparks      = [];
  const waves       = [];
  const impactBursts = [];
  const dusts       = [];
  const confetti    = [];
  const powers      = [];
  const scorchMarks = [];
  const shake       = { v:0, decay:0.87 };

  const CAP = {
    // These are intentionally conservative. A short, readable burst is more
    // valuable than hundreds of particles fighting the playfield and HUD.
    sparks: LOW_POWER ? 58 : 78,
    waves:  LOW_POWER ? 8  : 12,
    impactBursts: LOW_POWER ? 5 : 8,
    dusts:  LOW_POWER ? 14 : 20,
    confetti: LOW_POWER ? 42 : 64,
    damageConfetti: LOW_POWER ? 16 : 24,
    scorchMarks: LOW_POWER ? 5 : 7
  };
  function pushCapped(arr, cap, item) {
    const limit = Math.max(1, Math.floor(cap * PERF.fxScale));
    if (arr.length < limit) arr.push(item);
  }
  function burstCount(base, minimum=1) {
    const factor = clamp(PERF.fxScale / 0.68, 0.42, 1);
    return Math.max(minimum, Math.round(base * factor));
  }
  function trimFX() {
    const trim = (arr, cap) => {
      const limit = Math.max(1, Math.floor(cap * PERF.fxScale));
      if (arr.length > limit) arr.splice(0, arr.length - limit);
    };
    trim(sparks, CAP.sparks);
    trim(waves, CAP.waves);
    trim(impactBursts, CAP.impactBursts);
    trim(dusts, CAP.dusts);
    trim(confetti, CAP.confetti);
    trim(scorchMarks, CAP.scorchMarks);
    if (typeof gs !== 'undefined' && gs.damageConfetti) trim(gs.damageConfetti, CAP.damageConfetti);
  }
  // Useful during device testing without adding an on-screen debug panel.
  window.__BOOHA_DESTRUCTION_PERF = PERF;

  // ── Landscape lock overlay ───────────────────────────
  let rotateOverlay = null;
  function ensureRotateOverlay() {
    if (rotateOverlay) return;
    rotateOverlay = document.createElement('div');
    rotateOverlay.id = 'booha-rotate';
    Object.assign(rotateOverlay.style, {
      position:'fixed',top:'0',left:'0',width:'100%',height:'100%',
      background:'#0c0a12',display:'flex',flexDirection:'column',
      alignItems:'center',justifyContent:'center',zIndex:'9999',
      fontFamily:'system-ui,sans-serif',color:'#fff',gap:'24px'
    });
    rotateOverlay.innerHTML = `
      <div style="font-size:72px;animation:rotSpin 2s ease-in-out infinite alternate">📱</div>
      <div style="font-size:22px;font-weight:bold;letter-spacing:2px">ROTATE TO PLAY</div>
      <div style="font-size:14px;opacity:0.5">Booha Destruction requires landscape mode</div>
      <style>@keyframes rotSpin{0%{transform:rotate(-90deg)}100%{transform:rotate(0deg)}}</style>
    `;
    document.body.appendChild(rotateOverlay);
  }
  function checkOrientation() {
    const isPortrait = window.innerHeight > window.innerWidth;
    if (isPortrait) { ensureRotateOverlay(); rotateOverlay.style.display = 'flex'; }
    else if (rotateOverlay) rotateOverlay.style.display = 'none';
  }
  window.addEventListener('resize', checkOrientation);
  window.addEventListener('orientationchange', checkOrientation);
  checkOrientation();

  // ── Audio ────────────────────────────────────────────
  let AC = null;
  const AUDIO_PREF_KEY = 'booha_destruction_muted';
  const AUDIO_STATE = {
    muted:false, warned:new Set(), ready:false,
    master:0.82, maxVoices:4, activeVoices:0,
    lastPlayed:new Map(), activeSFX:[]
  };

  function audioWarn(key, error) {
    if (AUDIO_STATE.warned.has(key)) return;
    AUDIO_STATE.warned.add(key);
    console.warn(`[Booha Destruction] Audio unavailable: ${key}`, error || '');
  }

  function getAC() {
    if (!AC) {
      const AudioCtor = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtor) { audioWarn('AudioContext'); return null; }
      try { AC = new AudioCtor(); }
      catch (e) { audioWarn('AudioContext', e); return null; }
    }
    if (AC.state === 'suspended') {
      try { const resume = AC.resume(); if (resume?.catch) resume.catch(e => audioWarn('resume', e)); }
      catch (e) { audioWarn('resume', e); }
    }
    AUDIO_STATE.ready = true;
    return AC;
  }
  const audioBuffers = {};
  const audioPromises = {};
  async function loadBuffer(key, src) {
    if (!src || audioBuffers[key]) return audioBuffers[key] || null;
    if (audioPromises[key]) return audioPromises[key];
    audioPromises[key] = (async () => {
      try {
        const res = await fetch(src);
        const ab  = await res.arrayBuffer();
        const ac = getAC();
        if (!ac) return null;
        audioBuffers[key] = await ac.decodeAudioData(ab);
        return audioBuffers[key];
      } catch(e) {
        audioWarn(`voice:${key}`, e);
        return null;
      } finally {
        delete audioPromises[key];
      }
    })();
    return audioPromises[key];
  }
  function playBuffer(key, vol=1) {
    if (AUDIO_STATE.muted) return;
    const buf = audioBuffers[key]; if (!buf) return;
    if (AUDIO_STATE.activeVoices >= AUDIO_STATE.maxVoices) return;
    try {
      const ac = getAC(); if (!ac) return;
      const src = ac.createBufferSource(), gain = ac.createGain();
      src.buffer = buf; gain.gain.value = Math.max(0, Math.min(1, vol * AUDIO_STATE.master));
      src.connect(gain); gain.connect(ac.destination); src.start();
      AUDIO_STATE.activeVoices++;
      src.onended = () => { AUDIO_STATE.activeVoices=Math.max(0,AUDIO_STATE.activeVoices-1); };
    } catch(e) {}
  }
  const SFX_POOL_SIZE = 5;
  const sfxPool = {};
  function getSFXNode(src) {
    if (!sfxPool[src]) sfxPool[src] = Array.from({length: SFX_POOL_SIZE}, () => {
      const audio = new Audio(src);
      audio.preload = 'auto';
      audio.onerror = () => audioWarn(src, audio.error || 'file load failed');
      return audio;
    });
    const pool = sfxPool[src];
    const free = pool.find(a => a.ended || (a.paused && a.currentTime === 0));
    if (free) return free;
    pool.sort((a, b) => b.currentTime - a.currentTime);
    const oldest = pool[0]; oldest.pause(); oldest.currentTime = 0; return oldest;
  }
  function playSFX(src, vol=1, rate=1, channel=src, cooldownMs=0, priority=0) {
    if (!src || AUDIO_STATE.muted) return;
    const now=performance.now();
    const last=AUDIO_STATE.lastPlayed.get(channel)||0;
    if (cooldownMs && now-last<cooldownMs) return;
    AUDIO_STATE.lastPlayed.set(channel,now);
    AUDIO_STATE.activeSFX=AUDIO_STATE.activeSFX.filter(a=>!a.paused&&!a.ended);
    if (AUDIO_STATE.activeSFX.length>=AUDIO_STATE.maxVoices) {
      if (priority<2) return;
      const oldest=AUDIO_STATE.activeSFX.shift();
      try { oldest.pause(); oldest.currentTime=0; } catch(e) {}
    }
    try {
      const a = getSFXNode(src);
      a.preload = 'auto';
      a.volume = Math.max(0, Math.min(1, vol * AUDIO_STATE.master));
      a.playbackRate = rate; a.currentTime = 0;
      const play = a.play();
      AUDIO_STATE.activeSFX.push(a);
      if (play?.catch) play.catch(e => audioWarn(src, e));
    } catch(e) { audioWarn(src, e); }
  }
  function synthPop(freq=500, vol=0.3, dur=0.08) {
    try {
      if (AUDIO_STATE.muted) return;
      if (AUDIO_STATE.activeVoices >= AUDIO_STATE.maxVoices) return;
      const ac = getAC(); if (!ac) return;
      const o = ac.createOscillator(), g = ac.createGain();
      o.connect(g); g.connect(ac.destination); o.type = 'sine';
      o.frequency.setValueAtTime(freq, ac.currentTime);
      o.frequency.exponentialRampToValueAtTime(freq * 0.38, ac.currentTime + dur);
      g.gain.setValueAtTime(vol * AUDIO_STATE.master, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + dur);
      o.start(ac.currentTime); o.stop(ac.currentTime + dur + 0.01);
      AUDIO_STATE.activeVoices++;
      o.onended = () => { AUDIO_STATE.activeVoices=Math.max(0,AUDIO_STATE.activeVoices-1); };
    } catch(e) {}
  }

  function preloadAudio() {
    const sources = Object.values(AUDIO).filter(Boolean);
    sources.forEach(src => {
      try {
        const audio = new Audio(src);
        audio.preload = 'auto';
        audio.load?.();
      } catch (e) { audioWarn(src, e); }
    });
  }

  function readMutePreference() {
    try { AUDIO_STATE.muted = window.localStorage?.getItem(AUDIO_PREF_KEY) === '1'; }
    catch (e) { AUDIO_STATE.muted = false; }
  }

  function toggleMute() {
    AUDIO_STATE.muted = !AUDIO_STATE.muted;
    if (AUDIO_STATE.muted) {
      AUDIO_STATE.activeSFX.forEach(a => { try { a.pause(); a.currentTime=0; } catch(e) {} });
      AUDIO_STATE.activeSFX=[];
      AUDIO_STATE.lastPlayed.clear();
    }
    try { window.localStorage?.setItem(AUDIO_PREF_KEY, AUDIO_STATE.muted ? '1' : '0'); }
    catch (e) {}
    setToast(AUDIO_STATE.muted ? 'Sound off / 音声オフ' : 'Sound on / 音声オン', AUDIO_STATE.muted ? '#aaa' : '#7cfff8');
  }
  function celebPops(baseFreq=420) {
    [0,90,190].forEach((d,i) => setTimeout(() => synthPop(baseFreq + i*125, 0.24, 0.09), d));
  }

  // ── Booha roster ────────────────────────────────────
  const ROSTER = [
    { id:'booha', name:'Yellow Booha', jpName:'イエローブーハー',
      img:'./assets/destruction/optimized/booha_helmet_512.png',
      thumb:'./assets/destruction/optimized/booha_helmet_256.png',
      sfx:'./assets/destruction/boo-boo.mp3', stock:5, power:'normal',
      desc:'Classic. Reliable. Friendly.',
      jp:'ベーシックであんていしたブーハーです。',
      tip:'Aim for the middle of tall stacks — the ricochet does the work.',
      conf:{cols:['#fff','#ffe','#ddf','#fdd','#dfd','#ffd'],sh:['circle','star','sparkle'],sz:[4,10],burst:65,spin:true}},
    { id:'heavy', name:'Heavy Booha', jpName:'ヘビーブーハー',
      img:'./assets/destruction/optimized/heavy_booha_512.png',
      thumb:'./assets/destruction/optimized/heavy_booha_256.png',
      sfx:'./assets/destruction/boo-heavy.mp3', stock:3, power:'heavy',
      desc:'2× damage. Craters on landing.',
      jp:'とても強く、かたいブロックをこわします。',
      tip:'Drop it from high up — vertical hits compress blocks hardest.',
      conf:{cols:['#f60','#f90','#fc0','#f40','#fa0','#c30'],sh:['chunk','rect','circle'],sz:[7,18],burst:90,spin:false}},
    { id:'rock', name:'Rock Booha', jpName:'ロックブーハー',
      img:'./assets/destruction/optimized/rock_booha_512.png',
      thumb:'./assets/destruction/optimized/rock_booha_256.png',
      sfx:'./assets/destruction/boo-rock.mp3', stock:2, power:'rock',
      desc:'Pierces one block. Keeps going.',
      jp:'ブロックをつきぬけて、さらに進みます。',
      tip:'Angle through multiple blocks in a line for chain damage.',
      conf:{cols:['#9ab','#cde','#678','#e0e','#456','#abc'],sh:['shard','rect','crystal'],sz:[5,13],burst:58,spin:true}},
    { id:'ice', name:'Ice Booha', jpName:'アイスブーハー',
      img:'./assets/destruction/optimized/ice_booha_512.png',
      thumb:'./assets/destruction/optimized/ice_booha_256.png',
      sfx:'./assets/destruction/boo-ice.mp3', stock:2, power:'ice',
      desc:'Freezes blocks. They shatter.',
      jp:'ブロックをこおらせます。こおったブロックはこわれやすいです。',
      tip:'Freeze a structural base block — when it shatters, everything above falls.',
      conf:{cols:['#aef','#dff','#8df','#fff','#bcf','#6df'],sh:['crystal','sparkle','star'],sz:[4,12],burst:80,spin:true}},
    { id:'fire', name:'Fire Booha', jpName:'ファイアブーハー',
      img:'./assets/destruction/optimized/fire_booha_512.png',
      thumb:'./assets/destruction/optimized/fire_booha_256.png',
      sfx:'./assets/destruction/boo-fire.mp3', stock:2, power:'fire',
      desc:'Burns nearby blocks over time.',
      jp:'まわりのブロックをだんだんもやします。',
      tip:'Hit a central block — the burn spreads to everything within range.',
      conf:{cols:['#f22','#f70','#fa0','#fe0','#f50','#f33'],sh:['flame','circle','sparkle'],sz:[5,14],burst:105,spin:false}},
    { id:'princess', name:'Princess Booha', jpName:'プリンセスブーハー',
      img:'./assets/destruction/optimized/princess_booha_512.png',
      thumb:'./assets/destruction/optimized/princess_booha_256.png',
      sfx:'./assets/destruction/boo-princess.mp3', stock:1, power:'princess',
      desc:'Light & bouncy. Spawns 3 minis on first hit!',
      jp:'あたると、ちいさいブーハーに３つに分かれます。',
      tip:'The minis scatter unpredictably — hit a dense cluster for max chaos.',
      conf:{cols:['#f8c','#fae','#c4a','#fde','#fff','#fbd'],sh:['heart','star','sparkle','circle'],sz:[4,11],burst:125,spin:true}},
    { id:'rainbow', name:'Rainbow Booha', jpName:'レインボーブーハー',
      img:'./assets/destruction/optimized/rainbow_booha_512.png',
      thumb:'./assets/destruction/optimized/rainbow_booha_256.png',
      sfx:'./assets/destruction/boo-rainbow.mp3', stock:1, power:'rainbow',
      desc:'Turns blocks to glass. Shimmer trail.',
      jp:'ブロックをガラスに変えます。',
      tip:'Glass breaks with one hit — convert a whole wall, then finish it off.',
      conf:{cols:['#f06','#f80','#ff0','#0f6','#08f','#80f','#f0f'],sh:['sparkle','star','crystal'],sz:[5,13],burst:130,spin:true}},
    { id:'nightmare', name:'Nightmare Booha', jpName:'ナイトメアブーハー',
      img:'./assets/destruction/optimized/nightmare_booha_512.png',
      thumb:'./assets/destruction/optimized/nightmare_booha_256.png',
      sfx:'./assets/destruction/boo-nightmare.mp3', stock:1, power:'nightmare',
      desc:'Teleports behind the target!',
      jp:'ブロックのうしろにテレポートします。',
      tip:'Works best when blocks are clustered — it warps to the nearest surviving block.',
      conf:{cols:['#508','#80c','#b0f','#d4f','#304','#f0f'],sh:['shard','star','sparkle'],sz:[4,13],burst:88,spin:true}},
    { id:'monster', name:'Monster Booha', jpName:'モンスターブーハー',
      img:'./assets/destruction/optimized/monster_booha_512.png',
      thumb:'./assets/destruction/optimized/monster_booha_256.png',
      sfx:'./assets/destruction/boo-monster.mp3', stock:1, power:'monster',
      desc:'Grows with every bounce. HUGE settle.',
      jp:'はねるたびに大きくなります。',
      tip:'Let it bounce off the floor a few times before it hits the blocks.',
      conf:{cols:['#0c4','#4f8','#cf0','#0f6','#3a0','#8f0'],sh:['chunk','circle','sparkle'],sz:[6,16],burst:95,spin:false}},
    { id:'ultimate', name:'Ultimate Booha', jpName:'アルティメットブーハー',
      img:'./assets/destruction/optimized/ultimate_booha_512.png',
      thumb:'./assets/destruction/optimized/ultimate_booha_256.png',
      sfx:'./assets/destruction/boo-ultimate.mp3', stock:1, power:'ultimate',
      desc:'On settle — EVERYTHING in range explodes!',
      jp:'ばくはつして、まわりをすべてこわします。',
      tip:'Land it dead-center in the structure for maximum blast radius.',
      conf:{cols:['#f08','#f80','#ff0','#0fa','#08f','#c0f','#f48','#4fc'],sh:['star','heart','crystal','sparkle','flame'],sz:[5,16],burst:170,spin:true}},
  ];

  const ROSTER_UNLOCK_KEY = 'booha_destruction:roster:';
  const ROSTER_UNLOCK_STORAGE_KEY = 'booha_destruction_roster_unlocks_v1';
  const ROSTER_UNLOCKS = [
    { unlockEN:'Starter Booha', unlockJP:'最初から使えます' },
    { unlockEN:'Clear 1 round', unlockJP:'1ラウンドをクリア', test:p=>p.rounds>=1 },
    { unlockEN:'Clear 3 rounds', unlockJP:'3ラウンドをクリア', test:p=>p.rounds>=3 },
    { unlockEN:'Clear 5 rounds', unlockJP:'5ラウンドをクリア', test:p=>p.rounds>=5 },
    { unlockEN:'Clear 10 rounds', unlockJP:'10ラウンドをクリア', test:p=>p.rounds>=10 },
    { unlockEN:'Clear Chapter 1', unlockJP:'チャプター1をクリア', test:p=>p.chapters>=1 },
    { unlockEN:'Earn 3 medals', unlockJP:'メダルを3こ獲得', test:p=>p.medals>=3 },
    { unlockEN:'Clear Chapter 2', unlockJP:'チャプター2をクリア', test:p=>p.chapters>=2 },
    { unlockEN:'Clear 3 boss rounds', unlockJP:'ボスラウンドを3回クリア', test:p=>p.bosses>=3 },
    { unlockEN:'Clear the final round', unlockJP:'さいごのラウンドをクリア', test:p=>p.finalRound },
  ];
  const SEL_CARD_W=72, SEL_CARD_H=52, SEL_GAP=7;
  const bst = {
    sel: 0,
    unlocked: ROSTER.map((_, i) => i === 0),
    stocks: ROSTER.map((b, i) => i === 0 ? b.stock : 0),
    imgs: new Array(ROSTER.length).fill(null),
    thumbs: new Array(ROSTER.length).fill(null),
    totalShots() { return ROSTER.reduce((a,b) => a + b.stock, 0); }
  };

  // ── Main game state ─────────────────────────────────
  const gs = {
    phase: P.TITLE,
    round: 0, roundN: 1,
    running: false,
    dragging: false, pullPlayed: false,
    lastHit: 0, flash: 0, bestShot: 0,
    hitStop: 0,
    pct: 0, totalBlocks: 0, brokenBlocks: 0,
    goalReached: false,
    ghostsLeft: 0,
    shotLock: false,
    booha: null,
    blocks: [],
    debTimer: 0,
    cardTitle: '', cardSub: '', cardAccent: '#fff',
    cardIntro: 0,
    cardMeta: '', cardMetaGood: false,
    roundBestScore: 0,
    roundBestShots: 0,
    roundMedal: 0,
    roundClears: 0,
    roundNewBest: false,
    roundMedalUp: false,
    cardUnlock: '',
    cardChapter: '',
    comboPulse: 0,
    nearMiss: false,
    toast: '',
    toastAccent: '#fff',
    toastUntil: 0,
    scale: 1, offX: 0, offY: 0,
    runScore: 0,
    roundScore: 0,
    roundMultiplier: 1,
    roundShotBonus: 0,
    roundDestructionScore: 0,
    shotsUsed: 0,
    collapseCount: 0,
    powerUsed: new Set(),
    contractComplete: false,
    contractBonus: 0,
    ruleComplete: false,
    ruleBonus: 0,
    ruleFailed: false,
    ruleTime: 0,
    markedTargetIndex: -1,
    combo: 0,
    lives: MAX_RUN_LIVES,
    runStartedAt: 0,
    campaignActive: false,
    campaignComplete: false,
    highScore: 0,
    lastScoreIsBest: false,
    imgs: { bg: null },
    fireTrail: [],
    minis: [],
    frozen: new Map(),
    bounces: 0,
    isLastBooha: false,
    timeScale: 1,
    nightmareFlicker: false,
    nightmareFlickerTimer: 0,
    monsterExplodeStage: 0,
    damageConfetti: [],

    roundTransitionTimer: null,
    roundToken: 0,
  };

  function queueNextRound(fn, delay) {
    clearTimeout(gs.roundTransitionTimer);
    const token = gs.roundToken;
    gs.roundTransitionTimer = setTimeout(() => {
      if (gs.roundToken !== token) return;
      fn();
    }, delay);
  }

  const LEVELS = window.BOOHA_DESTRUCTION_LEVELS || [];
  const CHAPTERS = window.BOOHA_DESTRUCTION_CHAPTERS || [];
  const ROUND_RECORD_KEY = 'booha_destruction_round_records_v1';
  let roundRecords = {};
  if (!LEVELS.length) console.error('Booha: no levels');

  // ── Helpers ─────────────────────────────────────────
  const rnd   = (a=0, b=1) => a + Math.random() * (b - a);
  const clamp = (n, mn, mx) => Math.max(mn, Math.min(mx, n));
  const dist  = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
  const pick  = arr => arr[Math.floor(Math.random() * arr.length)];
  const scoreText = n => Math.round(n || 0).toLocaleString('en-US');

  function fitText(text, maxWidth) {
    const value = String(text || '');
    if (ctx.measureText(value).width <= maxWidth) return value;
    let end = value.length;
    while (end > 1 && ctx.measureText(`${value.slice(0, end - 1)}…`).width > maxWidth) end--;
    return `${value.slice(0, Math.max(1, end - 1))}…`;
  }

  function simpleJapanese(text) {
    const value = String(text || '');
    let match = value.match(/^Clear in (\d+) shots or fewer$/i);
    if (match) return `${match[1]}発以内でクリア`;
    match = value.match(/^Launch ([A-Z]+) Booha once$/i);
    if (match) return `${match[1]}ブーハーを1回使う`;
    match = value.match(/^Trigger (\d+) unsupported blocks$/i);
    if (match) return `支えのないブロックを${match[1]}個落とす`;
    match = value.match(/^Use (\d+) different powers$/i);
    if (match) return `ちがうパワーを${match[1]}つ使う`;
    if (/Break the marked target/i.test(value)) return '光るターゲットをこわしてボーナス';
    if (/Break the glowing target block/i.test(value)) return '光るブロックをこわしてボーナス';
    match = value.match(/^Use ([A-Z]+) Booha for a bonus$/i);
    if (match) return `${match[1]}ブーハーを使ってボーナス`;
    match = value.match(/^Clear the structure in (\d+) seconds$/i);
    if (match) return `${match[1]}秒以内にクリア`;
    return '';
  }

  function bilingualParts(text, explicitJP='') {
    const parts = String(text || '').split(' / ');
    return {
      en: parts[0] || '',
      jp: parts.slice(1).join(' / ') || explicitJP || simpleJapanese(text),
    };
  }

  function setToast(message, accent='#fff', duration=2800) {
    gs.toast = message;
    gs.toastAccent = accent;
    gs.toastUntil = performance.now() + duration;
    needsRender = true;
  }

  function drawToast() {
    if (!gs.toast || performance.now() >= gs.toastUntil) return;
    ctx.save();
    ctx.globalAlpha = clamp((gs.toastUntil - performance.now()) / 500, 0, 1);
    ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillStyle='rgba(5,5,12,0.9)';ctx.strokeStyle=gs.toastAccent;ctx.lineWidth=2;
    rr(ctx,W/2-220,H-72,440,42,14,true,true);
    ctx.fillStyle='#fff';ctx.font='bold 16px system-ui,sans-serif';ctx.fillText(gs.toast,W/2,H-51);
    ctx.restore();
  }

  function currentLevel() { return LEVELS[gs.round] || {}; }
  function currentChapter() {
    return CHAPTERS[(currentLevel().chapter || 1) - 1] || {};
  }

  function loadRoundRecords() {
    try {
      const stored = window.localStorage && window.localStorage.getItem(ROUND_RECORD_KEY);
      const parsed = stored ? JSON.parse(stored) : {};
      roundRecords = parsed && typeof parsed === 'object' ? parsed : {};
    } catch (e) { roundRecords = {}; }
  }

  function saveRoundRecords() {
    try {
      if (window.localStorage) window.localStorage.setItem(ROUND_RECORD_KEY, JSON.stringify(roundRecords));
    } catch (e) { /* Storage can be unavailable in private browsing. */ }
  }

  function medalThresholds(level) {
    const bronze = 1800 + Math.min(2200, (level.blocks || []).length * 70);
    return { bronze, silver:Math.round(bronze * 1.28), gold:Math.round(bronze * 1.62) };
  }

  function medalForScore(level, score) {
    const t = medalThresholds(level);
    return score >= t.gold ? 3 : score >= t.silver ? 2 : score >= t.bronze ? 1 : 0;
  }

  function medalText(medal) { return medal > 0 ? '★'.repeat(medal) : '—'; }

  function getRoundRecord(level = currentLevel()) {
    const record = roundRecords[String(level.id)] || {};
    return {
      best: Number(record.best) || 0,
      medal: Number(record.medal) || 0,
      clears: Number(record.clears) || 0,
      contractClears: Number(record.contractClears) || 0,
      ruleClears: Number(record.ruleClears) || 0,
      bestShots: Number(record.bestShots) || 0,
    };
  }

  function rosterProgress() {
    const records = LEVELS.map(level => getRoundRecord(level));
    const rounds = records.filter(record => record.clears > 0).length;
    const medals = records.reduce((sum, record) => sum + record.medal, 0);
    const bosses = LEVELS.filter(level => level.boss && getRoundRecord(level).clears > 0).length;
    let chapters = 0;
    for (let chapter = 0; chapter < 5; chapter++) {
      const complete = LEVELS.slice(chapter * 10, chapter * 10 + 10)
        .every(level => getRoundRecord(level).clears > 0);
      if (complete) chapters++;
    }
    return { rounds, medals, bosses, chapters, finalRound:getRoundRecord(LEVELS[LEVELS.length - 1]).clears > 0 };
  }

  function isChapterComplete(chapterNumber) {
    return LEVELS.slice((chapterNumber - 1) * 10, chapterNumber * 10)
      .every(level => getRoundRecord(level).clears > 0);
  }

  function hallStats() {
    const records = LEVELS.map(level => getRoundRecord(level));
    return {
      rounds: records.filter(record => record.clears > 0).length,
      medals: records.reduce((sum, record) => sum + record.medal, 0),
      contractClears: records.reduce((sum, record) => sum + record.contractClears, 0),
      ruleClears: records.reduce((sum, record) => sum + record.ruleClears, 0),
      unlocked: bst.unlocked.filter(Boolean).length,
    };
  }

  function loadRosterUnlocks() {
    let saved = {};
    try {
      const data = window.BoohaAdventure?.save?.load?.();
      saved = data?.unlocks || {};
    } catch (e) {}
    try {
      const local = JSON.parse(window.localStorage?.getItem(ROSTER_UNLOCK_STORAGE_KEY) || '{}');
      saved = {...local, ...saved};
    } catch (e) {}
    bst.unlocked = ROSTER.map((booha, index) => index === 0 || !!saved[ROSTER_UNLOCK_KEY + booha.id]);
  }

  function persistRosterUnlock(index) {
    const booha = ROSTER[index];
    const item = { unlockedAt:Date.now(), source:'booha_destruction' };
    try {
      window.BoohaAdventure?.save?.patch?.('unlocks', { [ROSTER_UNLOCK_KEY + booha.id]:item });
    } catch (e) {}
    try {
      const local = JSON.parse(window.localStorage?.getItem(ROSTER_UNLOCK_STORAGE_KEY) || '{}');
      local[ROSTER_UNLOCK_KEY + booha.id] = item;
      window.localStorage?.setItem(ROSTER_UNLOCK_STORAGE_KEY, JSON.stringify(local));
    } catch (e) {}
  }

  function syncRosterUnlocks() {
    const progress = rosterProgress();
    const newlyUnlocked = [];
    ROSTER.forEach((booha, index) => {
      if (bst.unlocked[index] || !ROSTER_UNLOCKS[index]?.test) return;
      if (ROSTER_UNLOCKS[index].test(progress)) {
        bst.unlocked[index] = true;
        persistRosterUnlock(index);
        newlyUnlocked.push(booha);
      }
    });
    return newlyUnlocked;
  }

  function isBoohaUnlocked(index) { return !!bst.unlocked[index]; }

  function unlockRequirement(index) {
    const requirement = ROSTER_UNLOCKS[index];
    return requirement ? `${requirement.unlockEN} / ${requirement.unlockJP}` : 'Clear more rounds / もっとラウンドをクリア';
  }

  function nextRosterUnlock() {
    const index = ROSTER.findIndex((_, i) => i > 0 && !bst.unlocked[i]);
    if (index < 0) return null;
    return { index, booha:ROSTER[index], requirement:ROSTER_UNLOCKS[index] };
  }

  function recordRoundResult(level, score, contractComplete, ruleComplete, shotsUsed) {
    const key = String(level.id);
    const previous = getRoundRecord(level);
    const medal = medalForScore(level, score);
    const next = {
      best: Math.max(previous.best, Math.round(score)),
      medal: Math.max(previous.medal, medal),
      clears: previous.clears + 1,
      contractClears: previous.contractClears + (contractComplete ? 1 : 0),
      ruleClears: previous.ruleClears + (ruleComplete ? 1 : 0),
      bestShots: previous.bestShots && previous.bestShots <= shotsUsed
        ? previous.bestShots : shotsUsed,
    };
    roundRecords[key] = next;
    saveRoundRecords();
    return {
      ...next,
      isNewBest: score > previous.best,
      isNewFewestShots: !previous.bestShots || shotsUsed < previous.bestShots,
      medalUp: medal > previous.medal,
      medal,
      thresholds: medalThresholds(level),
    };
  }

  function contractProgress(level = currentLevel()) {
    const c = level.contract;
    if (!c) return '';
    if (c.maxShots != null) return `${gs.shotsUsed}/${c.maxShots} shots`;
    if (c.power) return gs.powerUsed.has(c.power) ? 'READY' : `NEED ${c.power.toUpperCase()}`;
    if (c.minCollapses != null) return `${Math.min(gs.collapseCount, c.minCollapses)}/${c.minCollapses} falls`;
    if (c.minPowers != null) return `${Math.min(gs.powerUsed.size, c.minPowers)}/${c.minPowers} powers`;
    return 'READY';
  }

  function currentRule() { return currentLevel().rule || null; }

  function ruleProgress(level = currentLevel()) {
    const rule = level.rule;
    if (!rule) return '';
    if (rule.type === 'time_attack') return `${Math.ceil(Math.max(0, gs.ruleTime))}s left`;
    if (rule.type === 'spotlight') return gs.powerUsed.has(rule.power) ? 'READY' : `NEED ${rule.power.toUpperCase()}`;
    if (rule.type === 'marked_target') {
      const target = gs.blocks[gs.markedTargetIndex];
      return target && target.broken ? 'BROKEN' : 'GLOWING';
    }
    return 'READY';
  }

  function evaluateRule() {
    const rule = currentRule();
    if (!rule) return { complete:false, bonus:0, label:'' };
    let complete = false;
    if (rule.type === 'time_attack') complete = !gs.ruleFailed;
    if (rule.type === 'spotlight') complete = gs.powerUsed.has(rule.power);
    if (rule.type === 'marked_target') complete = !!gs.blocks[gs.markedTargetIndex]?.broken;
    gs.ruleComplete = complete;
    gs.ruleBonus = complete ? (rule.bonus || 0) : 0;
    return { ...rule, complete, bonus:gs.ruleBonus };
  }

  function ruleResultText(rule) {
    if (!rule) return '';
    return rule.complete
      ? `◆ CHALLENGE EARNED · ${rule.label} +${scoreText(rule.bonus)}`
      : `◆ CHALLENGE TO TRY · ${rule.label}`;
  }

  function evaluateContract(shotsLeft) {
    const contract = currentLevel().contract;
    if (!contract) return { complete:false, bonus:0, label:'NO CONTRACT' };
    const checks = [];
    if (contract.maxShots != null) checks.push(gs.shotsUsed <= contract.maxShots);
    if (contract.power) checks.push(gs.powerUsed.has(contract.power));
    if (contract.minCollapses != null) checks.push(gs.collapseCount >= contract.minCollapses);
    if (contract.minPowers != null) checks.push(gs.powerUsed.size >= contract.minPowers);
    const complete = checks.every(Boolean);
    gs.contractComplete = complete;
    gs.contractBonus = complete ? (contract.bonus || 0) : 0;
    return {
      ...contract,
      complete,
      bonus: gs.contractBonus,
      shotsLeft,
    };
  }

  function contractResultText(contract) {
    if (!contract || contract.label === 'NO CONTRACT') return '';
    return contract.complete
      ? `✦ BONUS EARNED · ${contract.label} +${scoreText(contract.bonus)}`
      : `✦ BONUS TO TRY · ${contract.label}`;
  }

  function readHighScore() {
    try {
      const scores = window.BoohaScoreSystem ||
        (window.BoohaAdventure && BoohaAdventure.scores);
      return scores && typeof scores.getHighScore === 'function'
        ? scores.getHighScore(GAME_ID) || 0 : 0;
    } catch (e) { return 0; }
  }

  function adaptPerformance(frameMs, updateMs=0, renderMs=0) {
    PERF.frameMs = PERF.frameMs ? PERF.frameMs * 0.85 + frameMs * 0.15 : frameMs;
    PERF.updateMs = PERF.updateMs ? PERF.updateMs * 0.85 + updateMs * 0.15 : updateMs;
    PERF.renderMs = PERF.renderMs ? PERF.renderMs * 0.85 + renderMs * 0.15 : renderMs;
    const pressureMs = Math.max(PERF.frameMs, PERF.updateMs + PERF.renderMs);

    if (pressureMs > 24 || renderMs > 14) {
      PERF.slowFrames++;
      PERF.fastFrames = 0;
    } else if (pressureMs < 17 && renderMs < 10) {
      PERF.fastFrames++;
      PERF.slowFrames = 0;
    } else {
      PERF.slowFrames = 0;
      PERF.fastFrames = 0;
    }

    if (PERF.slowFrames >= 8) {
      PERF.fxScale = Math.max(0.30, PERF.fxScale - 0.10);
      PERF.qualityChanges++;
      trimFX();
      PERF.slowFrames = 0;
    } else if (PERF.fastFrames >= 75) {
      PERF.fxScale = Math.min(PERF.targetScale, PERF.fxScale + 0.06);
      PERF.qualityChanges++;
      PERF.fastFrames = 0;
    }
  }

  function beginCampaign() {
    gs.runScore = 0;
    gs.roundScore = 0;
    gs.lives = MAX_RUN_LIVES;
    gs.combo = 0;
    gs.lastScoreIsBest = false;
    gs.nearMiss = false;
    gs.runStartedAt = performance.now();
    gs.campaignActive = true;
    gs.campaignComplete = false;
  }

  function submitRunScore(completed) {
    if (!gs.campaignActive) return null;
    const score = Math.max(0, Math.round(gs.runScore));
    const elapsed = gs.runStartedAt ? Math.max(0, performance.now() - gs.runStartedAt) : null;
    let result = null;
    try {
      const scores = window.BoohaScoreSystem ||
        (window.BoohaAdventure && BoohaAdventure.scores);
      if (scores && typeof scores.submit === 'function' && (score > 0 || completed)) {
        result = scores.submit(GAME_ID, score, { completed, time: elapsed });
        gs.highScore = Math.max(gs.highScore, scores.getHighScore(GAME_ID) || score);
        gs.lastScoreIsBest = !!(result && result.isHighScore);
      }
    } catch (e) {
      console.warn('[Booha Destruction] Score could not be saved:', e);
    }
    gs.campaignActive = false;
    gs.campaignComplete = !!completed;
    return result;
  }

  function awardRoundScore(shotsLeft, contract, rule) {
    gs.combo++;
    gs.comboPulse=1;
    const destruction = Math.round(gs.pct * 8);
    const shotBonus = shotsLeft * 140;
    const contractBonus = contract && contract.complete ? contract.bonus : 0;
    const ruleBonus = rule && rule.complete ? rule.bonus : 0;
    const bossBonus = currentLevel().boss ? (currentLevel().bossBonus || 0) : 0;
    const comboMultiplier = 1 + Math.min(1.5, (gs.combo - 1) * 0.08);
    gs.roundMultiplier = comboMultiplier;
    gs.roundShotBonus = shotBonus;
    gs.roundDestructionScore = destruction;
    gs.roundScore = Math.round((1000 + destruction + shotBonus + contractBonus + ruleBonus + bossBonus) * comboMultiplier);
    gs.runScore += gs.roundScore;
  }

  function offscreen(x, y, r=0) {
    return x + r < -20 || x - r > W + 20 || y + r < -20 || y - r > H + 100;
  }

  function hexRGB(hex) {
    const h = hex.replace('#','');
    return h.length === 3
      ? [parseInt(h[0]+h[0],16), parseInt(h[1]+h[1],16), parseInt(h[2]+h[2],16)]
      : [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
  }
  function lighten(hex,a){ const[r,g,b]=hexRGB(hex); return `rgb(${clamp((r+a*255)|0,0,255)},${clamp((g+a*255)|0,0,255)},${clamp((b+a*255)|0,0,255)})`; }
  function darken(hex,a){ return lighten(hex,-a); }

  // ── Material palette ────────────────────────────────
  const MAT = {
    wood:  {base:'#c8895a',mid:'#96532c',dark:'#5e2e10',edge:'#e8a870',spark:'#f0b870',chip:'#d49050',grain:true},
    stone: {base:'#8a939f',mid:'#626b76',dark:'#3d4450',edge:'#b0bac5',spark:'#ccd4de',chip:'#9aaab8',grain:false},
    glass: {base:'#b7ecff',mid:'#70caee',dark:'#3898bb',edge:'#e0f8ff',spark:'#e8faff',chip:'#a0d8ef',grain:false},
    soft:  {base:'#f8c0e0',mid:'#e080b8',dark:'#b04080',edge:'#ffddee',spark:'#ffd0ec',chip:'#eeaad0',grain:false},
    ice:   {base:'#d0f8ff',mid:'#80d8f8',dark:'#3898cc',edge:'#eeffff',spark:'#ccf8ff',chip:'#a0e8f8',grain:false},
    fire:  {base:'#ff9944',mid:'#cc5500',dark:'#882200',edge:'#ffbb66',spark:'#ffcc44',chip:'#ff8833',grain:false},
  };
 // ── Resist glow colours (per power) ─────────────────
  const RESIST_COLORS = {
    fire:     '#ff4400',
    ice:      '#00ccff',
    heavy:    '#ffaa00',
    rock:     '#888888',
    rainbow:  '#88ff44',
    ultimate: '#ff00ff',
  };


   
  function matFill(block) {
    if (block.frozen) return '#b8f0ff';
    const m = MAT[block.material] || MAT.wood;
    if (!block.maxHp || block.maxHp <= 1) return m.base;
    const r = clamp(block.hp / block.maxHp, 0, 1);
    return r > 0.66 ? m.base : r > 0.33 ? m.mid : m.dark;
  }

  // ── Image loader ────────────────────────────────────
  const imagePromises = new Map();
  function loadImg(src) {
    if (!src) return Promise.resolve(null);
    if (imagePromises.has(src)) return imagePromises.get(src);
    const promise = new Promise(res => {
      const img = new Image();
      img.decoding = 'async';
      img.onload = () => res(img); img.onerror = () => res(null); img.src = src;
    });
    imagePromises.set(src, promise);
    return promise;
  }
  async function ensureRosterImage(index) {
    if (bst.imgs[index]) return bst.imgs[index];
    const img = await loadImg(ROSTER[index]?.img);
    bst.imgs[index] = img;
    return img;
  }
  async function ensureRosterThumb(index) {
    if (bst.thumbs[index]) return bst.thumbs[index];
    const img = await loadImg(ROSTER[index]?.thumb || ROSTER[index]?.img);
    bst.thumbs[index] = img;
    return img;
  }
  async function preload() {
    const bgPromise = loadImg(ASSETS.bg);
    // The selector is visible as soon as a round starts, so every available
    // Booha needs to be ready before the first frame. Lazy loading here made
    // the roster look like broken placeholders on fast transitions.
    const rosterPromise = Promise.all(ROSTER.map((_, index) => Promise.all([
      ensureRosterImage(index), ensureRosterThumb(index)
    ])));
    gs.imgs.bg = await bgPromise;
    await rosterPromise;
    preloadAudio();
    buildBackgroundCache();
  }

  function maybeReachGoal() {
    const target = currentLevel().targetPercent || 100;
    if (gs.phase !== P.PLAY || gs.goalReached || gs.pct < target) return;
    gs.goalReached = true;
    setToast('GOAL REACHED! / クリア!', '#ffe66d', 1400);
    addShake(3);
    // Let the final break and collapse read for a beat, then resolve the
    // round. Previously 100% looked inert until the shot happened to settle.
    queueNextRound(() => finishShot(), 700);
  }

  // ── Audio helpers ────────────────────────────────────
  function sndPull()   { if (gs.pullPlayed) return; gs.pullPlayed = true; playSFX(AUDIO.pull, 0.5, 0.98+rnd()*0.06, 'pull', 90, 1); }
  function sndLaunch() {
    playSFX(AUDIO.launch, 0.88, 0.98+rnd()*0.06, 'launch', 120, 2);
    const r = ROSTER[bst.sel];
    if (!r) return;
    const playVoice = () => playBuffer(r.id, 0.85);
    if (audioBuffers[r.id]) playVoice();
    else loadBuffer(r.id, r.sfx).then(() => { if (audioBuffers[r.id]) playVoice(); });
  }
  function sndHit(mat, spd) {
    const now = performance.now(); if (now - gs.lastHit < HIT_COOL) return;
    gs.lastHit = now;
    const src = mat==='stone'?AUDIO.stone : mat==='glass'?AUDIO.glass : mat==='soft'?AUDIO.soft : AUDIO.wood;
    const volMult = gs.booha?.power === 'monster' ? Math.min(2, 1 + gs.bounces * 0.15) : 1;
    playSFX(src, Math.max(0.2, Math.min(1, spd/14)) * volMult, 0.92+rnd()*0.18, 'hit', HIT_COOL, 1);
    gs.flash = Math.max(gs.flash, spd > 12 ? 0.72 : 0.42);
  }
  function sndBreak() { playSFX(AUDIO.break, 0.95, 0.94+rnd()*0.08, 'break', 110, 2); }
  function sndRub()   { playSFX(AUDIO.rubble, 0.48, 0.98+rnd()*0.08, 'rubble', 260, 1); }
  function sndGnd(s)  { if (s < 12) return; playSFX(AUDIO.ground, Math.min(0.72, s/28), 0.96+rnd()*0.08, 'ground', 170, 1); }
  function sndWin()   { playSFX(AUDIO.win,  1, 1, 'win', 300, 3); }
  function sndFail()  { playSFX(AUDIO.fail, 0.85, 1, 'fail', 300, 3); }
  function sndUnlock() {
    [0, 120, 250].forEach((delay, index) => {
      setTimeout(() => synthPop(520 + index * 160, 0.25, 0.1), delay);
    });
  }

  // ── FX Spawners ──────────────────────────────────────
  function spawnSparks(x, y, mat, spd, n=8) {
    const m = MAT[mat] || MAT.wood;
    for (let i = 0; i < burstCount(n); i++) {
      const a = rnd(0, Math.PI*2), mag = rnd(1.5, Math.min(12, spd*0.7)), chip = mat!=='glass' && rnd()<0.4;
      pushCapped(sparks, CAP.sparks, {x, y, vx:Math.cos(a)*mag, vy:Math.sin(a)*mag-rnd(0,3),
        life:1, r:chip?rnd(2.5,5):rnd(1,2.5), col:rnd()<0.5?m.spark:m.chip,
        type:chip?'chip':'dot', grav:chip?0.28:0.12, rot:rnd(0,Math.PI*2), rotV:rnd(-0.2,0.2)});
    }
  }
  function spawnGlass(x, y, w, h) {
    for (let i = 0, n = burstCount(10+~~rnd(0,8), 4); i < n; i++) {
      const a = rnd(0,Math.PI*2), mag = rnd(3,14);
      pushCapped(sparks, CAP.sparks, {x:x+rnd(-w*0.4,w*0.4), y:y+rnd(-h*0.4,h*0.4),
        vx:Math.cos(a)*mag, vy:Math.sin(a)*mag-rnd(1,5),
        life:1, r:rnd(4,12), col:'#b7ecff', type:'shard', grav:0.32,
        rot:rnd(0,Math.PI*2), rotV:rnd(-0.35,0.35), alpha:0.85});
    }
  }
  function spawnIce(x, y, w, h) {
    for (let i = 0; i < burstCount(14, 5); i++) {
      const a = rnd(0,Math.PI*2), mag = rnd(2,9);
      pushCapped(sparks, CAP.sparks, {x:x+rnd(-w*0.3,w*0.3), y:y+rnd(-h*0.3,h*0.3),
        vx:Math.cos(a)*mag, vy:Math.sin(a)*mag-rnd(0,4),
        life:1, r:rnd(3,10), col:pick(['#aaeeff','#ddf8ff','#88ddff','#ffffff']), type:'shard', grav:0.25,
        rot:rnd(0,Math.PI*2), rotV:rnd(-0.3,0.3), alpha:0.9});
    }
  }
  function spawnDust(x, y)          { pushCapped(dusts, CAP.dusts, {x, y, r:4, maxR:rnd(28,48), life:1}); }
  function spawnWave(x, y, col, maxR=60) { pushCapped(waves, CAP.waves, {x, y, r:4, maxR, life:1, col}); }
  function spawnScorch(x, y) {
    pushCapped(scorchMarks, CAP.scorchMarks, {x, y, r:rnd(12,22), life:1, decay:0.005});
  }
  function addShake(v) { shake.v = Math.max(shake.v, v); }
  function spawnImpact(x, y, col='#ffffff', spd=8, kind='hit') {
    const breakHit = kind === 'break' || kind === 'break-weak' || kind === 'collapse';
    const weakHit = kind === 'weak' || kind === 'break-weak';
    pushCapped(impactBursts, CAP.impactBursts, {
      x, y, r:Math.max(3, spd * 0.45),
      maxR:breakHit ? Math.min(92, 38 + spd * 2.4) : kind === 'immune' ? 42 : weakHit ? Math.min(72, 32 + spd * 1.8) : Math.min(58, 24 + spd * 1.5),
      life:1, decay:breakHit ? 0.095 : 0.16,
      col:weakHit ? '#ffcf70' : col, thick:breakHit ? 4 : weakHit ? 4 : kind === 'immune' ? 2.5 : 3,
      kind, weak:weakHit,
    });
  }
  function spawnRingCrack(x, y) {
    pushCapped(waves, CAP.waves, {x, y, r:2, maxR:55, life:1, col:'#ffffff', thick:3});
    pushCapped(waves, CAP.waves, {x, y, r:4, maxR:38, life:1, col:'#aaeeff', thick:2});
  }

  function spawnEmber(x, y) {
    pushCapped(sparks, CAP.sparks, {x, y, vx:rnd(-1.5,1.5), vy:rnd(-2.5,-0.5), life:1, r:rnd(2,5),
      col:pick(['#ff6600','#ff9900','#ffcc00','#ff3300']), type:'dot', grav:0.05+rnd()*0.04,
      rot:0, rotV:0, decay:rnd(0.025,0.05)});
  }
  function spawnRainbow(x, y) {
    const hue = (performance.now()*0.3) % 360;
    pushCapped(sparks, CAP.sparks, {x, y, vx:rnd(-0.3,0.3), vy:rnd(-0.2,0.1), life:1, r:rnd(4,9),
      col:`hsl(${hue},100%,70%)`, type:'dot', grav:0.02, rot:0, rotV:0, decay:rnd(0.012,0.022)});
  }
  function spawnTeleport(x, y) {
    for (let i = 0; i < burstCount(30, 8); i++) {
      const a = rnd(0,Math.PI*2), mag = rnd(5,22);
      pushCapped(sparks, CAP.sparks, {x, y, vx:Math.cos(a)*mag, vy:Math.sin(a)*mag, life:1,
        r:rnd(3,9), col:pick(['#550088','#bb00ff','#ff00ff','#220033']), type:'dot', grav:0.15, rot:0, rotV:0});
    }
    pushCapped(waves, CAP.waves, {x, y, r:10, maxR:100, life:1, col:'#bb00ff'});
    addShake(8);
  }

// ── CLANG labels ─────────────────────────────────────
  const clangLabels = [];

  function spawnClangLabel(x, y) {
    clangLabels.push({
      x, y: y - 20,
      vy: -1.2,
      life: 1,
      text: pick(['CLANG!', 'NOPE!', 'IMMUNE!']),
    });
  }

  function updateClangLabels() {
    for (let i = clangLabels.length - 1; i >= 0; i--) {
      const c = clangLabels[i];
      c.y += c.vy;
      c.vy *= 0.92;
      c.life -= 0.028;
      if (c.life <= 0) clangLabels.splice(i, 1);
    }
  }

  function drawClangLabels() {
    for (const c of clangLabels) {
      ctx.save();
      ctx.globalAlpha = clamp(c.life, 0, 1);
      ctx.font = 'bold 18px system-ui,sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.strokeStyle = 'rgba(0,0,0,0.6)';
      ctx.lineWidth = 4;
      ctx.strokeText(c.text, c.x, c.y);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(c.text, c.x, c.y);
      ctx.restore();
    }
  }



   
  function spawnDetonation(x, y) {
    for (let i = 0; i < burstCount(80, 16); i++) {
      const a = rnd(0,Math.PI*2), mag = rnd(8,32);
      pushCapped(sparks, CAP.sparks, {x, y, vx:Math.cos(a)*mag, vy:Math.sin(a)*mag-rnd(0,5), life:1,
        r:rnd(4,14), col:pick(['#ff0088','#ff8800','#ffff00','#00ffaa','#0088ff','#cc00ff']),
        type:'dot', grav:0.2, rot:rnd(0,Math.PI*2), rotV:rnd(-0.3,0.3)});
    }
    [60,90,130].forEach(maxR => pushCapped(waves, CAP.waves, {x, y, r:4, maxR, life:1, col:'#ffffff'}));
    addShake(16);
  }
  function spawnChipTrail(x, y, vx, vy) {
    const ang = Math.atan2(-vy, -vx);
    for (let i = 0; i < 2; i++) {
      const spread = rnd(-0.8, 0.8);
      pushCapped(sparks, CAP.sparks, {x, y,
        vx:Math.cos(ang+spread)*rnd(2,7), vy:Math.sin(ang+spread)*rnd(2,7),
        life:1, r:rnd(1.5,4), col:pick(['#9ab','#cde','#678','#aaa']),
        type:'chip', grav:0.3, rot:rnd(0,Math.PI*2), rotV:rnd(-0.3,0.3), decay:rnd(0.04,0.07)});
    }
  }
  function spawnHeavyDust(x, y) {
    pushCapped(dusts, CAP.dusts, {x:x+rnd(-8,8), y, r:rnd(3,7), maxR:rnd(12,20), life:0.7, falling:true, vy:rnd(1,3)});
  }
  function spawnIceVapor(x, y) {
    pushCapped(sparks, CAP.sparks, {x, y:y+rnd(-4,4), vx:rnd(-1,1), vy:rnd(-1.5,-0.2),
      life:0.6, r:rnd(4,9), col:pick(['#d0f8ff','#aaeeff','#ffffff']),
      type:'dot', grav:-0.02, rot:0, rotV:0, decay:rnd(0.025,0.05), alpha:0.5});
  }
  function spawnGhostTrail(x, y, ri) {
    pushCapped(sparks, CAP.sparks, {x, y, vx:0, vy:0, life:0.55, r:B_RADIUS*1.4,
      col:'#9900ff', type:'ghost', grav:0, rot:0, rotV:0, decay:rnd(0.04,0.07), ri});
  }

  // ── v4: Trait / resist helpers ───────────────────────
  function hasTrait(block, trait) {
    return Array.isArray(block.traits) && block.traits.includes(trait);
  }

  function getResist(block, power) {
    return block.resist && typeof block.resist[power] === 'number'
      ? block.resist[power]
      : 1;
  }

  // Returns true if the hit/effect should be fully blocked.
  // mode: 'hit' | 'burn' | 'freeze' | 'convert'
  function powerBlocked(block, power, mode='hit') {
    if (!block) return false;
    if (mode === 'burn'    && hasTrait(block, 'burnimmune'))    return true;
    if (mode === 'freeze'  && hasTrait(block, 'freezeimmune')) return true;
    if (mode === 'convert' && hasTrait(block, 'convertimmune')) return true;

    if (mode === 'hit') {
      if (power === 'fire'      && hasTrait(block, 'fireproof'))     return true;
      if (power === 'ultimate'  && hasTrait(block, 'ultimateproof')) return true;
      if (power === 'ice'       && hasTrait(block, 'iceproof'))      return true;
      if (power === 'heavy'     && hasTrait(block, 'heavyproof'))    return true;
      if (power === 'rock'      && hasTrait(block, 'rockproof'))     return true;
      if (power === 'rainbow'   && hasTrait(block, 'rainbowproof'))  return true;
    }
    return false;
  }

  // Returns a colour to tint the block border based on its dominant trait.
  // Used by drawBlocks() for visual teaching.
function traitGlowColor(block) {
    if (!block.traits || !block.traits.length) {
      // Resist-only blocks: pick color based on strongest resist key
      if (block.resist) {
        const keys = Object.keys(block.resist);
        if (!keys.length) return null;
        // Lowest value = strongest resistance
        const dominant = keys.reduce((a, b) => block.resist[a] <= block.resist[b] ? a : b);
        return RESIST_COLORS[dominant] || '#dddddd';
      }
      return null;
    }
    if (hasTrait(block, 'ultimateproof')) return '#ff00ff';
    if (hasTrait(block, 'fireproof'))     return '#ff4400';
    if (hasTrait(block, 'iceproof'))      return '#00ccff';
    if (hasTrait(block, 'heavyproof'))    return '#ffaa00';
    if (hasTrait(block, 'rockproof'))     return '#888888';
    if (hasTrait(block, 'rainbowproof'))  return '#88ff44';
    if (hasTrait(block, 'burnimmune'))    return '#ff6600';
    if (hasTrait(block, 'freezeimmune'))  return '#aaddff';
    if (hasTrait(block, 'convertimmune')) return '#ccff88';
    // Has traits but none matched above — fall back to resist dominant
    if (block.resist) {
      const keys = Object.keys(block.resist);
      if (keys.length) {
        const dominant = keys.reduce((a, b) => block.resist[a] <= block.resist[b] ? a : b);
        return RESIST_COLORS[dominant] || '#dddddd';
      }
    }
    return '#dddddd';
  }

  function traitBadge(block) {
    if (hasTrait(block, 'ultimateproof')) return 'ULT';
    if (hasTrait(block, 'fireproof')) return 'FIRE';
    if (hasTrait(block, 'iceproof')) return 'ICE';
    if (hasTrait(block, 'heavyproof')) return 'HEAVY';
    if (hasTrait(block, 'rockproof')) return 'ROCK';
    if (hasTrait(block, 'rainbowproof')) return 'RAINBOW';
    if (hasTrait(block, 'burnimmune')) return 'BURN';
    if (hasTrait(block, 'freezeimmune')) return 'FREEZE';
    if (hasTrait(block, 'convertimmune')) return 'CONVERT';
    if (block.resist) {
      const keys = Object.keys(block.resist);
      if (keys.length) {
        const dominant = keys.reduce((a, b) => block.resist[a] <= block.resist[b] ? a : b);
        return dominant.toUpperCase();
      }
    }
    return '';
  }
  // ── Death explosions ─────────────────────────────────
  function triggerDeathExplosion(b) {
    const x = b.x, y = b.y, power = b.power, ri = b.ri;
    const isLast  = gs.isLastBooha;
    const scale   = (isLast ? 1.6 : 1) * BURST_SCALE;
    const token   = gs.roundToken;

    switch (power) {
      case 'heavy': {
        addShake(10 * scale);
        for (let i = 0; i < ~~(55 * scale); i++) {
          const ang = rnd(-Math.PI, 0), mag = rnd(3,15);
          pushCapped(confetti, CAP.confetti, {
            x:x+rnd(-20,20), y, vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag-rnd(2,8),
            life:1, decay:rnd(0.004,0.01), r:rnd(8,18),
            col:pick(['#f60','#f90','#fc0','#f40','#5a3010','#888']),
            sh:pick(['chunk','rect']), grav:rnd(0.5,0.9), bounce:0.45, bounced:false,
            rot:rnd(0,Math.PI*2), rotV:rnd(-0.08,0.08),
            wob:0, wobS:0, wobA:0, pls:0, plsS:0,
            sticky:rnd()<0.35, dustOnLand:true,
          });
        }
        pushCapped(waves, CAP.waves, {x, y:FLOOR_Y, r:4, maxR:90*scale, life:1, col:'#cc5500'});
        spawnDust(x-30,FLOOR_Y); spawnDust(x,FLOOR_Y); spawnDust(x+30,FLOOR_Y);
        break;
      }
      case 'ice': {
        addShake(7 * scale);
        for (let i = 0; i < ~~(60 * scale); i++) {
          const ang = rnd(-Math.PI, 0), mag = rnd(4,14);
          pushCapped(confetti, CAP.confetti, {
            x:x+rnd(-12,12), y, vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag,
            life:1, decay:rnd(0.002,0.006), r:rnd(5,14),
            col:pick(['#aef','#dff','#8df','#fff','#bcf','#6df']), sh:'crystal',
            grav:0.02, gravRamp:0.005, gravDelay:60, gravDelayT:0, dropGrav:0.55,
            rot:rnd(0,Math.PI*2), rotV:rnd(-0.15,0.15),
            wob:0, wobS:0, wobA:0, pls:0, plsS:0, bounce:0.2, bounced:false,
          });
        }
        gs.flash = 1.4;
        spawnRingCrack(x, y);
        break;
      }
      case 'fire': {
        addShake(8 * scale);
        for (let i = 0; i < ~~(80 * scale); i++) {
          const ang = rnd(-Math.PI, 0), mag = rnd(5,18);
          const dmgEnabled = rnd() < 0.4;
          const dc = {
            x:x+rnd(-15,15), y, vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag-rnd(1,4),
            life:1, decay:rnd(0.006,0.015), r:rnd(3,9),
            col:pick(['#f22','#f70','#fa0','#fe0','#f50']), sh:'flame',
            grav:rnd(0.04,0.1), rot:rnd(0,Math.PI*2), rotV:rnd(-0.3,0.3),
            wob:rnd(0,Math.PI*2), wobS:rnd(0.08,0.16), wobA:rnd(1,3),
            pls:rnd(0,Math.PI*2), plsS:rnd(0.15,0.25),
            bounce:0.3, bounced:false, hitOnce:false, power:'fire',
          };
          if (dmgEnabled) pushCapped(gs.damageConfetti, CAP.damageConfetti, dc);
          else            pushCapped(confetti, CAP.confetti, dc);
        }
        spawnScorch(x, y);
        pushCapped(waves, CAP.waves, {x, y, r:4, maxR:75*scale, life:1, col:'#ff6600'});
        break;
      }
      case 'princess': {
        addShake(4 * scale);
        for (let i = 0; i < ~~(70 * scale); i++) {
          const spread = rnd(-0.9,0.9), floatSpd = rnd(2.5,8);
          pushCapped(confetti, CAP.confetti, {
            x:x+rnd(-25,25), y, vx:spread*rnd(1,4), vy:-floatSpd,
            life:1, decay:rnd(0.008,0.016), r:rnd(5,12),
            col:pick(['#f8c','#fae','#c4a','#fde','#fff','#fbd','#ff88aa']), sh:'heart',
            grav:-0.04, gravRamp:0,
            rot:rnd(0,Math.PI*2), rotV:rnd(-0.12,0.12),
            wob:rnd(0,Math.PI*2), wobS:rnd(0.05,0.1), wobA:rnd(1,2.5),
            pls:rnd(0,Math.PI*2), plsS:rnd(0.12,0.22),
            popAt:rnd(0.4,0.75), popped:false,
          });
        }
        pushCapped(waves, CAP.waves, {x, y, r:4, maxR:55*scale, life:1, col:'#ff88cc'});
        break;
      }
      case 'rainbow': {
        addShake(7 * scale);
        const hues = [0, 30, 60, 120, 200, 270, 320];
        hues.forEach((h, i) => {
          setTimeout(() => {
            if (gs.roundToken !== token) return;
            pushCapped(waves, CAP.waves, {x, y, r:4, maxR:(80+i*12)*scale, life:1, col:`hsl(${h},100%,65%)`, thick:5-i*0.5});
          }, i * 18);
        });
        setTimeout(() => {
          if (gs.roundToken !== token) return;
          const cnt = ~~(90 * scale);
          for (let i = 0; i < cnt; i++) {
            const ang = rnd(-Math.PI, 0), mag = rnd(6,16), hue = rnd(0,360);
            const dc = {
              x:x+rnd(-18,18), y, vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag-rnd(2,6),
              life:1, decay:rnd(0.007,0.016), r:rnd(4,11),
              col:`hsl(${hue},100%,65%)`, sh:pick(['sparkle','star','crystal']),
              grav:rnd(0.12,0.22), rot:rnd(0,Math.PI*2), rotV:rnd(-0.2,0.2),
              wob:rnd(0,Math.PI*2), wobS:rnd(0.06,0.14), wobA:rnd(0.5,2.5),
              pls:rnd(0,Math.PI*2), plsS:rnd(0.12,0.22),
              damaging:rnd()<0.25, hitOnce:false, bounce:0.25, bounced:false,
            };
            if (dc.damaging) pushCapped(gs.damageConfetti, CAP.damageConfetti, dc);
            else             pushCapped(confetti, CAP.confetti, dc);
          }
        }, 130);
        break;
      }
      case 'nightmare': {
        gs.nightmareFlicker = true;
        gs.nightmareFlickerTimer = 45;
        setTimeout(() => {
          if (gs.roundToken !== token) return;
          gs.nightmareFlicker = false;
          gs.flash = 1.8;
          addShake(9 * scale);
          const bx = gs.blocks.filter(bl => !bl.broken).map(bl => bl.x);
          const spawnX = bx.length ? Math.max(...bx) + 40 : W * 0.75;
          const spawnY = FLOOR_Y - 80;
          for (let i = 0; i < ~~(70 * scale); i++) {
            const ang = rnd(-Math.PI*0.9, -Math.PI*0.1), mag = rnd(5,18);
            pushCapped(confetti, CAP.confetti, {
              x:spawnX+rnd(-20,20), y:spawnY,
              vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag,
              life:1, decay:rnd(0.007,0.016), r:rnd(4,12),
              col:pick(['#508','#80c','#b0f','#d4f','#304','#f0f','#fff']),
              sh:pick(['shard','star','sparkle']), grav:rnd(0.14,0.28),
              rot:rnd(0,Math.PI*2), rotV:rnd(-0.2,0.2),
              wob:rnd(0,Math.PI*2), wobS:rnd(0.06,0.14), wobA:rnd(0.5,2.5),
              pls:rnd(0,Math.PI*2), plsS:rnd(0.12,0.22),
              bounce:0.25, bounced:false,
            });
          }
          spawnTeleport(spawnX, spawnY);
          celebPops(300);
        }, 480);
        return;
      }
      case 'monster': {
        const stages = [
          {delay:0,   count:20, magMax:10, rMax:8,  shakeV:5},
          {delay:180, count:35, magMax:18, rMax:13, shakeV:9},
          {delay:380, count:~~(60*scale), magMax:28, rMax:20, shakeV:14},
        ];
        stages.forEach(({delay, count, magMax, rMax, shakeV}) => {
          setTimeout(() => {
            if (gs.roundToken !== token) return;
            addShake(shakeV);
            for (let i = 0; i < count; i++) {
              const ang = rnd(-Math.PI,0), mag = rnd(3, magMax);
              pushCapped(confetti, CAP.confetti, {
                x:x+rnd(-20,20), y,
                vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag-rnd(1,5),
                life:1, decay:rnd(0.006,0.014), r:rnd(4, rMax),
                col:pick(['#0c4','#4f8','#cf0','#0f6','#3a0','#8f0','#44ff88']),
                sh:pick(['chunk','circle','sparkle']), grav:rnd(0.18,0.32),
                rot:rnd(0,Math.PI*2), rotV:rnd(-0.2,0.2),
                wob:rnd(0,Math.PI*2), wobS:rnd(0.06,0.14), wobA:rnd(0.5,2.5),
                pls:rnd(0,Math.PI*2), plsS:rnd(0.12,0.22),
                bounce:0.35, bounced:false,
              });
            }
            pushCapped(waves, CAP.waves, {x, y, r:4, maxR:(50+count)*scale, life:1, col:'#44ff88'});
            synthPop(200+delay*0.5, 0.3, 0.12);
          }, delay);
        });
        break;
      }
      case 'ultimate': {
        addShake(18 * scale);
         
        gs.blocks.forEach((block, idx) => {
        if (block.broken) return;
        if (dist(x, y, block.x, block.y) > 220) return;
        if (powerBlocked(block, 'ultimate', 'hit')) return;
        if (block.hp >= block.maxHp && !block.falling) return;
           
          const m = MAT[block.material] || MAT.wood;
          const cnt = ~~(rnd(8,18));
          for (let i = 0; i < cnt; i++) {
            const ang = rnd(0, Math.PI*2), mag = rnd(4,16);
            const dc = {
              x:block.x+rnd(-block.w*0.5,block.w*0.5),
              y:block.y+rnd(-block.h*0.5,block.h*0.5),
              vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag-rnd(1,6),
              life:1, decay:rnd(0.006,0.014), r:rnd(4,12),
              col:pick([m.base,m.mid,m.spark,m.chip]),
              sh:pick(['chunk','shard','rect','sparkle']), grav:rnd(0.15,0.3),
              rot:rnd(0,Math.PI*2), rotV:rnd(-0.25,0.25),
              wob:rnd(0,Math.PI*2), wobS:rnd(0.06,0.14), wobA:rnd(0.5,2),
              pls:rnd(0,Math.PI*2), plsS:rnd(0.12,0.22),
              damaging:true, hitOnce:false, bounce:0.28, bounced:false, power:'ultimate',
            };
            pushCapped(gs.damageConfetti, CAP.damageConfetti, dc);
          }
          damageBlock(block, block.hp, block.x, block.y, 20, idx, false, 'ultimate');
        });
        gs.pct = (gs.brokenBlocks / gs.totalBlocks) * 100;
        const cnt2 = ~~(130 * scale);
        for (let i = 0; i < cnt2; i++) {
          const ang = rnd(-Math.PI,0), mag = rnd(8,26);
          pushCapped(confetti, CAP.confetti, {
            x:x+rnd(-30,30), y, vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag-rnd(2,8),
            life:1, decay:rnd(0.005,0.013), r:rnd(5,16),
            col:pick(['#f08','#f80','#ff0','#0fa','#08f','#c0f','#f48','#4fc','#fff']),
            sh:pick(['star','heart','crystal','sparkle','flame']), grav:rnd(0.14,0.26),
            rot:rnd(0,Math.PI*2), rotV:rnd(-0.25,0.25),
            wob:rnd(0,Math.PI*2), wobS:rnd(0.06,0.14), wobA:rnd(0.5,2.5),
            pls:rnd(0,Math.PI*2), plsS:rnd(0.12,0.22),
            bounce:0.3, bounced:false,
          });
        }
        spawnDetonation(x, y);
        celebPops(700);
        break;
      }
      default: {
        const r2 = ROSTER[ri], cfg = r2.conf;
        const cnt = ~~(cfg.burst * scale);
        for (let i = 0; i < cnt; i++) {
          const ang = rnd(-Math.PI,0), mag = rnd(4,16);
          pushCapped(confetti, CAP.confetti, {
            x:x+rnd(-20,20), y, vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag-rnd(2,7),
            life:1, decay:rnd(0.008,0.018), r:rnd(cfg.sz[0], cfg.sz[1]),
            col:pick(cfg.cols), sh:pick(cfg.sh), grav:rnd(0.14,0.28),
            rot:rnd(0,Math.PI*2), rotV:cfg.spin?rnd(-0.2,0.2):0,
            wob:rnd(0,Math.PI*2), wobS:rnd(0.06,0.14), wobA:rnd(0.5,2.5),
            pls:rnd(0,Math.PI*2), plsS:rnd(0.12,0.22),
            bounce:rnd(0.2,0.45), bounced:false,
          });
        }
        addShake(6 * scale);
      }
    }
    if (power !== 'nightmare' && power !== 'monster') {
      celebPops(power==='princess'?500 : power==='ultimate'?700 : 420);
    }
  }

  // ── Pre-explosion tell ───────────────────────────────
  function initTell(b) {
    b.tell = {phase:'squash', t:0, maxT:8};
    b.tellScaleX = 1; b.tellScaleY = 1; b.tellGlow = 0;
    addShake(2.5);
  }
  function updateTell(b) {
    if (!b.tell) return false;
    const tell = b.tell;
    tell.t++;
    if (tell.phase === 'squash') {
      const p = tell.t / tell.maxT;
      b.tellScaleX = 1 + Math.sin(p*Math.PI)*0.28;
      b.tellScaleY = 1 - Math.sin(p*Math.PI)*0.18;
      b.tellGlow   = Math.sin(p*Math.PI)*0.7;
      if (tell.t >= tell.maxT) { tell.phase='pause'; tell.t=0; tell.maxT=12; addShake(3.5); }
    } else if (tell.phase === 'pause') {
      b.tellScaleX = 1.15; b.tellScaleY = 0.88;
      b.tellGlow = 0.9 + rnd()*0.1;
      gs.flash = Math.max(gs.flash, 0.4);
      if (tell.t >= tell.maxT) {
        tell.phase = 'done'; b.tell = null;
        b.tellScaleX = 1; b.tellScaleY = 1; b.tellGlow = 0;
        return true;
      }
    }
    return false;
  }

  // ── Block x-range index ──────────────────────────────
  let blockXIndex = [];
  let blockIndexDirty = false;
  function markIndexDirty() { blockIndexDirty = true; }
  function buildBlockIndex() {
    blockXIndex = gs.blocks
      .map((b, i) => ({x:b.x, halfW:b.w*0.55, idx:i}))
      .sort((a,b) => a.x - b.x);
    blockIndexDirty = false;
  }
  function flushBlockIndex() {
    if (blockIndexDirty) buildBlockIndex();
  }

  // ── Structural collapse ──────────────────────────────
  function isBlockSupported(block, idx) {
    if (block.y + block.h / 2 >= FLOOR_Y - FLOOR_THRESHOLD) return true;
    const myLeft   = block.x - block.w / 2;
    const myRight  = block.x + block.w / 2;
    const myBottom = block.y + block.h / 2;
    for (let i = 0; i < gs.blocks.length; i++) {
      if (i === idx) continue;
      const other = gs.blocks[i];
      if (other.broken || other.falling) continue;
      const otherTop = other.y - other.h / 2;
      if (Math.abs(otherTop - myBottom) > 16) continue;
      const oLeft  = other.x - other.w / 2;
      const oRight = other.x + other.w / 2;
      const overlapLeft  = Math.max(myLeft,  oLeft);
      const overlapRight = Math.min(myRight, oRight);
      const overlap = overlapRight - overlapLeft;
      const minWidth = Math.min(block.w, other.w);
      if (overlap >= minWidth * SUPPORT_OVERLAP) return true;
    }
    return false;
  }

  // Visual-only companion to isBlockSupported(). It exposes where the stack
  // is carrying weight so the player can read a collapse before committing a
  // shot. This is intentionally cheap: the levels contain only a few dozen
  // blocks, and it runs only while the playfield is being drawn.
  function supportLoad(block, idx) {
    if (block.broken || block.falling) return 0;
    const myLeft=block.x-block.w/2, myRight=block.x+block.w/2;
    const myTop=block.y-block.h/2;
    let load=0;
    for(let i=0;i<gs.blocks.length;i++){
      if(i===idx)continue;
      const above=gs.blocks[i];
      if(above.broken||above.falling)continue;
      const aboveBottom=above.y+above.h/2;
      if(Math.abs(aboveBottom-myTop)>16)continue;
      const overlap=Math.min(myRight,above.x+above.w/2)-Math.max(myLeft,above.x-above.w/2);
      if(overlap>=Math.min(block.w,above.w)*SUPPORT_OVERLAP)load++;
    }
    return load;
  }

  function checkSupport() {
    let changed = true;
    while (changed) {
      changed = false;
      for (let i = 0; i < gs.blocks.length; i++) {
        const block = gs.blocks[i];
        if (block.broken || block.falling) continue;
        if (!isBlockSupported(block, i)) {
          block.falling = true;
          gs.collapseCount++;
          block.vy = block.vy || 0;
          changed = true;
          block.shake = 0.9;
          block.hitFlash = 0.5;
          spawnImpact(block.x, block.y, '#ffd27c', 7, 'collapse');
          spawnDust(block.x, block.y + block.h / 2);
          addShake(2.5);
        }
      }
    }
  }

  // ── Confetti update ──────────────────────────────────
  function updateConfetti() {
    for (let i = confetti.length - 1; i >= 0; i--) {
      const c = confetti[i];
      if (c.gravDelay !== undefined) {
        c.gravDelayT = (c.gravDelayT || 0) + 1;
        if (c.gravDelayT > (c.gravDelay || 60))
          c.grav = Math.min(c.dropGrav || 0.55, c.grav + (c.gravRamp || 0.008));
      }
      c.vy += c.grav; c.wob += (c.wobS||0); c.pls += (c.plsS||0);
      c.x += c.vx + Math.sin(c.wob)*(c.wobA||0); c.y += c.vy;
      c.vx *= 0.987; c.rot += (c.rotV||0);
      if (c.y + c.r > FLOOR_Y) {
        if (!c.bounced) {
          c.bounced = true; c.vy *= -(c.bounce||0.25); c.vx *= 0.72; c.y = FLOOR_Y - c.r;
          if (c.dustOnLand) spawnDust(c.x, FLOOR_Y);
          if (c.sticky) { c.vx=0; c.vy=0; c.grav=0; }
        } else { c.vy *= -0.18; c.vx *= 0.8; c.y = FLOOR_Y-c.r; c.life -= 0.04; }
      }
      if (c.sh==='heart' && !c.popped && c.life < (c.popAt||0.55)) {
        c.popped = true;
        for (let j = 0; j < 6; j++) {
          const ang=rnd(0,Math.PI*2), mag=rnd(2,7);
          pushCapped(confetti, CAP.confetti, {
            x:c.x, y:c.y, vx:Math.cos(ang)*mag, vy:Math.sin(ang)*mag,
            life:0.7, decay:rnd(0.025,0.045), r:rnd(2,5),
            col:pick(['#f8c','#fae','#fbd','#fff','#ff88aa']),
            sh:'sparkle', grav:0.08, rot:rnd(0,Math.PI*2), rotV:rnd(-0.3,0.3),
            wob:0, wobS:0, wobA:0, pls:0, plsS:0, bounce:0.3, bounced:false,
          });
        }
        synthPop(600+rnd()*200, 0.12, 0.06);
      }
      c.life -= (c.decay||0.014);
      if (c.y > H+200) c.life = 0;
      if (c.life <= 0) confetti.splice(i, 1);
    }

    for (let i = gs.damageConfetti.length - 1; i >= 0; i--) {
      const c = gs.damageConfetti[i];
      if (c.gravDelay !== undefined) {
        c.gravDelayT = (c.gravDelayT||0) + 1;
        if (c.gravDelayT > (c.gravDelay||60))
          c.grav = Math.min(c.dropGrav||0.55, c.grav + (c.gravRamp||0.008));
      }
      c.vy += c.grav; c.wob += (c.wobS||0); c.pls += (c.plsS||0);
      c.x += c.vx + Math.sin(c.wob)*(c.wobA||0); c.y += c.vy;
      c.vx *= 0.987; c.rot += (c.rotV||0);
      if (c.y + c.r > FLOOR_Y) {
        if (!c.bounced) {
          c.bounced = true; c.vy *= -(c.bounce||0.25); c.vx *= 0.72; c.y = FLOOR_Y-c.r;
        } else { c.vy *= -0.15; c.y = FLOOR_Y-c.r; c.life -= 0.05; }
      }

      if (!c.hitOnce) {
        const cx = c.x, cr = c.r;
        let lo = 0, hi = blockXIndex.length;
        while (lo < hi) { const m = (lo+hi)>>1; if (blockXIndex[m].x + blockXIndex[m].halfW < cx - cr) lo=m+1; else hi=m; }
        for (let j = lo; j < blockXIndex.length; j++) {
          const entry = blockXIndex[j];
          if (entry.x - entry.halfW > cx + cr) break;
          const block = gs.blocks[entry.idx];
          if (!block || block.broken) continue;
          if (dist(cx, c.y, block.x, block.y) < entry.halfW + cr) {
            damageBlock(block, 1, cx, c.y, 5, entry.idx, false, c.power || null);
            c.hitOnce = true;
            break;
          }
        }
      }

      c.life -= (c.decay||0.014);
      if (c.life <= 0) gs.damageConfetti.splice(i, 1);
    }
  }

  function drawConfetti() {
    for (const c of confetti) {
      if (offscreen(c.x, c.y, c.r)) continue;
      ctx.save();
      ctx.globalAlpha = clamp(c.life, 0, 1) * (c.alpha||1);
      ctx.fillStyle = c.col;
      ctx.translate(c.x, c.y); ctx.rotate(c.rot);
      drawConfettiShape(c);
      ctx.restore();
    }
    for (const c of gs.damageConfetti) {
      if (offscreen(c.x, c.y, c.r)) continue;
      ctx.save();
      ctx.globalAlpha = clamp(c.life, 0, 1) * (c.alpha||1);
      ctx.fillStyle = c.col;
      ctx.translate(c.x, c.y); ctx.rotate(c.rot);
      drawConfettiShape(c);
      ctx.restore();
    }
  }

  function drawConfettiShape(c) {
    switch(c.sh){
      case 'circle':  ctx.beginPath();ctx.ellipse(0,0,c.r,c.r*0.5,0,0,Math.PI*2);ctx.fill();break;
      case 'rect':    ctx.fillRect(-c.r*0.55,-c.r*0.35,c.r*1.1,c.r*0.7);break;
      case 'star': {
        ctx.beginPath();
        for(let s=0;s<10;s++){const R=s%2?c.r*0.42:c.r,a=s*Math.PI/5-Math.PI/2;s?ctx.lineTo(Math.cos(a)*R,Math.sin(a)*R):ctx.moveTo(Math.cos(a)*R,Math.sin(a)*R);}
        ctx.closePath();ctx.fill();break;}
      case 'sparkle':{
        const pf=0.38+0.28*Math.sin(c.pls||0),r2=c.r*pf;
        ctx.beginPath();ctx.moveTo(0,-c.r);ctx.lineTo(r2*0.25,-r2*0.25);ctx.lineTo(c.r,0);ctx.lineTo(r2*0.25,r2*0.25);ctx.lineTo(0,c.r);ctx.lineTo(-r2*0.25,r2*0.25);ctx.lineTo(-c.r,0);ctx.lineTo(-r2*0.25,-r2*0.25);ctx.closePath();ctx.fill();break;}
      case 'heart':{
        ctx.beginPath();ctx.moveTo(0,c.r*0.35);ctx.bezierCurveTo(-c.r,-c.r*0.1,-c.r,-c.r*0.9,0,-c.r*0.5);ctx.bezierCurveTo(c.r,-c.r*0.9,c.r,-c.r*0.1,0,c.r*0.35);ctx.closePath();ctx.fill();break;}
      case 'shard':   {ctx.beginPath();ctx.moveTo(0,-c.r);ctx.lineTo(c.r*0.55,c.r*0.5);ctx.lineTo(-c.r*0.55,c.r*0.35);ctx.closePath();ctx.fill();break;}
      case 'crystal': {ctx.beginPath();ctx.moveTo(0,-c.r);ctx.lineTo(c.r*0.4,0);ctx.lineTo(0,c.r);ctx.lineTo(-c.r*0.4,0);ctx.closePath();ctx.fill();break;}
      case 'chunk':   {ctx.beginPath();ctx.moveTo(-c.r*0.5,-c.r*0.6);ctx.lineTo(c.r*0.6,-c.r*0.4);ctx.lineTo(c.r*0.4,c.r*0.5);ctx.lineTo(-c.r*0.6,c.r*0.3);ctx.closePath();ctx.fill();break;}
      case 'flame':   {ctx.beginPath();ctx.moveTo(0,c.r*0.5);ctx.quadraticCurveTo(c.r*0.8,0,c.r*0.3,-c.r*0.6);ctx.quadraticCurveTo(0,-c.r,-c.r*0.3,-c.r*0.6);ctx.quadraticCurveTo(-c.r*0.8,0,0,c.r*0.5);ctx.closePath();ctx.fill();break;}
      default:        ctx.beginPath();ctx.arc(0,0,c.r,0,Math.PI*2);ctx.fill();
    }
  }

  // ── Crack system ────────────────────────────────────
  const CRACKS = new Map();
  function getCracks(block, idx) {
    if (!CRACKS.has(idx)) {
      const w=block.w, h=block.h;
      const ml=(n,maxL)=>Array.from({length:n},()=>{
        const ox=rnd(-w*0.35,w*0.35),oy=rnd(-h*0.35,h*0.35),a=rnd(0,Math.PI*2),l=rnd(maxL*0.4,maxL);
        return{x1:ox,y1:oy,x2:ox+Math.cos(a)*l,y2:oy+Math.sin(a)*l,
          br:rnd()<0.4?{x:ox+Math.cos(a)*l*0.5,y:oy+Math.sin(a)*l*0.5,a:a+rnd(0.4,1.1)*(rnd()<0.5?1:-1),l:l*rnd(0.3,0.55)}:null};
      });
      CRACKS.set(idx,{minor:ml(3,Math.min(w,h)*0.35),mid:ml(5,Math.min(w,h)*0.55),heavy:ml(8,Math.min(w,h)*0.75)});
    }
    return CRACKS.get(idx);
  }
  function drawCracks(block, idx) {
    if (block.broken || block.maxHp<=1) return;
    const r = clamp(block.hp/block.maxHp, 0, 1); if (r>=1) return;
    const{minor,mid,heavy} = getCracks(block, idx);
    const lines = r<0.34?[...minor,...mid,...heavy] : r<0.67?[...minor,...mid] : minor;
    const alpha = r<0.34?0.75 : r<0.67?0.55 : 0.35;
    ctx.save(); ctx.globalAlpha=alpha; ctx.strokeStyle='rgba(0,0,0,0.65)'; ctx.lineWidth=1; ctx.lineCap='round';
    rrClip(ctx, block.x-block.w/2, block.y-block.h/2, block.w, block.h, 8);
    for (const l of lines) {
      ctx.beginPath(); ctx.moveTo(block.x+l.x1,block.y+l.y1); ctx.lineTo(block.x+l.x2,block.y+l.y2); ctx.stroke();
      if (l.br) { ctx.beginPath(); ctx.moveTo(block.x+l.br.x,block.y+l.br.y); ctx.lineTo(block.x+l.br.x+Math.cos(l.br.a)*l.br.l,block.y+l.br.y+Math.sin(l.br.a)*l.br.l); ctx.stroke(); }
    }
    ctx.restore();
  }

  // ── Atomic round management ──────────────────────────
  function resetRound() {
    sparks.length=0; waves.length=0; impactBursts.length=0; dusts.length=0; confetti.length=0;
    powers.length=0; scorchMarks.length=0;
    CRACKS.clear(); shake.v=0;
    gs.dragging=false; gs.pullPlayed=false; gs.bestShot=0; gs.pct=0; gs.brokenBlocks=0; gs.goalReached=false;
    gs.roundScore=0;
    gs.roundMultiplier=1; gs.roundShotBonus=0; gs.roundDestructionScore=0;
    gs.shotsUsed=0; gs.collapseCount=0; gs.powerUsed=new Set();
    gs.contractComplete=false; gs.contractBonus=0; gs.cardUnlock=''; gs.cardChapter='';
    gs.ruleComplete=false; gs.ruleBonus=0; gs.ruleFailed=false; gs.ruleTime=0; gs.markedTargetIndex=-1;
    gs.nearMiss=false;
    gs.comboPulse=0;
    gs.debTimer=0; gs.shotLock=false; gs.flash=0; gs.hitStop=0; gs.cardIntro=0;
    gs.fireTrail=[]; gs.minis=[]; gs.frozen=new Map(); gs.bounces=0;
    gs.isLastBooha=false; gs.timeScale=1;
    gs.nightmareFlicker=false; gs.nightmareFlickerTimer=0;
    gs.damageConfetti=[];
    bst.stocks=ROSTER.map((b, i) => isBoohaUnlocked(i) ? b.stock : 0);
    bst.sel=ROSTER.findIndex((_, i) => isBoohaUnlocked(i));
    if (bst.sel < 0) bst.sel = 0;
    gs.ghostsLeft=bst.totalShots();
    blockIndexDirty = false;
  }

  function loadRound(idx) {
    clearTimeout(gs.roundTransitionTimer);
    gs.roundTransitionTimer = null;
    gs.roundToken++;

    resetRound();
    gs.round  = clamp(idx, 0, LEVELS.length - 1);
    gs.roundN = gs.round + 1;
    const record = getRoundRecord(LEVELS[gs.round]);
    gs.roundBestScore = record.best;
    gs.roundBestShots = record.bestShots;
    gs.roundMedal = record.medal;
    gs.roundClears = record.clears;
    gs.roundNewBest = false;
    gs.roundMedalUp = false;

    const lvl = LEVELS[gs.round];
    gs.blocks      = lvl.blocks.map((def, i) => cloneBlock(def, i));
    gs.totalBlocks = gs.blocks.length;
    if (lvl.rule?.type === 'time_attack') gs.ruleTime = lvl.rule.timeLimit || 55;
    if (lvl.rule?.type === 'marked_target') {
      gs.markedTargetIndex = gs.blocks.reduce((best, block, i) => {
        if (best < 0) return i;
        return block.y < gs.blocks[best].y ? i : best;
      }, -1);
      if (gs.markedTargetIndex >= 0) gs.blocks[gs.markedTargetIndex].marked = true;
    }
    buildBlockIndex();
    gs.booha   = makeBooha();
    gs.running = false;
  }

  function showBriefing() {
    gs.phase = P.BRIEF;
    gs.running = false;
    gs.booha = makeBooha();
  }

  function startRound() { gs.running=true; gs.phase=P.PLAY; }

  function showCard(phase, title, sub, accent) {
    gs.phase    = phase;
    gs.cardTitle= title; gs.cardSub=sub; gs.cardAccent=accent;
    gs.cardIntro=18;
    gs.flash = phase===P.WIN ? 1.1 : 0.35;
    gs.cardMeta=''; gs.cardMetaGood=false;
    gs.running  = false;
    gs.booha    = null; gs.minis=[]; gs.damageConfetti=[];
    gs.fireTrail= []; gs.frozen=new Map();
    sparks.length=0; waves.length=0; impactBursts.length=0; dusts.length=0;
    scorchMarks.length=0; shake.v=0;
  }

  function advanceRound() {
    if (gs.round >= LEVELS.length - 1) return;
    loadRound(gs.round + 1);
    showBriefing();
  }

  // ── Game objects ────────────────────────────────────
  function makeBooha(rosterIdx) {
    const ri = rosterIdx ?? bst.sel;
    const r  = ROSTER[ri];
    const radius = r.power==='heavy'    ? B_RADIUS*1.35
                 : r.power==='princess' ? B_RADIUS*0.78
                 : B_RADIUS;
    return {
      launched:false, x:SLING_X, y:SLING_Y, vx:0, vy:0,
      radius, baseRadius:radius,
      settledF:0, confettiFired:false, damageThisShot:0,
      ri, power:r.power,
      piercedOnce:false, spawnedMinis:false,
      trailTimer:0, lifeFrames:0, maxLifeFrames:420,
      tell:null, tellScaleX:1, tellScaleY:1, tellGlow:0,
      _teleported:false,
      impactCompress:0, impactCompressDir:0,
    };
  }

  // v4: cloneBlock reads traits and resist from level def
  function cloneBlock(def, idx) {
    const y = typeof def.floorOffset==='number' ? FLOOR_Y-def.floorOffset : def.y;
    CRACKS.delete(idx);
    return {
      x:def.x, y, w:def.w, h:def.h, material:def.material||'wood',
      hp:def.hp||1, maxHp:def.hp||1,
      broken:false,
      marked:false,
      falling:false,
      shake:0, vy:0, fallen:false, hitFlash:0,
      frozen:false, burning:false, burnTimer:0, ringCrack:false, compressY:0,
       
      // v4: trait & resist system
      traits: Array.isArray(def.traits) ? [...def.traits] : [],
      resist: def.resist ? {...def.resist} : {},
      burnBoost: def.burnBoost === true,
      burnStacks: 0,
    };
  }

  // ── Power helpers ────────────────────────────────────
  function applyFireBurn(block) {
    if (block.broken) return;
    if (powerBlocked(block, 'fire', 'burn')) return;
    // Stack-based: first hit ignites, second hit enables damage ticks
    block.burnStacks = (block.burnStacks || 0) + 1;
    if (block.burnStacks === 1) {
      // First hit — ignite only, no damage yet
      block.burning = true;
      block.burnTimer = block.burnBoost ? 160 : 120;
      block.burnDamageEnabled = false;
    } else {
      // Second hit — enable real damage ticks
      block.burnDamageEnabled = true;
      // Refresh timer so it doesn't immediately expire
      block.burnTimer = Math.max(block.burnTimer, block.burnBoost ? 120 : 80);
    }
  }

  // v4: updateBurning checks burnimmune before ticking
  function updateBurning() {
    gs.blocks.forEach((block, idx) => {
      if (!block.burning || block.broken) return;
      if (powerBlocked(block, 'fire', 'burn')) { block.burning = false; return; }
      block.burnTimer--;
      const tickRate = block.burnBoost ? 28 : 40;
      if (block.burnTimer % tickRate === 0 && block.hp > 0) {
        // Ignited but not stacked — smoke and embers only, no damage
        if (!block.burnDamageEnabled) {
          spawnEmber(block.x + rnd(-block.w/2, block.w/2), block.y - block.h/2);
          spawnEmber(block.x + rnd(-block.w/2, block.w/2), block.y - block.h/2);
        } else {
          // Second stack — real damage ticks
          damageBlock(block, 1, block.x, block.y, 8, idx, false, 'fire');
          spawnEmber(block.x + rnd(-block.w/2, block.w/2), block.y - block.h/2);
          // Spread boost: spread fire faster to nearby blocks
          if (block.burnBoost) {
            gs.blocks.forEach(other => {
              if (!other.broken && other !== block &&
                  dist(other.x, other.y, block.x, block.y) < 70) {
                applyFireBurn(other);
              }
            });
          }
        }
      }
      if (block.burnTimer <= 0) {
        block.burning = false;
        block.burnStacks = 0;
        block.burnDamageEnabled = false;
      }
    });
  }

   
  function updateFrozen() {
    for (const [idx, frames] of gs.frozen.entries()) {
      if (frames<=0) {
        const block = gs.blocks[idx];
        gs.frozen.delete(idx);
        if (block && !block.broken) {
          block.frozen=false;
          damageBlock(block, block.hp, block.x, block.y, 18, idx, true, 'ice');
          spawnIce(block.x, block.y, block.w, block.h);
        }
      } else gs.frozen.set(idx, frames-1);
    }
  }

// ── v4: Block damage ─────────────────────────────────
  // power param (string|null): the Booha power causing this damage.
  // Checks powerBlocked() and applies resist scalar before dealing damage.
  function damageBlock(block, amount, hx, hy, spd, idx, doSFX=true, power=null) {
    if (block.broken || block.frozen) return;

    // Check full immunity first
    if (power && powerBlocked(block, power, 'hit')) {
      spawnWave(hx, hy, '#ffffff', 26);
      spawnImpact(hx, hy, traitGlowColor(block) || '#ffffff', spd, 'immune');
      block.hitFlash = 0.35;
      block.shake = 0.65;
      addShake(1.5);
      return;
    }

    // Apply damage resistance (scalar 0–1 means less damage)
    const resist = power ? getResist(block, power) : 1;
    const actualAmount = amount * resist;
    if (actualAmount <= 0) return;

    const load=supportLoad(block,idx);
    const weakHit=block.marked||load>1;
    block.hp -= actualAmount;
    if (gs.booha) gs.booha.damageThisShot=Math.max(gs.booha.damageThisShot,actualAmount);
    block.shake=weakHit?1.45:1.15; block.hitFlash=1;
    block.compressY=Math.max(block.compressY||0,weakHit?8:3);
    const mat=block.material, m=MAT[mat]||MAT.wood;
    spawnSparks(hx, hy, mat, spd, ~~(6+spd*0.5));
    spawnWave(hx, hy, m.spark, 35+spd*2);
    spawnImpact(hx, hy, m.spark, spd, block.hp<=0 ? (weakHit?'break-weak':'break') : (weakHit?'weak':'hit'));
    if (weakHit) {
      spawnWave(hx,hy,'#ffcf70',Math.min(76,42+spd*1.5));
      gs.hitStop=Math.max(gs.hitStop,2);
      gs.flash=Math.max(gs.flash,0.5);
      addShake(Math.min(8,spd*0.5+2));
    } else if (spd>10) addShake(Math.min(6, spd*0.4));
    if (block.hp<=0) {
      block.broken=true; gs.brokenBlocks++;
      gs.pct=(gs.brokenBlocks/gs.totalBlocks)*100;
      maybeReachGoal();
      if (gs.booha) { gs.booha.damageThisShot=gs.pct; gs.bestShot=Math.max(gs.bestShot,gs.pct); }
      if (mat==='glass') { spawnGlass(block.x,block.y,block.w,block.h); spawnWave(block.x,block.y,'#b7ecff',70); }
      else { spawnSparks(block.x,block.y,mat,spd+4,20); spawnWave(block.x,block.y,m.spark,60); }
      if (gs.pct>50 && rnd()<0.35) {
        const nearby=gs.blocks.filter(bl=>!bl.broken&&dist(bl.x,bl.y,block.x,block.y)<120);
        nearby.slice(0,2).forEach(nb=>{spawnSparks(nb.x,nb.y,nb.material,spd*0.6,8);nb.hitFlash=0.5;});
      }
      gs.hitStop=Math.max(gs.hitStop, spd>12 ? 5 : 3);
      addShake(Math.min(10, spd*0.6+4));
      if (doSFX) sndBreak();
      gs.debTimer=18;
      markIndexDirty();
      checkSupport();
    }
  }

   
 // ── v4: Block collision ─────────────────────────────
  function blockCollide(block, idx) {
    const b=gs.booha; if(!b||!b.launched||block.broken) return;
    if (b.tell) return;
    const cx=clamp(b.x,block.x-block.w/2,block.x+block.w/2);
    const cy=clamp(b.y,block.y-block.h/2,block.y+block.h/2);
    const dx=b.x-cx, dy=b.y-cy, dsq=dx*dx+dy*dy;
    if (dsq>b.radius*b.radius) return;
    const spd=Math.hypot(b.vx,b.vy);
    if (spd<MIN_IMPACT) return;
    sndHit(block.material, spd);
    const power=b.power;

    // v4: immunity checks
    const fireImmune     = powerBlocked(block, 'fire',     'hit');
    const iceImmune      = powerBlocked(block, 'ice',      'hit') || powerBlocked(block, 'ice',     'freeze');
    const rainbowImmune  = powerBlocked(block, 'rainbow',  'hit') || powerBlocked(block, 'rainbow', 'convert');
    const ultimateImmune = powerBlocked(block, 'ultimate', 'hit');
    const heavyImmune    = powerBlocked(block, 'heavy',    'hit');
    const rockImmune     = powerBlocked(block, 'rock',     'hit');

    const fullyBlocked =
      (power==='fire'      && fireImmune)     ||
      (power==='ultimate'  && ultimateImmune) ||
      (power==='heavy'     && heavyImmune)    ||
      (power==='rock'      && rockImmune)     ||
      (power==='ice'       && iceImmune)      ||
      (power==='rainbow'   && rainbowImmune);

    if (fullyBlocked) {
      spawnWave(cx, cy, '#ffffff', 32);
      spawnWave(cx, cy, traitGlowColor(block) || '#ffffff', 22);
      spawnImpact(cx, cy, traitGlowColor(block) || '#ffffff', spd, 'immune');
      for (let i = 0; i < 10; i++) {
        const a = rnd(0, Math.PI*2), mag = rnd(2, 7);
        pushCapped(sparks, CAP.sparks, {
          x: cx, y: cy,
          vx: Math.cos(a)*mag, vy: Math.sin(a)*mag - rnd(1, 3),
          life: 1, r: rnd(2, 5),
          col: traitGlowColor(block) || '#ffffff',
          type: 'dot', grav: 0.18, rot: 0, rotV: 0,
          decay: rnd(0.03, 0.06)
        });
      }
      block.hitFlash = 0.6;
      addShake(2.5);
      synthPop(900 + rnd()*200, 0.18, 0.06);
      spawnClangLabel(cx, cy);
      const nx=dx===0&&dy===0?1:dx/Math.sqrt(dsq||1), ny=dx===0&&dy===0?0:dy/Math.sqrt(dsq||1);
      const dot=b.vx*nx+b.vy*ny;
      b.vx=(b.vx-2*dot*nx)*BOUNCE; b.vy=(b.vy-2*dot*ny)*BOUNCE;
      if(Math.abs(dx)>Math.abs(dy)) b.x=cx+nx*(b.radius+1); else b.y=cy+ny*(b.radius+1);
      return;
    }

     
    // Special effects — only reach here if not fully blocked
    if (power==='ice')      { spawnRingCrack(cx,cy); block.ringCrack=true; }
    if (power==='fire')     { spawnScorch(cx,cy); }
    if (power==='heavy')    { block.compressY=6; }
    if (power==='princess') { b.impactCompress=1; b.impactCompressDir=Math.atan2(dy,dx); }
    if (power==='nightmare'){ setTimeout(()=>sndHit(block.material,spd),160); }

    if (power==='ice' && !block.frozen) {
      block.frozen=true; gs.frozen.set(idx,90);
      spawnWave(cx,cy,'#aaeeff',50); spawnSparks(cx,cy,'ice',spd,10); addShake(4);
    }
    if (power==='rainbow' && block.material!=='glass') {
      block.material='glass'; block.hp=1; block.maxHp=1;
      spawnWave(cx,cy,'#ff88ff',55);
    }
    if (power==='princess' && !b.spawnedMinis) {
      b.spawnedMinis=true;
      for (let m=0;m<3;m++) {
        const ang=-Math.PI*0.5+rnd(-0.6,0.6);
        gs.minis.push({isMini:true, x:cx, y:cy, vx:Math.cos(ang)*rnd(8,14), vy:Math.sin(ang)*rnd(8,14)-rnd(3,6), radius:B_RADIUS*0.45, launched:true, life:1, ri:b.ri});
      }
    }

    // Damage
    let dmg=0;
    if      (power==='heavy')                   dmg=2;
    else if (power==='ice'||power==='rainbow')  dmg=0;
    else dmg = block.material==='stone'?(spd>11?1:0) : block.material==='glass'?1 : block.material==='soft'?(spd>5?1:0) : (spd>7?1:0);
    if (dmg>0) damageBlock(block,dmg,cx,cy,spd,idx,true,power);

    // Fire spread
    if (power==='fire') {
    gs.blocks.forEach((blk,i)=>{
    if(!blk.broken && dist(blk.x,blk.y,block.x,block.y)<80) applyFireBurn(blk);
   });
 }

    if (power==='rock'&&!b.piercedOnce) { b.piercedOnce=true; return; }
    if (power==='monster') { gs.bounces++; b.radius=Math.min(b.baseRadius*(1+gs.bounces*0.22),B_RADIUS*2.8); }

    const nx=dx===0&&dy===0?1:dx/Math.sqrt(dsq||1), ny=dx===0&&dy===0?0:dy/Math.sqrt(dsq||1);
    const dot=b.vx*nx+b.vy*ny;
    b.vx=(b.vx-2*dot*nx)*BOUNCE; b.vy=(b.vy-2*dot*ny)*BOUNCE;
    if(Math.abs(dx)>Math.abs(dy)) b.x=cx+nx*(b.radius+1); else b.y=cy+ny*(b.radius+1);
  }

  function miniCollide(mini) {
    for (let i=0;i<gs.blocks.length;i++) {
      const block=gs.blocks[i]; if(block.broken)continue;
      const cx=clamp(mini.x,block.x-block.w/2,block.x+block.w/2);
      const cy=clamp(mini.y,block.y-block.h/2,block.y+block.h/2);
      if(dist(mini.x,mini.y,cx,cy)<mini.radius){
        damageBlock(block,1,cx,cy,Math.hypot(mini.vx,mini.vy),i,true,null);
        const nx=(mini.x-cx)||1, ny=(mini.y-cy)||0, l=Math.hypot(nx,ny)||1;
        mini.vx=(mini.vx-2*(mini.vx*(nx/l)+mini.vy*(ny/l))*(nx/l))*0.65;
        mini.vy=(mini.vy-2*(mini.vx*(nx/l)+mini.vy*(ny/l))*(ny/l))*0.65;
      }
    }
  }

  // ── updateBlocks ─────────────────────────────────────
  function updateBlocks() {
    flushBlockIndex();
    let anyFallingLanded = false;

    for (let i = 0; i < gs.blocks.length; i++) {
      const block = gs.blocks[i];

      if (block.broken) {
        block.vy += GRAVITY * 0.6;
        block.y  += block.vy;
        if (!block.fallen && block.y + block.h / 2 >= FLOOR_Y) {
          block.y = FLOOR_Y - block.h / 2;
          block.fallen = true;
          const s = Math.abs(block.vy); sndGnd(s);
          if (s > 6) {
            spawnDust(block.x, FLOOR_Y);
            spawnDust(block.x + rnd(-20,20), FLOOR_Y);
            spawnSparks(block.x, FLOOR_Y, block.material, s, 6);
          }
          block.vy *= -0.18;
        }
        block.vy *= 0.985;
        if (block.compressY > 0) { block.compressY *= 0.7; if (block.compressY < 0.5) block.compressY = 0; }
        block.shake *= 0.84; block.hitFlash *= 0.8;
        continue;
      }

      if (block.falling) {
        block.vy += GRAVITY;
        block.y  += block.vy;

        if (block.y + block.h / 2 >= FLOOR_Y) {
          block.y   = FLOOR_Y - block.h / 2;
          const spd = Math.abs(block.vy);
          block.vy  = 0;
          block.falling = false;
          anyFallingLanded = true;

          sndGnd(spd);
          if (spd > 4) {
            spawnDust(block.x, FLOOR_Y);
            addShake(Math.min(5, spd * 0.25));
            spawnSparks(block.x, FLOOR_Y, block.material, spd, 5);
          }
          if (spd >= FALL_CRUSH_SPEED) {
            const crushDmg = spd >= FALL_CRUSH_SPEED * 1.8 ? 2 : 1;
            damageBlock(block, crushDmg, block.x, block.y, spd, i, true, null);
          }
        } else {
          for (let j = 0; j < gs.blocks.length; j++) {
            if (i === j) continue;
            const other = gs.blocks[j];
            if (other.broken || other.falling) continue;

            const otherTop    = other.y - other.h / 2;
            const blockBottom = block.y + block.h / 2;

            if (blockBottom >= otherTop && blockBottom <= otherTop + block.vy + 2) {
              const overlapL = Math.max(block.x - block.w/2, other.x - other.w/2);
              const overlapR = Math.min(block.x + block.w/2, other.x + other.w/2);
              if (overlapR - overlapL > block.w * SUPPORT_OVERLAP) {
                const spd = Math.abs(block.vy);
                block.y   = otherTop - block.h / 2;
                block.vy  = 0;
                block.falling = false;
                anyFallingLanded = true;

                sndGnd(spd);
                if (spd > 4) {
                  spawnDust(block.x, otherTop);
                  addShake(Math.min(4, spd * 0.2));
                }
                if (spd >= FALL_CRUSH_SPEED) {
                  const crushDmg = spd >= FALL_CRUSH_SPEED * 1.8 ? 2 : 1;
                  damageBlock(other, crushDmg, other.x, other.y, spd, j, true, null);
                }
                break;
              }
            }
          }
        }
      }

      if (block.compressY > 0) { block.compressY *= 0.7; if (block.compressY < 0.5) block.compressY = 0; }
      block.shake   *= 0.84;
      block.hitFlash *= 0.8;
    }

    if (anyFallingLanded) {
      markIndexDirty();
      checkSupport();
    }

    if (gs.debTimer > 0) { if (gs.debTimer === 18) sndRub(); gs.debTimer--; }
    updateBurning();
    updateFrozen();

    for (let i = scorchMarks.length - 1; i >= 0; i--) {
      scorchMarks[i].life -= scorchMarks[i].decay;
      if (scorchMarks[i].life <= 0) scorchMarks.splice(i, 1);
    }
  }

  function updateMinis() {
    for(let i=gs.minis.length-1;i>=0;i--){
      const m=gs.minis[i];
      m.vy+=GRAVITY; m.vx*=AIR; m.vy*=AIR; m.x+=m.vx; m.y+=m.vy;
      if(m.y+m.radius>=FLOOR_Y){m.y=FLOOR_Y-m.radius;m.vy*=-0.35;m.vx*=0.8;m.life-=0.12;}
      if(m.x<0||m.x>W)m.life-=0.2;
      miniCollide(m); m.life-=0.008;
      if(m.life<=0)gs.minis.splice(i,1);
    }
  }
  function updateNightmareFlicker() {
    if(!gs.nightmareFlicker)return;
    gs.nightmareFlickerTimer--;
    if(gs.nightmareFlickerTimer<=0)gs.nightmareFlicker=false;
  }

  // ── Update: booha ────────────────────────────────────
  function updateBooha() {
    const b=gs.booha; if(!b||!b.launched)return;
    if(b.tell){
      const fire=updateTell(b);
      if(fire){ b.confettiFired=true; triggerDeathExplosion(b); queueNextRound(()=>finishShot(), NEXT_MS); }
      return;
    }
    if(b.launched&&!b.confettiFired&&!gs.shotLock){
      b.lifeFrames++;
      if(b.lifeFrames>=b.maxLifeFrames){
        b.y=FLOOR_Y-b.radius; b.vx=0; b.vy=0;
        if(b.power==='nightmare'){
          b.confettiFired=true; triggerDeathExplosion(b);
          queueNextRound(()=>finishShot(), NEXT_MS+600);
        } else { initTell(b); }
        return;
      }
    }
    if(b.power==='nightmare'&&!b._teleported){
      b._teleported=true;
      const target=gs.blocks.find(bl=>!bl.broken);
      if(target){
        spawnTeleport(b.x,b.y);
        b.x=target.x+target.w*0.5+60; b.y=target.y;
        b.vx=-Math.abs(b.vx)*1.4-rnd()*3; b.vy=rnd(-4,2);
        spawnTeleport(b.x,b.y);
      }
    }
    const ts=gs.timeScale;
    b.vy+=GRAVITY*ts; b.vx*=Math.pow(AIR,ts); b.vy*=Math.pow(AIR,ts);
    b.x+=b.vx*ts; b.y+=b.vy*ts;
    b.trailTimer++;
    const tt=b.trailTimer;
    switch(b.power){
      case 'heavy':     if(tt%4===0)spawnHeavyDust(b.x,b.y); break;
      case 'rock':      if(tt%3===0)spawnChipTrail(b.x,b.y,b.vx,b.vy); break;
      case 'ice':       if(tt%3===0)spawnIceVapor(b.x,b.y); break;
      case 'fire':      if(rnd()<0.45)spawnEmber(b.x,b.y); break;
      case 'rainbow':   if(tt%2===0){const so=Math.sin(tt*0.18)*12;spawnRainbow(b.x,b.y+so);} break;
      case 'nightmare': if(tt%5===0)spawnGhostTrail(b.x-b.vx*3,b.y-b.vy*3,b.ri); break;
      case 'monster':   if(tt%3===0){const thk=1+gs.bounces*0.5;for(let i=0;i<thk;i++)spawnEmber(b.x+rnd(-4,4),b.y+rnd(-4,4));} break;
      case 'princess':  if(tt%4===0)pushCapped(sparks,CAP.sparks,{x:b.x+rnd(-8,8),y:b.y+rnd(-8,8),vx:rnd(-1,1),vy:rnd(-1,0.5),life:0.8,r:rnd(2,5),col:pick(['#f8c','#fae','#fff']),type:'dot',grav:0.02,rot:0,rotV:0,decay:rnd(0.025,0.045)}); break;
    }
    if(b.impactCompress>0){b.impactCompress*=0.8;if(b.impactCompress<0.05)b.impactCompress=0;}
    if(b.x-b.radius<0){b.x=b.radius;b.vx*=-BOUNCE;}
    if(b.x+b.radius>W){b.x=W-b.radius;b.vx*=-BOUNCE;}
    if(b.y+b.radius>=FLOOR_Y){
      const s=Math.abs(b.vy)*ts;
      if(s>8){sndGnd(s);spawnDust(b.x,FLOOR_Y);addShake(Math.min(4,s*0.2)*(gs.isLastBooha?1.8:1));}
      b.y=FLOOR_Y-b.radius; b.vy*=-0.38; b.vx*=0.86;
      if(b.power==='heavy'&&s>10){for(let i=0;i<20;i++)spawnSparks(b.x,FLOOR_Y,'stone',s,1);addShake(8*(gs.isLastBooha?1.8:1));}
      if(b.power==='monster'){gs.bounces++;b.radius=Math.min(b.baseRadius*(1+gs.bounces*0.22),B_RADIUS*2.8);}
    }
    for(let i=0;i<gs.blocks.length;i++)blockCollide(gs.blocks[i],i);
    const spd=Math.hypot(b.vx,b.vy), onFloor=Math.abs(b.y-(FLOOR_Y-b.radius))<3;
    if(spd<REST_THR&&onFloor){
      b.vx*=0.985; b.vy*=0.985; b.settledF++;
      if(!b.confettiFired&&b.settledF>=SETTLE_NEED){
        if(!b.tell&&b.power!=='nightmare'){
          initTell(b);
        } else if(b.power==='nightmare'&&!b.confettiFired){
          b.confettiFired=true; triggerDeathExplosion(b);
          queueNextRound(()=>finishShot(), NEXT_MS+600);
        }
        if(b.power==='ultimate'&&!b.confettiFired){
          b.confettiFired=true; initTell(b); spawnDetonation(b.x,b.y);
           
          gs.blocks.forEach((block,i)=>{
          if(!block.broken&&dist(b.x,b.y,block.x,block.y)<220) {
          if(!powerBlocked(block,'ultimate','hit') && (block.hp < block.maxHp || block.falling))
          damageBlock(block,block.hp,block.x,block.y,20,i,false,'ultimate');
       }
     });
           
          gs.pct=(gs.brokenBlocks/gs.totalBlocks)*100;
        }
      }
    } else b.settledF=0;
    if(gs.isLastBooha&&b.launched&&gs.timeScale>0.55)gs.timeScale=Math.max(0.55,gs.timeScale-0.008);
    if((b.y>H+200||b.x<-200||b.x>W+200)&&!gs.shotLock)finishShot();
  }

  // ── finishShot ───────────────────────────────────────
  function finishShot() {
    if (gs.shotLock) return;
    gs.shotLock=true;
    gs.timeScale=1;
    const shotsLeft=bst.stocks.reduce((a,v)=>a+v,0);
    gs.ghostsLeft=shotsLeft;
    gs.pct=(gs.brokenBlocks/Math.max(1,gs.totalBlocks))*100;
    const level = currentLevel();
    const ruleFailed = gs.ruleFailed;
    const target=(level.targetPercent)||100;
    if (!ruleFailed && gs.pct>=target) {
      const contract = evaluateContract(shotsLeft);
      const rule = evaluateRule();
      awardRoundScore(shotsLeft, contract, rule);
      const chapterWasComplete = isChapterComplete(level.chapter);
      const roundResult = recordRoundResult(level, gs.roundScore, contract.complete, rule.complete, gs.shotsUsed);
      const newlyUnlocked = syncRosterUnlocks();
      gs.cardUnlock = newlyUnlocked.map(booha => `${booha.name} / ${booha.jpName}`).join(' · ');
      gs.cardChapter = !chapterWasComplete && isChapterComplete(level.chapter)
        ? `${level.chapterName} / チャプター${level.chapter} CLEAR`
        : '';
      gs.roundBestScore = roundResult.best;
      gs.roundMedal = roundResult.medal;
      gs.roundClears = roundResult.clears;
      gs.roundNewBest = roundResult.isNewBest;
      gs.roundMedalUp = roundResult.medalUp;
      sndWin();
      if (newlyUnlocked.length || gs.cardChapter) sndUnlock();
      const r=ROSTER[bst.sel], cfg=r.conf, cnt=~~(cfg.burst*1.4*BURST_SCALE);
      for(let i=0;i<cnt;i++){
        const ang=rnd(-Math.PI*0.85,-Math.PI*0.15), mag=rnd(4,20);
        pushCapped(confetti,CAP.confetti,{
          x:W/2+rnd(-60,60),y:H*0.28,vx:Math.cos(ang)*mag,vy:Math.sin(ang)*mag,
          life:1,decay:rnd(0.006,0.014),r:rnd(cfg.sz[0],cfg.sz[1]),
          col:pick(cfg.cols),sh:pick(cfg.sh),grav:rnd(0.14,0.28),
          rot:rnd(0,Math.PI*2),rotV:cfg.spin?rnd(-0.2,0.2):0,
          wob:rnd(0,Math.PI*2),wobS:rnd(0.06,0.14),wobA:rnd(0.5,2.5),
          pls:rnd(0,Math.PI*2),plsS:rnd(0.12,0.22),
          bounce:rnd(0.2,0.45),bounced:false,
        });
      }
      celebPops(500);
      const finalRound = gs.round >= LEVELS.length - 1;
      if (finalRound) {
        submitRunScore(true);
        const streakNote = gs.combo > 1 ? ` · STREAK / れんぞく ×${gs.combo}` : '';
        showCard(P.WIN, 'CAMPAIGN CLEAR!', `${LEVELS.length} rounds smashed · ${scoreText(gs.runScore)} points${streakNote}`, '#ffdd44');
      } else {
        const streakNote = gs.combo > 1 ? ` · STREAK / れんぞく ×${gs.combo}` : '';
        showCard(P.WIN, gs.cardChapter ? `CHAPTER ${level.chapter} CLEAR!` : (level.boss ? `BOSS ${gs.roundN} CLEARED!` : `ROUND ${gs.roundN} COMPLETE!`), `+${scoreText(gs.roundScore)} points · ${scoreText(gs.runScore)} total${streakNote}`, '#ffdd44');
      }
      const recordTag = roundResult.isNewBest ? 'NEW ROUND BEST' : `BEST ${scoreText(roundResult.best)}`;
      const medalTag = roundResult.medal ? `${medalText(roundResult.medal)} MEDAL` : 'MEDAL TO EARN';
      const shotTag = roundResult.isNewFewestShots ? `NEW SHOT RECORD · ${gs.shotsUsed} SHOTS` : `FEWEST ${roundResult.bestShots} SHOTS`;
      const streakTag = gs.combo > 1 ? `STREAK ×${gs.combo} · SCORE ×${gs.roundMultiplier.toFixed(2)}` : 'STREAK STARTED';
      gs.cardMeta = [contractResultText(contract), ruleResultText(rule), medalTag, shotTag, streakTag, recordTag]
        .filter(Boolean).join('  ·  ');
      gs.cardMetaGood = contract.complete || rule.complete || roundResult.isNewBest || roundResult.medalUp;
    } else if (ruleFailed || shotsLeft<=0) {
      sndFail();
      const lostStreak = gs.combo;
      gs.combo=0;
      gs.nearMiss = gs.pct >= Math.max(0, target - 10);
      gs.lives=Math.max(0,gs.lives-1);
      if (gs.lives===0) {
        submitRunScore(false);
        showCard(P.FAIL, 'RUN OVER', `${Math.round(gs.pct)}% destruction · ${scoreText(gs.runScore)} points`, '#ff6666');
      } else {
        showCard(P.FAIL, ruleFailed ? 'TIME UP!' : (gs.nearMiss ? 'SO CLOSE!' : (level.boss ? 'BOSS ROUND OVER' : 'ROUND OVER')), `${Math.round(gs.pct)}% destruction · ${gs.lives} lives left`, ruleFailed ? '#ff9f7f' : (gs.nearMiss ? '#ffcf70' : '#ff6666'));
      }
      const failMeta = ruleFailed
        ? `TIME ATTACK FAILED · ${Math.ceil(Math.max(0, gs.ruleTime))}s remaining`
        : gs.nearMiss
        ? `NEAR MISS · ${Math.round(target - gs.pct)}% more damage needed`
        : `${level.contract?.label || 'CONTRACT'} · ${contractProgress(level)}`;
      gs.cardMeta = [failMeta, lostStreak > 1 ? `STREAK ENDED ×${lostStreak}` : ''].filter(Boolean).join('  ·  ');
      gs.cardMetaGood = gs.nearMiss;
    } else {
      if (gs.booha && gs.booha.damageThisShot <= 0) {
        setToast('MISS · AIM FOR THE LOAD', '#aab8c4', 1100);
      }
      gs.shotLock=false;
      advanceSelector();
      const remaining=bst.stocks.reduce((a,v)=>a+v,0);
      gs.isLastBooha=remaining<=1; gs.timeScale=1;
      gs.booha=makeBooha(); gs.bounces=0;
      gs.fireTrail=[]; gs.minis=[]; gs.frozen=new Map(); gs.damageConfetti=[];
    }
  }
  function advanceSelector() {
    for(let i=0;i<ROSTER.length;i++){const t=(bst.sel+i)%ROSTER.length;if(bst.stocks[t]>0){bst.sel=t;return;}}
  }

  function updateRuleTimer() {
    const rule = currentRule();
    if (gs.phase !== P.PLAY || !rule || rule.type !== 'time_attack' || gs.ruleFailed || gs.shotLock) return;
    gs.ruleTime = Math.max(0, gs.ruleTime - FIXED_STEP / 1000);
    if (gs.ruleTime <= 0) {
      gs.ruleFailed = gs.pct < (currentLevel().targetPercent || 100);
      finishShot();
    }
  }

  // ── FX update ────────────────────────────────────────
  function updateFX() {
    gs.comboPulse *= 0.92;
    if (gs.cardIntro > 0) gs.cardIntro--;
    if (gs.phase === P.WIN || gs.phase === P.FAIL) {
      updateConfetti();
      return;
    }
    for(let i=sparks.length-1;i>=0;i--){
      const p=sparks[i];
      p.vy+=p.grav; p.x+=p.vx; p.y+=p.vy; p.vx*=0.97;
      if(p.rot!==undefined)p.rot+=p.rotV;
      p.life-=(p.decay||0.025)+0.005*rnd();
      if(p.y>FLOOR_Y-p.r&&(p.type==='chip'||p.type==='shard')){p.y=FLOOR_Y-p.r;p.vy*=-0.38;p.vx*=0.78;if(Math.abs(p.vy)>5)spawnDust(p.x,FLOOR_Y);}
      if(p.life<=0)sparks.splice(i,1);
    }
    for(let i=waves.length-1;i>=0;i--){const w=waves[i];w.r+=(w.maxR-w.r)*0.18;w.life-=0.07;if(w.life<=0)waves.splice(i,1);}
    for(let i=impactBursts.length-1;i>=0;i--){
      const p=impactBursts[i];
      p.r+=(p.maxR-p.r)*0.28;
      p.life-=p.decay;
      if(p.life<=0)impactBursts.splice(i,1);
    }
    for(let i=dusts.length-1;i>=0;i--){
      const d=dusts[i];
      if(d.falling){d.y=(d.y||0)+(d.vy||2);}
      d.r+=(d.maxR-d.r)*0.12; d.life-=0.05; if(d.life<=0)dusts.splice(i,1);
    }
    shake.v*=shake.decay;
    updateConfetti();
    updateMinis();
    updateNightmareFlicker();
    updateClangLabels();
  }

  // ── Input ────────────────────────────────────────────
  function worldPt(evt) {
    const r=canvas.getBoundingClientRect();
    const cx=evt.touches?evt.touches[0].clientX:evt.clientX;
    const cy=evt.touches?evt.touches[0].clientY:evt.clientY;
    return {x:(cx-r.left)*(W/r.width), y:(cy-r.top)*(VIEW_H/r.height)-SCENE_Y};
  }
  function selectorLayout() {
    const total = ROSTER.length * SEL_CARD_W + (ROSTER.length - 1) * SEL_GAP;
    return {
      x: Math.max(14, (W - total) / 2),
      y: FULL_BLEED ? H + 12 : H - SEL_CARD_H - 8,
    };
  }
  const ACTION_RECT = { x: W / 2 - 145, y: H / 2 + 105, w: 290, h: 58 };
  const EXIT_MODAL = { x: W / 2 - 250, y: H / 2 - 104, w: 500, h: 208 };
  const PAUSE_MODAL = { x: W / 2 - 220, y: H / 2 - 222, w: 440, h: 444 };
  const CONTROL_DOCK = [
    { id:'hall',  label:'★ HALL', w:70 },
    { id:'mute',  label:'♪',      w:36 },
    { id:'help',  label:'?',      w:36 },
    { id:'exit',  label:'EXIT',   w:58 },
  ];
  function controlDockLayout() {
    const gap = 6;
    const total = CONTROL_DOCK.reduce((sum, item) => sum + item.w, 0) + gap * (CONTROL_DOCK.length - 1);
    let x = W - 14 - total;
    return CONTROL_DOCK.map(item => {
      // Reserve the right end of the bottom strip for navigation. It stays
      // out of the playfield and clear of the selectable Booha cards.
      const rect = { ...item, x, y:H - SEL_CARD_H - 8, h:36 };
      x += item.w + gap;
      return rect;
    });
  }
  function controlDockHit(px, py) {
    return controlDockLayout().find(item => px >= item.x && px <= item.x + item.w && py >= item.y && py <= item.y + item.h)?.id || '';
  }
  function selHit(px,py){
    const layout=selectorLayout();
    for(let i=0;i<ROSTER.length;i++){
      const sx=layout.x+i*(SEL_CARD_W+SEL_GAP);
      if(px>=sx&&px<=sx+SEL_CARD_W&&py>=layout.y&&py<=layout.y+SEL_CARD_H)return i;
    }
    return -1;
  }
  function htStart(px,py){const bx=W/2-140,by=H/2+10;return px>=bx&&px<=bx+280&&py>=by&&py<=by+70;}
  function htSave(px,py){const bx=W/2-95,by=H/2+128;return px>=bx&&px<=bx+190&&py>=by&&py<=by+44;}
  function htAction(px,py){return px>=ACTION_RECT.x&&px<=ACTION_RECT.x+ACTION_RECT.w&&py>=ACTION_RECT.y&&py<=ACTION_RECT.y+ACTION_RECT.h;}
  function showHall(){
    hallReturnState = {
      phase:gs.phase, round:gs.round, roundN:gs.roundN, running:gs.running,
      dragging:gs.dragging, booha:gs.booha, campaignActive:gs.campaignActive,
      campaignComplete:gs.campaignComplete, shotLock:gs.shotLock,
      isLastBooha:gs.isLastBooha, timeScale:gs.timeScale, goalReached:gs.goalReached,
    };
    gs.phase=P.HALL;gs.running=false;gs.booha=null;gs.dragging=false;
    gs.campaignActive=false;
    ROSTER.forEach((_, index) => { if (isBoohaUnlocked(index)) ensureRosterThumb(index); });
    needsRender=true;
  }
  function returnFromHall() {
    if (hallReturnState) Object.assign(gs, hallReturnState);
    else gs.phase=P.TITLE;
    hallReturnState=null;
    needsRender=true;
  }
  function performExit() {
    // Hall is a temporary view. Restore the run before saving so exiting from
    // Hall cannot silently discard the active campaign state.
    if (hallReturnState) {
      Object.assign(gs, hallReturnState);
      hallReturnState=null;
    }
    if (gs.campaignActive && gs.runScore > 0) submitRunScore(false);
    window.location.href='karasuki.html?room=room_12';
  }
  function leaveGame() {
    exitConfirmOpen=true;
    needsRender=true;
  }
  function exitModalHit(px, py, choice) {
    const y=EXIT_MODAL.y+132, h=46;
    const cancel={x:EXIT_MODAL.x+82,y,w:150,h};
    const exit={x:EXIT_MODAL.x+268,y,w:150,h};
    const hit=choice==='exit'?exit:cancel;
    return px>=hit.x&&px<=hit.x+hit.w&&py>=hit.y&&py<=hit.y+hit.h;
  }

  // ── Pause menu ─────────────────────────────────────────
  // A real pause: unlike the old exit-only dialog, opening this does not
  // leave the sim running behind it — see tick(), which now checks
  // pauseOpen before stepping physics/FX at all.
  function openPause() {
    if (gs.phase !== P.PLAY) return;
    pauseOpen = true;
    gs.dragging = false; gs.pullPlayed = false;
    needsRender = true;
  }
  function closePause() {
    pauseOpen = false;
    needsRender = true;
  }
  function pauseLayout() {
    const m = PAUSE_MODAL, bw = m.w - 60, bh = 56, gap = 14;
    const startY = m.y + 128;
    const rows = [
      { id:'resume',  en:'RESUME',        jp:'つづける',       accent:true  },
      { id:'restart', en:'RESTART ROUND', jp:'ラウンドをやりなおす', accent:false },
      { id:'save',    en:'SAVE',          jp:'セーブ',         accent:false },
      { id:'exit',    en:'EXIT',          jp:'おわる',         accent:false, danger:true },
    ];
    return rows.map((row, i) => ({ ...row, x:m.x+30, y:startY+i*(bh+gap), w:bw, h:bh }));
  }
  function pauseHit(px, py) {
    return pauseLayout().find(b => px>=b.x&&px<=b.x+b.w&&py>=b.y&&py<=b.y+b.h)?.id || '';
  }

  function onDown(evt){
    const p=worldPt(evt);
    if(exitConfirmOpen){
      if(exitModalHit(p.x,p.y,'cancel')){exitConfirmOpen=false;needsRender=true;}
      else if(exitModalHit(p.x,p.y,'exit')){exitConfirmOpen=false;performExit();}
      evt.preventDefault();return;
    }
    if(pauseOpen){
      const hit = pauseHit(p.x,p.y);
      if(hit === 'resume') closePause();
      else if(hit === 'restart'){ closePause(); loadRound(gs.round); showBriefing(); }
      else if(hit === 'save'){ if(window.BoohaSaveMenu) BoohaSaveMenu.open(); }
      else if(hit === 'exit'){ closePause(); leaveGame(); }
      evt.preventDefault();return;
    }
    const dockAction = controlDockHit(p.x, p.y);

    if(dockAction === 'mute'){toggleMute();evt.preventDefault();return;}
    if(dockAction === 'help'){openHelp();evt.preventDefault();return;}
    if(dockAction === 'hall' && gs.phase !== P.HALL){showHall();evt.preventDefault();return;}
    if(dockAction === 'exit'){ if(gs.phase===P.PLAY) openPause(); else leaveGame(); evt.preventDefault();return;}
    if(dockAction === 'hall' && gs.phase === P.HALL){returnFromHall();evt.preventDefault();return;}
    getAC();

    if(gs.phase===P.TITLE){
      if(htStart(p.x,p.y)){beginCampaign();loadRound(0);showBriefing();}
      else if(htSave(p.x,p.y)){ if(window.BoohaSaveMenu) BoohaSaveMenu.open(); }
      evt.preventDefault();return;
    }
    if(gs.phase===P.HALL){
      evt.preventDefault();return;
    }
    if(gs.phase===P.BRIEF){
      if(htAction(p.x,p.y)) startRound();
      evt.preventDefault();return;
    }
    if(gs.phase===P.WIN||gs.phase===P.FAIL){
      if(htAction(p.x,p.y)){
        if(gs.phase===P.WIN && !gs.campaignComplete) advanceRound();
        else if(gs.phase===P.FAIL && gs.campaignActive){loadRound(gs.round);showBriefing();}
        else {beginCampaign();loadRound(0);showBriefing();}
      }
      evt.preventDefault();return;
    }
     
    const slot=selHit(p.x,p.y);
    if(slot!==-1&&!isBoohaUnlocked(slot)){
      setToast(`${ROSTER[slot].name}: ${unlockRequirement(slot)}`, '#ffdf80', 4200);
      evt.preventDefault();evt.stopPropagation();return;
    }
    if(slot!==-1&&bst.stocks[slot]>0&&!gs.shotLock){
      bst.sel=slot;if(gs.booha&&!gs.booha.launched)gs.booha=makeBooha();
      ensureRosterImage(slot);
      loadBuffer(ROSTER[slot].id, ROSTER[slot].sfx);
      evt.preventDefault();evt.stopPropagation();return;
    }
    if(!gs.booha||gs.booha.launched||gs.shotLock||gs.goalReached)return;
    if(!gs.running)startRound();
    if(dist(p.x,p.y,gs.booha.x,gs.booha.y)>gs.booha.radius+24)return;
    gs.dragging=true;gs.pullPlayed=false;sndPull();
    evt.preventDefault();evt.stopPropagation();
  }
  function onMove(evt){
    if(!gs.dragging||!gs.booha||gs.booha.launched)return;
    const p=worldPt(evt);
    const dx=p.x-SLING_X,dy=p.y-SLING_Y,d=Math.min(MAX_PULL,Math.hypot(dx,dy)),a=Math.atan2(dy,dx);
    gs.booha.x=SLING_X+Math.cos(a)*d;
    gs.booha.y=Math.min(SLING_Y+Math.sin(a)*d,FLOOR_Y-gs.booha.radius-4);
    evt.preventDefault();
  }
  function onUp(evt){
    if(!gs.dragging)return;
    gs.dragging=false;gs.pullPlayed=false;
    if(!gs.booha||gs.booha.launched||gs.shotLock)return;
    const dx=SLING_X-gs.booha.x,dy=SLING_Y-gs.booha.y,mag=Math.hypot(dx,dy);
    if(mag<12){gs.booha.x=SLING_X;gs.booha.y=SLING_Y;return;}
    bst.stocks[bst.sel]=Math.max(0,bst.stocks[bst.sel]-1);
    gs.shotsUsed++;
    gs.powerUsed.add(gs.booha.power);
    gs.booha.vx=dx*0.19;gs.booha.vy=dy*0.19;gs.booha.launched=true;gs.booha.damageThisShot=0;
    const remaining=bst.stocks.reduce((a,v)=>a+v,0);
    gs.isLastBooha=remaining===0;
    if(gs.isLastBooha){addShake(5);gs.timeScale=0.8;}
    spawnWave(SLING_X,SLING_Y,ROSTER[bst.sel]?.conf?.cols?.[0]||'#7cfff8',26);
    sndLaunch();
  }

  // ── Draw helpers ─────────────────────────────────────
  function rr(c,x,y,w,h,r,fill,stroke){
    c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();
    if(fill)c.fill();if(stroke)c.stroke();
  }
  function drawImageContain(img, x, y, w, h, pad=0) {
    if (!img || !img.naturalWidth || !img.naturalHeight) return false;
    const boxW = Math.max(1, w - pad * 2), boxH = Math.max(1, h - pad * 2);
    const scale = Math.min(boxW / img.naturalWidth, boxH / img.naturalHeight);
    const dw = img.naturalWidth * scale, dh = img.naturalHeight * scale;
    ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
    return true;
  }
  function rrClip(c,x,y,w,h,r){
    c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();c.clip();
  }

  // ── Draw: Background ─────────────────────────────────
  function buildBackgroundCache(){
    if (backgroundCache) return;
    backgroundCache=document.createElement('canvas');
    backgroundCache.width=W;backgroundCache.height=H;
    const c=backgroundCache.getContext('2d');
    if(gs.imgs.bg)c.drawImage(gs.imgs.bg,0,0,W,H);
    else{
      const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'#1e1c2a');g.addColorStop(1,'#0c0a12');
      c.fillStyle=g;c.fillRect(0,0,W,H);
    }
    c.fillStyle='rgba(0,0,0,0.18)';c.fillRect(0,H-80,W,80);

    // The playfield uses a quieter version of the same art. Bake that veil
    // once instead of painting a full-screen translucent rectangle every
    // frame on the iPad-sized canvas.
    playBackgroundCache=document.createElement('canvas');
    playBackgroundCache.width=W;playBackgroundCache.height=H;
    const play=playBackgroundCache.getContext('2d');
    play.drawImage(backgroundCache,0,0);
    play.fillStyle='rgba(5,10,10,0.28)';play.fillRect(0,0,W,H);
    const vignette=play.createRadialGradient(W*0.52,H*0.46,140,W*0.52,H*0.46,780);
    vignette.addColorStop(0,'rgba(0,0,0,0)');
    vignette.addColorStop(0.72,'rgba(0,0,0,0.05)');
    vignette.addColorStop(1,'rgba(0,0,0,0.28)');
    play.fillStyle=vignette;play.fillRect(0,0,W,H);
  }
  function drawBG(){
    buildBackgroundCache();
    const isPlay=gs.phase===P.PLAY;
    const tint=gs.phase!==P.TITLE&&gs.phase!==P.HALL ? currentLevel().chapterTint : '';
    const base=isPlay ? playBackgroundCache : backgroundCache;
    if (tint) {
      const key=`${isPlay?'play':'base'}:${tint}`;
      let tinted=tintedBackgroundCache.get(key);
      if (!tinted) {
        tinted=document.createElement('canvas');tinted.width=W;tinted.height=H;
        const c=tinted.getContext('2d');c.drawImage(base,0,0);c.fillStyle=tint;c.fillRect(0,0,W,H);
        tintedBackgroundCache.set(key,tinted);
      }
      ctx.drawImage(tinted,0,0);
    } else {
      ctx.drawImage(base,0,0);
    }
    if(gs.nightmareFlicker){
      const flk=(gs.nightmareFlickerTimer%8<4)?0.18:0;
      if(flk>0){ctx.fillStyle=`rgba(80,0,128,${flk})`;ctx.fillRect(0,0,W,H);}
    }
  }
  function drawViewportBackdrop(){
    if(!FULL_BLEED)return;
    if (!viewportBackdropCache || viewportBackdropHeight !== VIEW_H) {
      viewportBackdropCache=document.createElement('canvas');
      viewportBackdropCache.width=W;viewportBackdropCache.height=VIEW_H;
      viewportBackdropHeight=VIEW_H;
      const c=viewportBackdropCache.getContext('2d');
      c.fillStyle='#081014';c.fillRect(0,0,W,VIEW_H);
      const g=c.createLinearGradient(0,0,0,VIEW_H);
      g.addColorStop(0,'rgba(10,22,25,0.95)');
      g.addColorStop(0.5,'rgba(3,8,12,0.5)');
      g.addColorStop(1,'rgba(8,15,18,0.95)');
      c.fillStyle=g;c.fillRect(0,0,W,VIEW_H);
      c.fillStyle='rgba(124,255,248,0.09)';
      c.fillRect(0,SCENE_Y,W,1);c.fillRect(0,SCENE_Y+H-1,W,1);
    }
    ctx.drawImage(viewportBackdropCache,0,0);
  }
  function drawScorchMarks(){
    for(const s of scorchMarks){
      if(offscreen(s.x,s.y,s.r))continue;
      ctx.save();ctx.globalAlpha=s.life*0.46;ctx.fillStyle='#20140d';
      ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=s.life*0.22;ctx.strokeStyle='#c75b22';ctx.lineWidth=2;
      ctx.beginPath();ctx.arc(s.x,s.y,s.r*0.72,0,Math.PI*2);ctx.stroke();ctx.restore();
    }
  }
  function drawSling(){
    const b=gs.booha||makeBooha(0);
    const baseX=SLING_X,baseY=FLOOR_Y+4,topY=SLING_Y-52,lx=SLING_X-26,rx=SLING_X+26;
    ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
    ctx.beginPath();ctx.ellipse(baseX,baseY+7,14,5,0,0,Math.PI*2);ctx.fillStyle='rgba(0,0,0,0.3)';ctx.fill();
    for(const[sx,ex]of[[-6,lx],[6,rx]]){
      ctx.beginPath();ctx.moveTo(baseX+sx,baseY);ctx.quadraticCurveTo(baseX+sx*4.5,baseY-80,ex,topY);
      ctx.lineWidth=18;ctx.strokeStyle='#2a1608';ctx.stroke();
      ctx.lineWidth=13;ctx.strokeStyle='#5c3318';ctx.stroke();
    }
    ctx.beginPath();ctx.moveTo(baseX,baseY);ctx.lineTo(baseX,baseY-45);
    ctx.lineWidth=20;ctx.strokeStyle='#2a1608';ctx.stroke();ctx.lineWidth=15;ctx.strokeStyle='#5c3318';ctx.stroke();
    ctx.globalAlpha=0.18;ctx.strokeStyle='#e8a060';ctx.lineWidth=2;
    for(const[gsx,gex]of[[-3,lx+2],[3,rx-2]]){ctx.beginPath();ctx.moveTo(baseX+gsx,baseY-10);ctx.quadraticCurveTo(baseX+gsx*8,baseY-75,gex,topY+10);ctx.stroke();}
    ctx.globalAlpha=1;
    for(const[kx,ky]of[[lx,topY],[rx,topY]]){
      ctx.beginPath();ctx.arc(kx,ky,9,0,Math.PI*2);ctx.fillStyle='#2a1608';ctx.fill();
      ctx.beginPath();ctx.arc(kx,ky,7,0,Math.PI*2);ctx.fillStyle='#6e3e1e';ctx.fill();
      ctx.beginPath();ctx.arc(kx-2,ky-2,3,0,Math.PI*2);ctx.fillStyle='rgba(220,160,80,0.38)';ctx.fill();
      ctx.beginPath();ctx.arc(kx,ky,7,0,Math.PI*2);ctx.strokeStyle='#1a0e04';ctx.lineWidth=1.5;ctx.stroke();
    }
    if(!b.launched){
      const bx=gs.dragging?b.x:SLING_X,by=gs.dragging?b.y:SLING_Y;
      const stretch=Math.hypot(bx-SLING_X,by-SLING_Y)/MAX_PULL,bw=Math.max(2.5,6-stretch*3);
      ctx.globalAlpha=0.6;ctx.strokeStyle='#4a2a18';ctx.lineWidth=bw+2;
      ctx.beginPath();ctx.moveTo(lx,topY);ctx.lineTo(bx,by);ctx.stroke();
      ctx.beginPath();ctx.moveTo(rx,topY);ctx.lineTo(bx,by);ctx.stroke();
      ctx.globalAlpha=1;
      ctx.strokeStyle='#b06e35';ctx.lineWidth=bw;
      ctx.beginPath();ctx.moveTo(lx,topY);ctx.lineTo(bx,by);ctx.stroke();
      ctx.beginPath();ctx.moveTo(rx,topY);ctx.lineTo(bx,by);ctx.stroke();
      if(!gs.dragging){ctx.fillStyle='#5c3018';ctx.strokeStyle='#3a1e08';ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(bx,by,12,9,0,0,Math.PI*2);ctx.fill();ctx.stroke();}
    }
    ctx.restore();
  }
  function drawBooha(){
    const b=gs.booha; if(!b)return;
    if(b.power==='nightmare'&&gs.nightmareFlicker)return;
    if(b.power==='monster'&&gs.bounces>0){ctx.save();ctx.globalAlpha=0.28;ctx.strokeStyle='#44ff44';ctx.lineWidth=5;ctx.beginPath();ctx.arc(b.x,b.y,b.radius+5,0,Math.PI*2);ctx.stroke();ctx.restore();}
    if(b.power==='ice'){ctx.save();ctx.globalAlpha=0.35;ctx.beginPath();ctx.arc(b.x,b.y,b.radius+4,0,Math.PI*2);ctx.fillStyle='#aaeeff';ctx.fill();ctx.restore();}
    if(b.power==='rainbow'){ctx.save();ctx.globalAlpha=0.38;ctx.strokeStyle='#d68cff';ctx.lineWidth=5;ctx.beginPath();ctx.arc(b.x,b.y,b.radius+6,0,Math.PI*2);ctx.stroke();ctx.restore();}
    if(b.tellGlow>0){ctx.save();ctx.globalAlpha=b.tellGlow*0.85;ctx.strokeStyle='#ffffff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(b.x,b.y,b.radius*b.tellScaleX*1.1,0,Math.PI*2);ctx.stroke();ctx.restore();}
    if(gs.isLastBooha&&b.launched){const pulse=0.5+0.5*Math.sin(performance.now()*0.006);ctx.save();ctx.globalAlpha=0.3*pulse;ctx.strokeStyle='#ffdd44';ctx.lineWidth=5;ctx.beginPath();ctx.arc(b.x,b.y,b.radius+10,0,Math.PI*2);ctx.stroke();ctx.restore();}
    const img=bst.imgs[b.ri];
    ctx.save();ctx.translate(b.x,b.y);
    if(b.launched)ctx.rotate(Math.atan2(b.vy,b.vx)*0.2);
    ctx.scale(b.tellScaleX||1,b.tellScaleY||1);
    if(b.impactCompress>0){const ic=b.impactCompress;ctx.scale(1+ic*0.3,1-ic*0.2);}
    if(img){drawImageContain(img,-b.radius*1.4,-b.radius*1.4,b.radius*2.8,b.radius*2.8);}
    else{ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(0,0,b.radius,Math.PI,0,false);ctx.lineTo(b.radius,22);ctx.quadraticCurveTo(0,b.radius+12,-b.radius,22);ctx.closePath();ctx.fill();}
    ctx.restore();
  }
  function drawGhostSparks(){
    for(const p of sparks){
      if(p.type!=='ghost')continue;
      ctx.globalAlpha=clamp(p.life,0,1)*0.35;
      const img=bst.imgs[p.ri];
      if(img)drawImageContain(img,p.x-p.r,p.y-p.r,p.r*2,p.r*2);
      else{ctx.beginPath();ctx.arc(p.x,p.y,p.r*0.5,0,Math.PI*2);ctx.fillStyle='#9900ff';ctx.fill();}
    }
    ctx.globalAlpha=1;
  }
  function drawMinis(){
    for(const m of gs.minis){
      ctx.globalAlpha=clamp(m.life,0,1)*0.85;
      const img=bst.imgs[m.ri];
      if(img)drawImageContain(img,m.x-m.radius*1.4,m.y-m.radius*1.4,m.radius*2.8,m.radius*2.8);
      else{ctx.fillStyle='#ffaacc';ctx.beginPath();ctx.arc(m.x,m.y,m.radius,0,Math.PI*2);ctx.fill();}
    }
    ctx.globalAlpha=1;
  }

  // Static block art is rendered once and reused. The old path rebuilt these
  // gradients, grain dots, and glass highlights on every animation frame.
  const BLOCK_TEXTURE_CACHE = new Map();
  // Deterministic 0..1 hash, used for speckle/grain placement so a block's
  // texture only ever gets *lighter or darker* as its damage tier changes —
  // never re-randomized. Seeding on (w, h, index) rather than on hp/fill
  // means every tier's rebuild lands on the exact same dot layout.
  function detRand(a, b) {
    const s = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453;
    return s - Math.floor(s);
  }
  function getBlockTexture(block) {
    const fill = matFill(block);
    const key = [block.material, fill, Math.round(block.w), Math.round(block.h)].join('|');
    if (BLOCK_TEXTURE_CACHE.has(key)) return BLOCK_TEXTURE_CACHE.get(key);

    const w = Math.max(1, Math.ceil(block.w));
    const h = Math.max(1, Math.ceil(block.h));
    const out = document.createElement('canvas');
    out.width = w; out.height = h;
    const c = out.getContext('2d');
    const m = MAT[block.material] || MAT.wood;
    const fg = c.createLinearGradient(0, 0, 0, h);
    fg.addColorStop(0, lighten(fill, 0.12));
    fg.addColorStop(0.5, fill);
    fg.addColorStop(1, darken(fill, 0.14));
    c.fillStyle = fg;
    c.strokeStyle = darken(m.edge, 0.3);
    c.lineWidth = 2;
    rr(c, 0, 0, w, h, 8, true, true);

    if (block.material === 'glass') {
      const sg = c.createLinearGradient(0, 0, w * 0.7, h * 0.7);
      sg.addColorStop(0, 'rgba(255,255,255,0.9)');
      sg.addColorStop(0.5, 'rgba(255,255,255,0)');
      c.save(); c.globalAlpha = 0.22; c.fillStyle = sg;
      rrClip(c, 0, 0, w, h, 8); c.fillRect(0, 0, w, h); c.restore();
    } else if (block.material === 'stone') {
      c.save(); c.globalAlpha = 0.08; rrClip(c, 0, 0, w, h, 8);
      const n = ~~(w * h / 200);
      for (let d = 0; d < n; d++) {
        const dx = 6 + detRand(w, d * 1.7 + 1) * Math.max(1, w - 12);
        const dy = 6 + detRand(h, d * 2.3 + 7) * Math.max(1, h - 12);
        const dr = 1 + detRand(d, w + h) * 1.5;
        c.beginPath();
        c.arc(dx, dy, dr, 0, Math.PI * 2);
        c.fillStyle = detRand(d * 3.1, h - w) < 0.5 ? 'rgba(255,255,255,0.8)' : 'rgba(0,0,0,0.6)';
        c.fill();
      }
      c.restore();
    } else if (block.material === 'soft') {
      c.save(); c.globalAlpha = 0.13; rrClip(c, 0, 0, w, h, 8);
      for (let d = 0; d < 6; d++) {
        const dx = 6 + detRand(w, d * 2.9 + 3) * Math.max(1, w - 12);
        const dy = 6 + detRand(h, d * 4.1 + 5) * Math.max(1, h - 12);
        const dr = 1.5 + detRand(d, w * h) * 1.5;
        c.beginPath();
        c.arc(dx, dy, dr, 0, Math.PI * 2);
        c.fillStyle = 'rgba(255,255,255,0.9)'; c.fill();
      }
      c.restore();
    } else if (m.grain) {
      c.save(); c.globalAlpha = 0.09; c.strokeStyle = 'rgba(255,210,160,0.5)'; c.lineWidth = 1;
      rrClip(c, 0, 0, w, h, 8);
      for (let y = 0, gi = 0; y < h; y += 8, gi++) {
        const j1 = (detRand(w, gi * 5.3 + 2) - 0.5) * 2;
        const j2 = (detRand(h, gi * 6.1 + 9) - 0.5) * 2;
        c.beginPath(); c.moveTo(0, y + j1); c.lineTo(w, y + j2); c.stroke();
      }
      c.restore();
    }

    // Cheap baked edge lighting makes the blocks read as objects with mass,
    // rather than flat interface cards. It costs nothing during animation.
    c.save();
    rrClip(c, 0, 0, w, h, 8);
    c.lineCap='round';c.lineWidth=2;
    c.strokeStyle='rgba(255,255,255,0.22)';
    c.beginPath();c.moveTo(7,1);c.lineTo(Math.max(7,w-8),1);c.moveTo(1,7);c.lineTo(1,Math.max(7,h-8));c.stroke();
    c.strokeStyle='rgba(0,0,0,0.24)';c.lineWidth=2;
    c.beginPath();c.moveTo(7,h-1);c.lineTo(Math.max(7,w-8),h-1);c.moveTo(w-1,7);c.lineTo(w-1,Math.max(7,h-8));c.stroke();
    c.restore();

    BLOCK_TEXTURE_CACHE.set(key, out);
    return out;
  }

  // v4: drawBlocks — adds trait glow border on immune/resistant blocks
  function drawBlocks(){
    const glowTime=performance.now();
    for(let i=0;i<gs.blocks.length;i++){
      const block=gs.blocks[i];
      if(offscreen(block.x,block.y,Math.max(block.w,block.h)))continue;
      const sx=block.shake ? (rnd()-0.5)*8*block.shake : 0;
      const sy=block.shake ? (rnd()-0.5)*6*block.shake : 0;
      const compY=block.compressY||0;
      const bx=block.x-block.w/2,by=block.y-block.h/2+compY,bw=block.w,bh=block.h-compY;
      const load=supportLoad(block,i);

      ctx.save();
      ctx.globalAlpha = block.broken ? 0.28 : (block.falling ? 0.88 : 1);
      ctx.translate(sx, sy);

      if (block.falling) {
        const tilt = clamp(block.vy * 0.012, -0.26, 0.26);
        ctx.translate(block.x, block.y);
        ctx.rotate(tilt);
        ctx.translate(-block.x, -block.y);
      }

      if(block.frozen){
        ctx.fillStyle='#c0f0ff';ctx.strokeStyle='#88ddff';ctx.lineWidth=2;rr(ctx,bx,by,bw,bh,8,true,true);
        ctx.globalAlpha*=0.5;ctx.fillStyle='rgba(170,240,255,0.4)';rr(ctx,bx,by,bw,bh,8,true,false);ctx.restore();continue;
      }
      if(!block.broken&&!block.falling){
        ctx.save();ctx.globalAlpha=0.22;ctx.fillStyle='#071014';
        ctx.beginPath();ctx.ellipse(block.x,by+bh+3,Math.max(8,bw*0.34),3,0,0,Math.PI*2);ctx.fill();ctx.restore();
      }
      if(load>0&&!block.broken){
        const emphasis=gs.dragging||load>1;
        ctx.save();ctx.globalAlpha=emphasis?0.78:0.42;
        ctx.fillStyle=load>1?'#ffcf70':'#7cfff8';
        rr(ctx,bx+8,by+bh+6,Math.min(bw-16,12+load*18),3,2,true,false);
        ctx.restore();
      }
      if(block.burning&&!block.broken){ctx.save();ctx.globalAlpha=(block.burnTimer/120)*0.4;ctx.fillStyle='#ff6600';rr(ctx,bx-2,by-2,bw+4,bh+4,10,true,false);ctx.restore();}
      ctx.drawImage(getBlockTexture(block), bx, by, bw, bh);
      if(!block.broken&&block.maxHp>1){
        const hr=clamp(block.hp/block.maxHp,0,1);
        ctx.fillStyle='rgba(0,0,0,0.35)';rr(ctx,bx+8,by+bh-12,bw-16,7,3,true,false);
        ctx.fillStyle=hr>0.66?'#44ee77':hr>0.33?'#ffcc33':'#ff4444';rr(ctx,bx+8,by+bh-12,(bw-16)*hr,7,3,true,false);
      }
      if(block.hitFlash>0){
        ctx.save();
        ctx.globalCompositeOperation='lighter';
        ctx.fillStyle=`rgba(255,255,255,${0.22*block.hitFlash})`;
        rr(ctx,bx,by,bw,bh,8,true,false);
        ctx.restore();
      }
      ctx.strokeStyle='rgba(0,0,0,0.25)';ctx.lineWidth=1.5;rr(ctx,bx+1.5,by+1.5,bw-3,bh-3,7,false,true);

      // v4: trait glow — pulsing coloured border signals immunity to player
      if (!block.broken) {
        const glowCol = traitGlowColor(block);
        if (glowCol) {
          const pulse = LOW_POWER ? 0.62 : 0.45 + 0.35 * Math.sin(glowTime * 0.004 + i);
          ctx.save();
          ctx.globalAlpha = pulse * 0.72;
          ctx.strokeStyle = glowCol;
          ctx.lineWidth = 3.5;
          rr(ctx, bx - 1, by - 1, bw + 2, bh + 2, 9, false, true);
          ctx.restore();
        }
        if (block.marked) {
          const pulse = REDUCED_MOTION ? 0.75 : 0.55 + 0.35 * Math.sin(performance.now() * 0.006);
          ctx.save();
          ctx.globalAlpha = pulse;
          ctx.strokeStyle = '#ffe66d';
          ctx.lineWidth = 2.5;
          ctx.setLineDash([8, 5]);
          rr(ctx, bx - 6, by - 6, bw + 12, bh + 12, 12, false, true);
          ctx.setLineDash([]);
          ctx.fillStyle = '#ffe66d';
          ctx.font = 'bold 13px system-ui,sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('◆', block.x, by - 14);
          ctx.restore();
        }
        const badge=traitBadge(block);
        if (badge && block.w>=46 && block.h>=24) {
          const badgeW=Math.min(block.w-6,Math.max(30,badge.length*6.2+10));
          const badgeX=block.x-badgeW/2;
          const badgeY=Math.max(5,by-14);
          ctx.save();
          ctx.fillStyle='rgba(4,7,12,0.9)';ctx.strokeStyle=glowCol||'#fff';ctx.lineWidth=1;
          rr(ctx,badgeX,badgeY,badgeW,13,5,true,true);
          ctx.fillStyle='#fff';ctx.font='bold 8px system-ui,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
          ctx.fillText(badge,block.x,badgeY+6.5);
          ctx.restore();
        }
      }

      ctx.restore();
      if(!block.broken)drawCracks(block,i);
    }
  }

  const TRAJ_POINTS = Array.from({length:22}, () => ({x:0,y:0}));
  function drawTraj(){
    if(!gs.dragging||!gs.booha)return;
    const b=gs.booha;
    let tx=b.x,ty=b.y,tvx=(SLING_X-b.x)*0.19,tvy=(SLING_Y-b.y)*0.19;
    for(let i=0;i<22;i++){
      tvy+=GRAVITY;tvx*=AIR;tvy*=AIR;tx+=tvx;ty+=tvy;
      TRAJ_POINTS[i].x=tx;TRAJ_POINTS[i].y=ty;
    }
    const accent=ROSTER[bst.sel]?.conf?.cols?.[0] || '#7cfff8';
    ctx.save();
    for(let i=0;i<TRAJ_POINTS.length;i++){
      const point=TRAJ_POINTS[i], fade=(1-i/TRAJ_POINTS.length)*0.72;
      const radius=Math.max(1.8,5.5-i*0.2);
      // A dark keyline keeps the guide visible over bright forest and blocks.
      ctx.globalAlpha=fade*0.85;ctx.fillStyle='rgba(0,0,0,0.72)';
      ctx.beginPath();ctx.arc(point.x,point.y,radius+2.2,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=fade;ctx.fillStyle=accent;
      ctx.beginPath();ctx.arc(point.x,point.y,radius,0,Math.PI*2);ctx.fill();
    }
    const end=TRAJ_POINTS[TRAJ_POINTS.length-1];
    if(end){
      ctx.globalAlpha=0.82;ctx.strokeStyle=accent;ctx.lineWidth=2;
      ctx.beginPath();ctx.arc(end.x,end.y,11,0,Math.PI*2);ctx.stroke();
      ctx.globalAlpha=0.5;ctx.beginPath();ctx.moveTo(end.x-17,end.y);ctx.lineTo(end.x+17,end.y);ctx.moveTo(end.x,end.y-17);ctx.lineTo(end.x,end.y+17);ctx.stroke();
    }
    const pull=clamp(Math.hypot(b.x-SLING_X,b.y-SLING_Y)/MAX_PULL,0,1);
    const meterX=SLING_X+64,meterY=FLOOR_Y-58,meterW=138,meterH=28;
    ctx.globalAlpha=0.9;ctx.fillStyle='rgba(5,8,14,0.84)';ctx.strokeStyle='rgba(255,255,255,0.28)';ctx.lineWidth=1;
    rr(ctx,meterX,meterY,meterW,meterH,9,true,true);
    ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='rgba(255,255,255,0.86)';ctx.font='bold 9px system-ui,sans-serif';
    ctx.fillText('POWER / ちから',meterX+meterW/2,meterY+8);
    ctx.fillStyle='rgba(255,255,255,0.16)';rr(ctx,meterX+10,meterY+16,meterW-20,5,3,true,false);
    if (!hudMeterGradient || hudMeterGradientWidth !== meterW) {
      hudMeterGradient=ctx.createLinearGradient(meterX+10,0,meterX+meterW-10,0);
      hudMeterGradient.addColorStop(0,'#44ffcc');hudMeterGradient.addColorStop(0.7,'#ffdf44');hudMeterGradient.addColorStop(1,'#ff5555');
      hudMeterGradientWidth=meterW;
    }
    ctx.fillStyle=hudMeterGradient;rr(ctx,meterX+10,meterY+16,(meterW-20)*pull,5,3,true,false);
    ctx.restore();
  }
  function drawGround(){
    ctx.fillStyle='rgba(255,255,255,0.18)';ctx.fillRect(0,FLOOR_Y-6,W,3);
    ctx.fillStyle='rgba(255,255,255,0.06)';ctx.fillRect(0,FLOOR_Y-3,W,7);
  }
  function drawFXBehind(){
    for(const d of dusts){if(offscreen(d.x,d.y||0,d.r))continue;ctx.globalAlpha=d.life*0.22;ctx.beginPath();ctx.arc(d.x,d.y||0,d.r,0,Math.PI*2);ctx.fillStyle='rgba(200,190,180,0.5)';ctx.fill();}
    for(const w of waves){if(offscreen(w.x,w.y,w.r))continue;ctx.globalAlpha=w.life*0.7;ctx.strokeStyle=w.col;ctx.lineWidth=(w.thick||2.5)*w.life;ctx.beginPath();ctx.arc(w.x,w.y,w.r,0,Math.PI*2);ctx.stroke();}
    ctx.globalAlpha=1;
  }
  function drawFXFront(){
    drawGhostSparks();
    for(const p of impactBursts){
      if(offscreen(p.x,p.y,p.maxR))continue;
      ctx.globalAlpha=clamp(p.life,0,1)*0.9;
      ctx.strokeStyle=p.col;ctx.lineWidth=p.thick*(0.65+0.35*p.life);
      ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.stroke();
      if(p.kind==='break'||p.kind==='break-weak'){
        ctx.globalAlpha*=0.55;ctx.lineWidth=1.5;
        ctx.beginPath();ctx.arc(p.x,p.y,Math.max(2,p.r*0.58),0,Math.PI*2);ctx.stroke();
      }
      if(p.weak){
        ctx.globalAlpha*=0.7;ctx.lineWidth=1.5;
        const tick=Math.max(5,p.r*0.32),gap=Math.max(7,p.r*0.58);
        ctx.beginPath();
        ctx.moveTo(p.x-gap,p.y-tick);ctx.lineTo(p.x-gap,p.y-tick-4);ctx.lineTo(p.x-gap+4,p.y-tick-4);
        ctx.moveTo(p.x+gap,p.y+tick);ctx.lineTo(p.x+gap,p.y+tick+4);ctx.lineTo(p.x+gap-4,p.y+tick+4);
        ctx.stroke();
      }
    }
    for(const p of sparks){
      if(p.type==='ghost')continue;
      if(offscreen(p.x,p.y,p.r))continue;
      ctx.globalAlpha=clamp(p.life,0,1)*(p.alpha||1);ctx.fillStyle=p.col;
      if(p.type==='shard'){
        ctx.save();ctx.translate(p.x,p.y);if(p.rot!==undefined)ctx.rotate(p.rot);
        const s=p.r;ctx.beginPath();ctx.moveTo(0,-s);ctx.lineTo(s*0.7,s*0.6);ctx.lineTo(-s*0.7,s*0.4);ctx.closePath();ctx.fillStyle=p.col;ctx.strokeStyle='rgba(180,240,255,0.6)';ctx.lineWidth=0.8;ctx.fill();ctx.stroke();ctx.restore();
      } else if(p.type==='chip'){
        ctx.fillRect(p.x-p.r*0.6,p.y-p.r*0.4,p.r*1.2,p.r*0.8);
      } else {
        ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();
      }
    }
    ctx.globalAlpha=1;
    drawScorchMarks();
    drawClangLabels();
  }
  function drawFlash(){
    if(gs.flash<=0)return;
    ctx.save();ctx.fillStyle=`rgba(255,255,255,${0.11*gs.flash})`;ctx.fillRect(0,0,W,H);ctx.restore();
    gs.flash*=0.74;
  }

  function drawControlDock(){
    const items = controlDockLayout();
    ctx.save();
    ctx.textAlign='center';ctx.textBaseline='middle';
    for (const item of items) {
      const isBack = item.id === 'hall' && gs.phase === P.HALL;
      const isExit = item.id === 'exit';
      const isPauseBtn = isExit && gs.phase === P.PLAY;
      ctx.fillStyle = isPauseBtn ? 'rgba(124,255,248,0.14)' : isExit ? 'rgba(255,108,108,0.16)' : 'rgba(5,8,14,0.84)';
      ctx.strokeStyle = isPauseBtn ? 'rgba(124,255,248,0.55)' : isExit ? 'rgba(255,150,150,0.64)' : 'rgba(255,255,255,0.35)';
      ctx.lineWidth = 1.5;
      rr(ctx,item.x,item.y,item.w,item.h,10,true,true);
      ctx.fillStyle = isPauseBtn ? '#7cfff8' : isExit ? '#ffb0a8' : (item.id === 'mute' && !AUDIO_STATE.muted ? '#7cfff8' : '#fff');
      ctx.font = `bold ${item.id === 'hall' ? 11 : isPauseBtn ? 15 : 13}px system-ui,sans-serif`;
      const label = isBack ? 'BACK' : isPauseBtn ? '❚❚' : (item.id === 'mute' && AUDIO_STATE.muted ? '×' : item.label);
      ctx.fillText(label, item.x + item.w / 2, item.y + item.h / 2);
    }
    ctx.restore();
  }

  function drawSelector(){
    const layout=selectorLayout();
    const total=ROSTER.length*SEL_CARD_W+(ROSTER.length-1)*SEL_GAP;
    ctx.save();
    ctx.fillStyle='rgba(5,8,12,0.82)';ctx.strokeStyle='rgba(124,255,248,0.2)';ctx.lineWidth=1;
    rr(ctx,layout.x-10,layout.y-8,total+20,SEL_CARD_H+16,14,true,true);
    ctx.restore();
    ctx.save();
    for(let i=0;i<ROSTER.length;i++){
      const sx=layout.x+i*(SEL_CARD_W+SEL_GAP),sy=layout.y;
      const unlocked=isBoohaUnlocked(i),stock=bst.stocks[i],isSel=i===bst.sel,isAvail=unlocked&&stock>0;
      ctx.save();ctx.globalAlpha=isSel?0.96:(unlocked?0.72:0.52);
      ctx.fillStyle=isSel?'rgba(255,255,255,0.2)':(unlocked?'rgba(8,6,16,0.7)':'rgba(8,6,16,0.86)');
      ctx.strokeStyle=isSel?'#7cfff8':(unlocked?'rgba(255,255,255,0.12)':'rgba(255,223,128,0.25)');ctx.lineWidth=isSel?2.5:1;
      rr(ctx,sx,sy,SEL_CARD_W,SEL_CARD_H,10,true,true);ctx.restore();
      const img=bst.thumbs[i] || bst.imgs[i];
      ctx.save();ctx.globalAlpha=isAvail?(isSel?1:0.72):0.16;
      if(!unlocked){
        ctx.fillStyle='#ffdf80';ctx.font='bold 18px system-ui,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('🔒',sx+SEL_CARD_W/2,sy+SEL_CARD_H/2-3);
      } else if(img)drawImageContain(img,sx+5,sy+3,SEL_CARD_W-10,SEL_CARD_H-16);
      else{ctx.beginPath();ctx.arc(sx+SEL_CARD_W/2,sy+SEL_CARD_H/2-5,14,0,Math.PI*2);ctx.fillStyle='#aaa';ctx.fill();}
      ctx.restore();
      const bw=stock>=10?30:26;
      ctx.save();ctx.globalAlpha=unlocked?1:0.55;
      ctx.fillStyle=unlocked?(isSel?'#fff':'rgba(255,255,255,0.55)'):'rgba(255,223,128,0.22)';
      ctx.strokeStyle='rgba(0,0,0,0.4)';ctx.lineWidth=1;rr(ctx,sx+SEL_CARD_W-bw-2,sy+SEL_CARD_H-14,bw,12,6,true,true);
      ctx.fillStyle=unlocked?(isSel?'#111':'#333'):'#ffdf80';ctx.font='bold 9px system-ui,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(unlocked?`×${stock}`:'LOCK',sx+SEL_CARD_W-bw*0.5-2,sy+SEL_CARD_H-8);ctx.restore();
      if(isSel&&unlocked){
        const pulse=REDUCED_MOTION?0.65:0.5+0.5*Math.sin(performance.now()*0.004);
        ctx.save();ctx.globalAlpha=0.25*pulse;ctx.strokeStyle='#fff';ctx.lineWidth=3;rr(ctx,sx-2,sy-2,SEL_CARD_W+4,SEL_CARD_H+4,12,false,true);ctx.restore();
      }
    }
    ctx.restore();
  }
  function drawHUD(){
    const level=currentLevel(), chapter=currentChapter(), rule=currentRule();
    const panels=[];
    const addPanel=(en,jp,value,accent)=>panels.push({en,jp,value,accent});
    addPanel('SCORE','スコア',scoreText(gs.runScore),'#ffdf80');
    addPanel('SHOTS','のこり',String(gs.ghostsLeft),gs.isLastBooha?'#ff5555':'#ff9f7f');
    addPanel('LIVES','いのち',`${gs.lives}/${MAX_RUN_LIVES}`,gs.lives<=1?'#ff5555':'#ffcf70');
    addPanel('DAMAGE','はかい',`${Math.round(gs.pct)}%`,'#7cfff8');
    if(gs.phase!==P.PLAY) addPanel('GOAL','もくひょう',`${level.targetPercent||100}%`,'#ffdf80');
    if(rule?.type==='time_attack') addPanel('TIME','じかん',`${Math.ceil(Math.max(0,gs.ruleTime))}s`,gs.ruleTime<10?'#ff5555':'#ff9f7f');

    if(gs.isLastBooha&&gs.phase===P.PLAY){
      const pulse=REDUCED_MOTION?0.65:0.5+0.5*Math.sin(performance.now()*0.005);
      ctx.save();ctx.globalAlpha=0.22*pulse;ctx.strokeStyle='#ff4444';ctx.lineWidth=6;ctx.strokeRect(0,0,W,H);ctx.restore();
    }
    if(level.boss){
      const pulse=REDUCED_MOTION?0.6:0.45+0.2*Math.sin(performance.now()*0.004);
      ctx.save();ctx.globalAlpha=pulse;ctx.strokeStyle=level.bossProfile?.accent || chapter.accent || '#ffdf80';ctx.lineWidth=3;ctx.strokeRect(8,10,W-16,H-18);ctx.restore();
    }

    const pw=112,ph=62,gap=6;
    const statsWidth=panels.length*pw+(panels.length-1)*gap;
    const statsX=W-14-statsWidth;
    const barX=118,barW=Math.max(300,Math.min(500,statsX-barX-28)),barY=92;
    const headerW=Math.max(260,statsX-112);
    ctx.save();ctx.fillStyle='rgba(5,8,14,0.82)';ctx.strokeStyle='rgba(255,255,255,0.24)';ctx.lineWidth=1.5;rr(ctx,104,10,headerW,80,12,true,true);ctx.restore();
    ctx.save();ctx.fillStyle='rgba(0,0,0,0.42)';ctx.strokeStyle='rgba(255,255,255,0.2)';ctx.lineWidth=1;rr(ctx,barX-4,barY-3,barW+8,15,7,true,true);
    ctx.fillStyle='rgba(255,255,255,0.2)';rr(ctx,barX,barY,barW,9,5,true,false);
    if (!goalGradient || goalGradientWidth !== barW) {
      goalGradient=ctx.createLinearGradient(barX,0,barX+barW,0);
      goalGradient.addColorStop(0,'#ff7cfb');goalGradient.addColorStop(0.5,'#7cfff8');goalGradient.addColorStop(1,'#ffdf80');
      goalGradientWidth=barW;
    }
    ctx.fillStyle=goalGradient;rr(ctx,barX,barY,barW*clamp(gs.pct/100,0,1),9,5,true,false);ctx.restore();

    ctx.save();ctx.fillStyle='rgba(8,6,16,0.86)';ctx.strokeStyle='rgba(255,255,255,0.22)';ctx.lineWidth=1.5;rr(ctx,14,12,84,62,12,true,true);ctx.restore();
    ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='rgba(255,255,255,0.6)';ctx.font='bold 9px system-ui,sans-serif';ctx.fillText('ROUND / ラウンド',56,27);
    ctx.fillStyle='#fff';ctx.font='bold 24px system-ui,sans-serif';ctx.fillText(String(gs.roundN),56,53);

    ctx.textAlign='left';ctx.fillStyle=chapter.accent||'#fff';ctx.font='bold 14px system-ui,sans-serif';
    ctx.fillText(`CHAPTER ${level.chapter||1} · ${level.chapterName||'CAMPAIGN'}`,112,28);
    ctx.fillStyle='#fff';ctx.font='bold 20px system-ui,sans-serif';ctx.fillText(fitText(`${level.name||''}`, headerW-24),112,53);
    const selected=ROSTER[bst.sel]||ROSTER[0];
    ctx.fillStyle='rgba(255,255,255,0.78)';ctx.font='13px system-ui,sans-serif';
    ctx.fillText(`BOOHA · ${selected.name}`,112,75);
    ctx.fillStyle='rgba(255,255,255,0.54)';ctx.font='11px system-ui,sans-serif';
    ctx.fillStyle=gs.goalReached?'#ffe66d':'rgba(255,255,255,0.54)';
    ctx.fillText(gs.goalReached ? 'GOAL REACHED! · CLEARING…' : `DAMAGE ${Math.round(gs.pct)}% / ${level.targetPercent||100}%`,barX,barY+25);

    let px=statsX;
    for(const panel of panels){
      ctx.save();ctx.fillStyle='rgba(8,6,16,0.88)';ctx.strokeStyle='rgba(255,255,255,0.18)';ctx.lineWidth=1.5;rr(ctx,px,12,pw,ph,12,true,true);ctx.restore();
      ctx.textAlign='center';ctx.fillStyle='rgba(255,255,255,0.78)';ctx.font='bold 11px system-ui,sans-serif';ctx.fillText(panel.en,px+pw/2,27);
      ctx.fillStyle='rgba(255,255,255,0.62)';ctx.font='11px system-ui,sans-serif';ctx.fillText(panel.jp,px+pw/2,40);
      ctx.fillStyle=panel.accent;ctx.font='bold 22px system-ui,sans-serif';ctx.fillText(panel.value,px+pw/2,61);px+=pw+gap;
    }

    if(gs.combo>0&&gs.phase===P.PLAY){
      ctx.textAlign='left';ctx.globalAlpha=0.7+gs.comboPulse*0.3;ctx.fillStyle='#ffcf70';ctx.font='bold 13px system-ui,sans-serif';
      ctx.fillText(`STREAK / れんぞく ×${gs.combo}`,barX+barW-150,barY+25);ctx.globalAlpha=1;
    }
    ctx.textAlign='left';
    drawSelector();
    drawControlDock();
  }

  function drawTitle(){
    const t=performance.now();

    // Atmospheric vignette instead of a flat dim, so the background art and
    // the rising embers (see tick()) actually read, while text stays legible.
    const vg=ctx.createRadialGradient(W/2,H*0.42,60,W/2,H*0.42,W*0.62);
    vg.addColorStop(0,'rgba(24,12,4,0.30)');vg.addColorStop(0.6,'rgba(6,4,10,0.56)');vg.addColorStop(1,'rgba(2,1,4,0.82)');
    ctx.fillStyle=vg;ctx.fillRect(0,0,W,H);

    ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';

    // A slow shockwave — one cyan ring, one ember-orange ring — pulses out
    // from behind the wordmark on a loop. A preview of "impact" before
    // you've thrown anything yet.
    const cyc=(t%2600)/2600;
    for(let i=0;i<2;i++){
      const ph=(cyc+i*0.5)%1, r=40+ph*230;
      ctx.save();ctx.globalAlpha=(1-ph)*0.28;ctx.strokeStyle=i===0?'#7cfff8':'#ffaa33';ctx.lineWidth=2.5;
      ctx.beginPath();ctx.arc(W/2,H/2-86,r,0,Math.PI*2);ctx.stroke();ctx.restore();
    }

    const glowPulse=0.5+0.5*Math.sin(t*0.0016);
    ctx.font='bold 76px system-ui,sans-serif';ctx.fillStyle='#fff';
    ctx.shadowColor='#aaa';ctx.shadowBlur=10+glowPulse*6;ctx.fillText('BOOHA',W/2,H/2-115);ctx.shadowBlur=0;
    ctx.font='bold 40px system-ui,sans-serif';ctx.fillStyle='#ffdd44';ctx.shadowColor='#ffaa00';ctx.shadowBlur=10+glowPulse*8;
    ctx.fillText('DESTRUCTION',W/2,H/2-58);ctx.shadowBlur=0;

    ctx.strokeStyle='rgba(124,255,248,0.4)';ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(W/2-80,H/2-34);ctx.lineTo(W/2+80,H/2-34);ctx.stroke();

    ctx.font='15px system-ui,sans-serif';ctx.fillStyle='rgba(255,255,255,0.6)';
    ctx.fillText('Pull back and let fly! / ひっぱって、はなそう！',W/2,H/2-16);
    const bx=W/2-140,by=H/2+10,bw=280,bh=70;
    const bg=ctx.createLinearGradient(bx,by,bx,by+bh);bg.addColorStop(0,'#ffe566');bg.addColorStop(1,'#ff9900');
    ctx.shadowColor='#ffdd44';ctx.shadowBlur=16+glowPulse*10;
    ctx.fillStyle=bg;rr(ctx,bx,by,bw,bh,18,true,false);ctx.shadowBlur=0;
    ctx.strokeStyle='rgba(255,255,255,0.35)';ctx.lineWidth=2;rr(ctx,bx,by,bw,bh,18,false,true);
    ctx.fillStyle='#1a0e00';ctx.font='bold 25px system-ui,sans-serif';ctx.fillText('START / はじめる',W/2,by+bh/2);
    ctx.font='13px system-ui,sans-serif';ctx.fillStyle='rgba(255,255,255,0.62)';
    ctx.fillText(`${CHAPTERS.length || 5} chapters · ${LEVELS.length} rounds · Best ${scoreText(gs.highScore)}`,W/2,H/2+100);

    const sbx=W/2-95,sby=H/2+128,sbw=190,sbh=44;
    ctx.fillStyle='rgba(124,255,248,0.1)';ctx.strokeStyle='rgba(124,255,248,0.5)';ctx.lineWidth=1.5;
    rr(ctx,sbx,sby,sbw,sbh,14,true,true);
    ctx.fillStyle='#7cfff8';ctx.font='bold 15px system-ui,sans-serif';
    ctx.fillText('💾 SAVE / セーブ',W/2,sby+sbh/2);

    ctx.restore();
    drawControlDock();
  }

  function drawHall(){
    const stats=hallStats();
    ctx.fillStyle='rgba(5,4,14,0.94)';ctx.fillRect(0,0,W,H);
    ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillStyle='#ffdf80';ctx.font='bold 34px system-ui,sans-serif';ctx.fillText('HALL OF FAME / 殿堂',W/2,30);
    ctx.fillStyle='rgba(255,255,255,0.5)';ctx.font='12px system-ui,sans-serif';ctx.fillText(`Your records / きろく · Contracts ${stats.contractClears} · Rules ${stats.ruleClears}`,W/2,54);
    const summary=[
      ['BEST / ベスト',scoreText(gs.highScore),'#ffdf80'],
      ['ROUNDS / ラウンド',`${stats.rounds}/${LEVELS.length}`,'#7cfff8'],
      ['MEDALS / メダル',`${stats.medals}`,'#ffe66d'],
      ['BOOHA / ブーハー',`${stats.unlocked}/${ROSTER.length}`,'#ff9f7f'],
    ];
    const sw=176,sg=12;let sx=(W-summary.length*(sw+sg)+sg)/2;
    for(const item of summary){
      ctx.save();ctx.fillStyle='rgba(255,255,255,0.07)';ctx.strokeStyle='rgba(255,255,255,0.18)';ctx.lineWidth=1;rr(ctx,sx,68,sw,48,10,true,true);ctx.restore();
      ctx.fillStyle='rgba(255,255,255,0.55)';ctx.font='bold 9px system-ui,sans-serif';ctx.fillText(item[0],sx+sw/2,81);
      ctx.fillStyle=item[2];ctx.font='bold 18px system-ui,sans-serif';ctx.fillText(item[1],sx+sw/2,101);sx+=sw+sg;
    }

    ctx.textAlign='left';
    for(let chapterIndex=0;chapterIndex<5;chapterIndex++){
      const chapter=CHAPTERS[chapterIndex]||{};
      const y=130+chapterIndex*62;
      const levels=LEVELS.slice(chapterIndex*10,chapterIndex*10+10);
      const cleared=levels.filter(level=>getRoundRecord(level).clears>0).length;
      const complete=cleared===10;
      ctx.save();ctx.fillStyle='rgba(255,255,255,0.055)';ctx.strokeStyle=complete?(chapter.accent||'#7cfff8'):'rgba(255,255,255,0.12)';ctx.lineWidth=complete?1.5:1;rr(ctx,28,y,1224,52,10,true,true);ctx.restore();
      ctx.fillStyle=chapter.accent||'#fff';ctx.font='bold 11px system-ui,sans-serif';ctx.fillText(`CH ${chapterIndex+1} / チャプター${chapterIndex+1}`,44,y+16);
      ctx.fillStyle='#fff';ctx.font='bold 13px system-ui,sans-serif';ctx.fillText(chapter.name||'',44,y+34);
      ctx.fillStyle='rgba(255,255,255,0.48)';ctx.font='10px system-ui,sans-serif';ctx.fillText(`${cleared}/10 cleared · ${complete?'COMPLETE / クリア':'IN PROGRESS / ちょうせん中'}`,196,y+27);
      for(let round=0;round<10;round++){
        const level=levels[round],record=getRoundRecord(level),x=390+round*84;
        ctx.save();ctx.fillStyle=record.clears>0?'rgba(124,255,248,0.13)':'rgba(0,0,0,0.25)';ctx.strokeStyle=record.clears>0?(chapter.accent||'#7cfff8'):'rgba(255,255,255,0.12)';ctx.lineWidth=1;rr(ctx,x,y+7,76,38,7,true,true);ctx.restore();
        ctx.textAlign='center';ctx.fillStyle='rgba(255,255,255,0.55)';ctx.font='9px system-ui,sans-serif';ctx.fillText(`R${level.id}`,x+38,y+17);
        ctx.fillStyle=record.clears>0?'#fff':'rgba(255,255,255,0.28)';ctx.font='bold 11px system-ui,sans-serif';
        const shortScore=record.best>=1000?`${(record.best/1000).toFixed(1)}k`:String(record.best||'—');ctx.fillText(shortScore,x+38,y+31);
        ctx.fillStyle=record.medal? '#ffe66d':'rgba(255,255,255,0.24)';ctx.font='10px system-ui,sans-serif';
        ctx.fillText(fitText(medalText(record.medal),24),x+59,y+17);
        ctx.fillStyle=record.contractClears?'#7cfff8':'rgba(255,255,255,0.2)';ctx.font='bold 8px system-ui,sans-serif';ctx.fillText(record.contractClears?'C':'',x+12,y+44);
        ctx.fillStyle=record.ruleClears?'#ffe66d':'rgba(255,255,255,0.2)';ctx.fillText(record.ruleClears?'◆':'',x+26,y+44);
        ctx.textAlign='left';
      }
    }

    ctx.textAlign='left';ctx.fillStyle='#ffdf80';ctx.font='bold 14px system-ui,sans-serif';ctx.fillText('BOOHA COLLECTION / ブーハーコレクション',34,456);
    for(let index=0;index<ROSTER.length;index++){
      const col=index%5,row=Math.floor(index/5),x=34+col*247,y=468+row*76,booha=ROSTER[index],unlocked=isBoohaUnlocked(index);
      ctx.save();ctx.fillStyle=unlocked?'rgba(124,255,248,0.1)':'rgba(255,255,255,0.045)';ctx.strokeStyle=unlocked?'rgba(124,255,248,0.4)':'rgba(255,223,128,0.24)';ctx.lineWidth=1;rr(ctx,x,y,232,64,10,true,true);ctx.restore();
      if(unlocked&&(bst.thumbs[index]||bst.imgs[index]))ctx.drawImage(bst.thumbs[index]||bst.imgs[index],x+8,y+7,50,50);
      else {ctx.fillStyle='#ffdf80';ctx.font='bold 20px system-ui,sans-serif';ctx.textAlign='center';ctx.fillText('🔒',x+33,y+31);}
      ctx.textAlign='left';ctx.fillStyle=unlocked?'#fff':'rgba(255,255,255,0.5)';ctx.font='bold 11px system-ui,sans-serif';
      ctx.fillText(fitText(`${unlocked?'':'LOCKED · '}${booha.name}`,158),x+66,y+23);
      ctx.fillStyle=unlocked?'#7cfff8':'rgba(255,223,128,0.68)';ctx.font='10px system-ui,sans-serif';
      ctx.fillText(fitText(unlocked?booha.jpName:unlockRequirement(index),158),x+66,y+41);
    }

    drawControlDock();
    ctx.restore();
  }

  function drawBriefing(){
    const level = currentLevel();
    const chapter = currentChapter();
    ctx.save();
    ctx.fillStyle='rgba(7,5,18,0.82)';ctx.fillRect(0,0,W,H);
    ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillStyle=chapter.accent || '#ffdf80';ctx.font='bold 15px system-ui,sans-serif';
    ctx.fillText(`CHAPTER ${level.chapter || 1} · ${level.chapterName || 'CAMPAIGN'}`,W/2,H/2-145);
    ctx.fillStyle='#fff';ctx.font='bold 44px system-ui,sans-serif';
    ctx.fillText(level.boss ? `BOSS ROUND ${gs.roundN} · ボスラウンド` : `ROUND ${gs.roundN} · ラウンド`,W/2,H/2-96);
    ctx.fillStyle='rgba(255,255,255,0.82)';ctx.font='bold 21px system-ui,sans-serif';
    ctx.fillText(level.name || '',W/2,H/2-58);
    const panelX=W/2-300,panelY=H/2-46,panelW=600,panelH=140;
    ctx.save();ctx.fillStyle='rgba(255,255,255,0.08)';ctx.strokeStyle=level.boss ? (chapter.accent || '#ffdf80') : 'rgba(255,255,255,0.18)';ctx.lineWidth=1.5;
    rr(ctx,panelX,panelY,panelW,panelH,16,true,true);ctx.restore();
    ctx.fillStyle=level.boss ? '#ffdf80' : '#7cfff8';ctx.font='bold 13px system-ui,sans-serif';
    ctx.fillText(`✦ BONUS · ${level.contract?.label || 'CLEAR THE STACK'}`,W/2,panelY+18);
    const contractLines=bilingualParts(level.contract?.detail || 'Break every block.');
    ctx.fillStyle='rgba(255,255,255,0.86)';ctx.font='13px system-ui,sans-serif';
    ctx.fillText(fitText(contractLines.en,520),W/2,panelY+37);
    ctx.fillStyle='rgba(255,255,255,0.58)';ctx.font='11px system-ui,sans-serif';
    ctx.fillText(fitText(contractLines.jp || 'ブロックをぜんぶこわそう',520),W/2,panelY+51);
    const focusLines=bilingualParts(level.focus || 'Find the weak point.', level.focusJP || 'よわいところをみつけよう');
    ctx.fillStyle='rgba(255,255,255,0.78)';ctx.font='bold 12px system-ui,sans-serif';
    ctx.fillText(fitText(`AIM · ${focusLines.en}`,520),W/2,panelY+73);
    ctx.fillStyle='rgba(255,255,255,0.58)';ctx.font='11px system-ui,sans-serif';
    ctx.fillText(fitText(focusLines.jp || 'ねらいをさだめよう',520),W/2,panelY+87);
    ctx.fillStyle='#ffe66d';ctx.font='bold 10px system-ui,sans-serif';
    const challenge = level.rule ? `CHALLENGE · ${level.rule.label}` : `BEST · ${scoreText(gs.roundBestScore)}  ·  MEDAL · ${medalText(gs.roundMedal)}`;
    ctx.fillText(fitText(challenge, 520),W/2,panelY+108);
    const bx=ACTION_RECT.x,by=ACTION_RECT.y,bw=ACTION_RECT.w,bh=ACTION_RECT.h;
    const bg=ctx.createLinearGradient(bx,by,bx,by+bh);bg.addColorStop(0,level.boss?'#ffdf80':'#44ffcc');bg.addColorStop(1,level.boss?'#ff8c44':'#009977');
    ctx.shadowColor=level.boss?'#ffcf70':'#44ffcc';ctx.shadowBlur=18;ctx.fillStyle=bg;rr(ctx,bx,by,bw,bh,16,true,false);ctx.shadowBlur=0;
    ctx.fillStyle='#07121a';ctx.font='bold 18px system-ui,sans-serif';ctx.fillText('BEGIN / はじめる →',W/2,by+bh/2);
    ctx.restore();
  }

  function drawCard(){
    const win=gs.phase===P.WIN;
    const cardNow=performance.now();
    ctx.fillStyle=win?'rgba(0,18,0,0.62)':'rgba(28,0,0,0.62)';ctx.fillRect(0,0,W,H);
    ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';
    const panelX=W/2-470,panelY=H/2-220,panelW=940,panelH=410;
    ctx.fillStyle=win?'rgba(4,18,15,0.92)':'rgba(22,8,12,0.92)';
    ctx.strokeStyle=win?'rgba(255,221,68,0.72)':'rgba(255,120,110,0.58)';ctx.lineWidth=2;
    rr(ctx,panelX,panelY,panelW,panelH,24,true,true);

    // Chapter Clear gets a second, pulsing halo outside the panel border —
    // visibly a bigger moment than an ordinary round win, not just the same
    // chrome with an extra line of text.
    if (gs.cardChapter) {
      const hp=0.4+0.35*Math.sin(cardNow*0.0035);
      ctx.save();ctx.globalAlpha=hp;ctx.strokeStyle='#ffcf70';ctx.lineWidth=3;
      rr(ctx,panelX-7,panelY-7,panelW+14,panelH+14,28,false,true);
      ctx.restore();
    }

    // Defeat gets its own identity too, instead of being a duller copy of
    // the win panel — a couple of small crack lines at the top corners.
    if (!win) {
      ctx.save();ctx.strokeStyle='rgba(255,150,130,0.5)';ctx.lineWidth=1.5;
      ctx.beginPath();
      ctx.moveTo(panelX+26,panelY+2);ctx.lineTo(panelX+38,panelY+22);ctx.lineTo(panelX+30,panelY+30);ctx.lineTo(panelX+46,panelY+50);
      ctx.moveTo(panelX+panelW-26,panelY+2);ctx.lineTo(panelX+panelW-40,panelY+20);ctx.lineTo(panelX+panelW-30,panelY+28);ctx.lineTo(panelX+panelW-48,panelY+48);
      ctx.stroke();ctx.restore();
    }

    if(win){
      const pulse=0.55+0.45*Math.sin(performance.now()*0.004);
      ctx.save();ctx.globalAlpha=0.32+0.18*pulse;ctx.strokeStyle='#ffdf44';ctx.lineWidth=2;
      for(let i=0;i<10;i++){
        const a=i*Math.PI/5+performance.now()*0.00035;
        const r1=158,r2=186;
        ctx.beginPath();ctx.moveTo(W/2+Math.cos(a)*r1,H/2-126+Math.sin(a)*r1*0.38);ctx.lineTo(W/2+Math.cos(a)*r2,H/2-126+Math.sin(a)*r2*0.38);ctx.stroke();
      }
      ctx.restore();
      ctx.fillStyle='#ffdf44';ctx.font='bold 13px system-ui,sans-serif';
      ctx.fillText('✦ ROUND COMPLETE · ラウンドクリア ✦',W/2,panelY+30);
    } else {
      ctx.fillStyle='#ff9f7f';ctx.font='bold 13px system-ui,sans-serif';
      ctx.fillText('TRY AGAIN · もういちど',W/2,panelY+30);
    }
    const introP=1-clamp(gs.cardIntro/18,0,1);
    const titleScale=0.84+introP*0.16;
    ctx.save();ctx.globalAlpha=0.35+introP*0.65;ctx.translate(W/2,H/2-110);ctx.scale(titleScale,titleScale);
    ctx.font='bold 70px system-ui,sans-serif';ctx.fillStyle=gs.cardAccent;
    ctx.shadowColor=gs.cardAccent;ctx.shadowBlur=18;ctx.fillText(gs.cardTitle,0,0);ctx.restore();
    ctx.font='20px system-ui,sans-serif';ctx.fillStyle='rgba(255,255,255,0.75)';ctx.fillText(fitText(gs.cardSub, 860),W/2,H/2-54);
    ctx.font='14px system-ui,sans-serif';ctx.fillStyle='rgba(255,255,255,0.45)';
    ctx.fillText(`${Math.round(gs.pct)}% clear  ·  SCORE ${scoreText(gs.runScore)}  ·  BEST ${scoreText(gs.highScore)}`,W/2,H/2-20);
    if (gs.cardMeta) {
      ctx.font='13px system-ui,sans-serif';
      ctx.fillStyle=gs.cardMetaGood?'#7cfff8':'rgba(255,255,255,0.5)';
      ctx.fillText(fitText(gs.cardMeta, 820),W/2,H/2+8);
    }
    if (gs.cardUnlock) {
      // New-unlock spotlight — a soft violet glow behind the line, so a new
      // roster member reads as its own reveal rather than another gold line.
      ctx.save();
      const sg=ctx.createRadialGradient(W/2,H/2+36,4,W/2,H/2+36,150);
      sg.addColorStop(0,'rgba(216,140,255,0.28)');sg.addColorStop(1,'rgba(216,140,255,0)');
      ctx.fillStyle=sg;ctx.fillRect(W/2-150,H/2-14,300,100);
      ctx.restore();
      const unlockText=`✦ NEW BOOHA / あたらしいブーハー · ${gs.cardUnlock}`;
      ctx.font='bold 13px system-ui,sans-serif';
      ctx.fillStyle='#e8b8ff';
      ctx.fillText(fitText(unlockText, 820),W/2,H/2+36);
    } else if (win) {
      const next = nextRosterUnlock();
      if (next) {
        const nextText=`NEXT BOOHA / つぎのブーハー · ${next.booha.name} · ${next.requirement.unlockEN}`;
        ctx.font='12px system-ui,sans-serif';
        ctx.fillStyle='rgba(255,223,128,0.82)';
        ctx.fillText(fitText(nextText, 820),W/2,H/2+36);
      }
    }
    if (gs.cardChapter) {
      ctx.font='bold 13px system-ui,sans-serif';ctx.fillStyle='#ffcf70';
      ctx.fillText(fitText(`★ CHAPTER CLEAR / チャプタークリア · ${gs.cardChapter}`, 820),W/2,H/2+58);
    }
    if (gs.lastScoreIsBest && gs.runScore > 0) {
      ctx.font='bold 13px system-ui,sans-serif';ctx.fillStyle='#ffdf80';
      ctx.fillText(fitText('✦ NEW HIGH SCORE · ハイスコア更新 ✦', 820),W/2,H/2+62);
      // Fixed twinkling sparkles around the line — positions come from
      // detRand (same deterministic hash as the block textures), so they
      // only fade in and out, never jump around.
      ctx.save();
      for (let i=0;i<6;i++){
        const ang=detRand(i,7.3)*Math.PI*2;
        const rad=70+detRand(i,3.1)*60;
        const sx=W/2+Math.cos(ang)*rad, sy=H/2+62+Math.sin(ang)*rad*0.4;
        const tw=0.4+0.6*Math.abs(Math.sin(cardNow*0.003+i*1.7));
        ctx.globalAlpha=tw;ctx.fillStyle='#fff4c2';ctx.font=`${10+detRand(i,9)*6}px system-ui,sans-serif`;
        ctx.fillText('✦',sx,sy);
      }
      ctx.restore();
    }
    const bx=ACTION_RECT.x,by=ACTION_RECT.y,bw=ACTION_RECT.w,bh=ACTION_RECT.h;
    const bg=ctx.createLinearGradient(bx,by,bx,by+bh);
    bg.addColorStop(0,win?'#44ff88':'#ff9944');bg.addColorStop(1,win?'#009944':'#cc4400');
    ctx.shadowColor=win?'#44ff88':'#ff6600';ctx.shadowBlur=16;
    ctx.fillStyle=bg;rr(ctx,bx,by,bw,bh,16,true,false);ctx.shadowBlur=0;
    ctx.strokeStyle='rgba(255,255,255,0.3)';ctx.lineWidth=1.5;rr(ctx,bx,by,bw,bh,16,false,true);
    ctx.fillStyle='#fff';ctx.font='bold 24px system-ui,sans-serif';
    const actionLabel = win
      ? (gs.campaignComplete ? 'PLAY AGAIN / もういちど →' : 'NEXT / つぎへ →')
      : (gs.campaignActive ? 'RETRY / もういちど' : 'NEW RUN / あたらしいラン');
    ctx.fillText(actionLabel,W/2,by+bh/2);


    ctx.restore();
  }

  function drawExitConfirm(){
    if(!exitConfirmOpen)return;
    const m=EXIT_MODAL;
    ctx.save();
    ctx.fillStyle='rgba(0,0,0,0.64)';ctx.fillRect(0,0,W,H);
    ctx.fillStyle='rgba(8,10,18,0.97)';ctx.strokeStyle='rgba(255,159,127,0.82)';ctx.lineWidth=2;
    rr(ctx,m.x,m.y,m.w,m.h,18,true,true);
    ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillStyle='#ffb0a8';ctx.font='bold 22px system-ui,sans-serif';ctx.fillText('EXIT GAME?',W/2,m.y+43);
    ctx.fillStyle='rgba(255,255,255,0.92)';ctx.font='bold 15px system-ui,sans-serif';ctx.fillText('ゲームを終了しますか？',W/2,m.y+76);
    ctx.fillStyle='rgba(255,255,255,0.52)';ctx.font='11px system-ui,sans-serif';
    ctx.fillText(fitText('Your current run will be saved. / げんざいのランは ほぞんされます',m.w-70),W/2,m.y+99);
    const y=m.y+132;
    ctx.fillStyle='rgba(255,105,105,0.18)';ctx.strokeStyle='rgba(255,150,150,0.72)';ctx.lineWidth=1.5;rr(ctx,m.x+268,y,150,46,10,true,true);
    ctx.fillStyle='rgba(255,255,255,0.08)';ctx.strokeStyle='rgba(255,255,255,0.34)';rr(ctx,m.x+82,y,150,46,10,true,true);
    ctx.font='bold 13px system-ui,sans-serif';ctx.fillStyle='#fff';ctx.fillText('CANCEL / いいえ',m.x+157,y+23);
    ctx.fillStyle='#ffb0a8';ctx.fillText('EXIT / はい',m.x+343,y+23);
    ctx.restore();
  }

  function drawPause(){
    if(!pauseOpen)return;
    const m=PAUSE_MODAL;
    ctx.save();
    ctx.fillStyle='rgba(0,0,0,0.66)';ctx.fillRect(0,0,W,H);
    ctx.fillStyle='rgba(8,10,18,0.97)';ctx.strokeStyle='rgba(124,255,248,0.55)';ctx.lineWidth=2;
    rr(ctx,m.x,m.y,m.w,m.h,20,true,true);
    ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillStyle='#7cfff8';ctx.font='bold 26px system-ui,sans-serif';ctx.fillText('PAUSED',W/2,m.y+50);
    ctx.fillStyle='rgba(255,255,255,0.6)';ctx.font='13px system-ui,sans-serif';ctx.fillText('いちじていし',W/2,m.y+76);

    for (const b of pauseLayout()){
      const danger=b.danger, dim=b.disabled;
      ctx.save();
      if (dim) ctx.globalAlpha=0.42;
      ctx.fillStyle = b.accent ? 'rgba(124,255,248,0.16)' : danger ? 'rgba(255,105,105,0.14)' : 'rgba(255,255,255,0.06)';
      ctx.strokeStyle = b.accent ? 'rgba(124,255,248,0.75)' : danger ? 'rgba(255,150,150,0.55)' : 'rgba(255,255,255,0.24)';
      ctx.lineWidth=1.5;
      rr(ctx,b.x,b.y,b.w,b.h,12,true,true);
      ctx.fillStyle = b.accent ? '#7cfff8' : danger ? '#ffb0a8' : '#fff';
      ctx.font='bold 15px system-ui,sans-serif';
      ctx.fillText(b.en, W/2, b.y+b.h/2-10);
      ctx.fillStyle='rgba(255,255,255,0.5)';ctx.font='11px system-ui,sans-serif';
      ctx.fillText(b.jp, W/2, b.y+b.h/2+11);
      ctx.restore();
    }
    ctx.restore();
  }

  // ── Render ───────────────────────────────────────────
  function render(){
    const sx=shake.v>0.3?(rnd()-0.5)*shake.v*2:0,sy=shake.v>0.3?(rnd()-0.5)*shake.v*1.4:0;
    ctx.clearRect(0,0,W,VIEW_H);
    drawViewportBackdrop();
    ctx.save();
    ctx.translate(0,SCENE_Y);
    if(sx||sy)ctx.translate(sx,sy);
    drawBG();
    drawFXBehind();
    if(gs.phase!==P.TITLE&&gs.phase!==P.HALL){drawTraj();drawBlocks();drawGround();drawSling();drawBooha();drawMinis();}
    drawFXFront();drawConfetti();drawFlash();
    ctx.restore();

    ctx.save();
    ctx.translate(0,SCENE_Y);
    if(gs.phase===P.TITLE)drawTitle();
    else if(gs.phase===P.HALL)drawHall();
    else if(gs.phase===P.BRIEF){drawHUD();drawBriefing();}
    else if(gs.phase===P.WIN||gs.phase===P.FAIL){drawHUD();drawCard();}
    else drawHUD();
    drawToast();
    drawPause();
    drawExitConfirm();
    ctx.restore();
  }

  // ── Main loop ────────────────────────────────────────
  let lastT=0;
  let physicsCarry=0;
  function tick(now){
    const frameMs = lastT ? Math.min(now-lastT,50) : FIXED_STEP;
    lastT=now;
    const workStart = performance.now();

    if(gs.phase===P.PLAY && !pauseOpen){
      physicsCarry=Math.min(FIXED_STEP*4,physicsCarry+frameMs);
      let steps=0;
      while(physicsCarry>=FIXED_STEP&&steps<4){
        updateRuleTimer();
        if(gs.phase!==P.PLAY){physicsCarry=0;break;}
        updateFX();
        if(gs.hitStop>0) gs.hitStop--;
        else { updateBlocks(); updateBooha(); }
        physicsCarry-=FIXED_STEP;steps++;
        if(gs.phase!==P.PLAY){physicsCarry=0;break;}
      }
    } else if (gs.phase===P.PLAY && pauseOpen) {
      // Paused: freeze the sim entirely, including FX. Don't let carry build
      // up while paused either, or resuming dumps a stutter-step of queued
      // physics in one frame.
      physicsCarry=0;
    } else if (gs.phase===P.WIN || gs.phase===P.FAIL) {
      physicsCarry=0;
      updateFX();
    } else if (gs.phase===P.TITLE) {
      // The title screen gets its own light ambient motion — rising embers,
      // out of the same spark pool the game already uses — so it keeps
      // animating every frame like PLAY/WIN/FAIL do below.
      physicsCarry=0;
      gs.titleEmberTimer = (gs.titleEmberTimer||0) + 1;
      if (gs.titleEmberTimer % 24 === 0) spawnEmber(rnd(W*0.12,W*0.88), H+8);
      updateFX();
    } else {
      physicsCarry=0;
      // Menus and briefings are static. Only keep the loop alive while a
      // toast is fading; otherwise they cost a full canvas render every frame.
      if (gs.toast && performance.now() < gs.toastUntil) updateFX();
    }
    const updateMs = performance.now() - workStart;
    const animated = gs.phase===P.PLAY || gs.phase===P.WIN || gs.phase===P.FAIL || gs.phase===P.TITLE;
    const renderKey = `${gs.phase}:${gs.roundN}:${gs.cardTitle}`;
    const toastVisible = !!(gs.toast && performance.now() < gs.toastUntil);
    const shouldRender = animated || needsRender || staticRenderKey !== renderKey ||
      toastVisible || toastWasVisible;
    let renderMs = 0;
    if (shouldRender) {
      const renderStart = performance.now();
      render();
      renderMs = performance.now() - renderStart;
      needsRender = false;
      staticRenderKey = renderKey;
    }
    toastWasVisible = toastVisible;
    PERF.frames++;
    PERF.maxFrameMs=Math.max(PERF.maxFrameMs,frameMs);
    adaptPerformance(frameMs, updateMs, renderMs);
    requestAnimationFrame(tick);
  }

  // ── Resize ───────────────────────────────────────────
  function resize(){
    const vw=window.innerWidth,vh=window.innerHeight;
    const viewportRatio=vw/Math.max(1,vh);
    viewportBackdropCache=null;
    viewportBackdropHeight=0;
    hudMeterGradient=null;
    hudMeterGradientWidth=0;
    goalGradient=null;
    goalGradientWidth=0;
    needsRender=true;
    FULL_BLEED=viewportRatio < W/H;
    if(FULL_BLEED){
      VIEW_H=Math.max(H,Math.round(W/viewportRatio));
      SCENE_Y=Math.round((VIEW_H-H)/2);
      canvas.width=W;canvas.height=VIEW_H;
      canvas.style.width=vw+'px';canvas.style.height=vh+'px';
      canvas.style.left='0px';canvas.style.top='0px';
      gs.scale=vw/W;
    } else {
      const scale=Math.min(vw/W,vh/H);
      VIEW_H=H;SCENE_Y=0;
      canvas.width=W;canvas.height=H;
      canvas.style.width=W*scale+'px';canvas.style.height=H*scale+'px';
      canvas.style.left=((vw-W*scale)/2)+'px';canvas.style.top=((vh-H*scale)/2)+'px';
      gs.scale=scale;
    }
  }

  // ── Help modal ───────────────────────────────────────
  let helpOpen = false;
  let helpIdx  = 0;
  let helpEl   = null;

  function buildHelpModal() {
    if (helpEl) return;
    helpEl = document.createElement('div');
    helpEl.id = 'booha-help';
    Object.assign(helpEl.style, {
      position:'fixed', inset:'0', background:'rgba(8,5,20,0.88)',
      display:'none', alignItems:'center', justifyContent:'center',
      zIndex:'8888', fontFamily:'system-ui,sans-serif',
    });
    helpEl.innerHTML = `
      <div id="bh-panel" style="
        background:linear-gradient(160deg,#1a1230,#0d0820);
        border:1px solid rgba(255,255,255,0.14);
        border-radius:20px;padding:32px 28px;width:340px;max-width:90vw;
        box-shadow:0 0 60px rgba(0,0,0,0.7);position:relative;text-align:center;
      ">
        <button id="bh-close" style="
          position:absolute;top:12px;right:14px;background:none;border:none;
          color:rgba(255,255,255,0.5);font-size:22px;cursor:pointer;line-height:1;
        ">✕</button>
        <div style="font-size:11px;letter-spacing:3px;color:rgba(255,255,255,0.35);margin-bottom:18px;text-transform:uppercase">Booha Guide</div>
        <img id="bh-img" src="" style="width:90px;height:90px;object-fit:contain;margin-bottom:12px;" />
        <div id="bh-name" style="font-size:26px;font-weight:800;color:#fff;line-height:1.1;margin-bottom:2px;"></div>
        <div id="bh-jp-name" style="font-size:13px;color:rgba(255,255,255,0.68);margin-bottom:8px;letter-spacing:0.5px;"></div>
        <div id="bh-power" style="font-size:12px;letter-spacing:2px;color:#aaa;text-transform:uppercase;margin-bottom:14px;"></div>
        <div id="bh-desc" style="font-size:14px;color:rgba(255,255,255,0.75);margin-bottom:10px;line-height:1.5;"></div>
        <div id="bh-tip" style="
          font-size:12px;color:#ffdd88;background:rgba(255,200,0,0.08);
          border:1px solid rgba(255,200,0,0.2);border-radius:8px;
          padding:8px 12px;margin-bottom:22px;line-height:1.5;
        "></div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <button id="bh-prev" style="
            background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);
            color:#fff;font-size:20px;border-radius:10px;width:44px;height:44px;
            cursor:pointer;display:flex;align-items:center;justify-content:center;
          ">‹</button>
          <div id="bh-dots" style="display:flex;gap:6px;"></div>
          <button id="bh-next" style="
            background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);
            color:#fff;font-size:20px;border-radius:10px;width:44px;height:44px;
            cursor:pointer;display:flex;align-items:center;justify-content:center;
          ">›</button>
        </div>
      </div>
    `;
    document.body.appendChild(helpEl);
    document.getElementById('bh-close').onclick = closeHelp;
    document.getElementById('bh-prev').onclick  = () => { helpIdx=(helpIdx-1+ROSTER.length)%ROSTER.length; refreshHelp(); };
    document.getElementById('bh-next').onclick  = () => { helpIdx=(helpIdx+1)%ROSTER.length; refreshHelp(); };
    helpEl.addEventListener('click', e => { if(e.target===helpEl) closeHelp(); });
    document.addEventListener('keydown', onHelpKey);
  }
  function onHelpKey(e) {
    if (!helpOpen) return;
    if (e.key==='ArrowLeft')  { helpIdx=(helpIdx-1+ROSTER.length)%ROSTER.length; refreshHelp(); }
    if (e.key==='ArrowRight') { helpIdx=(helpIdx+1)%ROSTER.length; refreshHelp(); }
    if (e.key==='Escape')     closeHelp();
  }
  function refreshHelp() {
    const r = ROSTER[helpIdx];
    const imgEl    = document.getElementById('bh-img');
    const nameEl   = document.getElementById('bh-name');
    const jpNameEl = document.getElementById('bh-jp-name');
    const powerEl  = document.getElementById('bh-power');
    const descEl   = document.getElementById('bh-desc');
    const tipEl    = document.getElementById('bh-tip');
    const dotsEl   = document.getElementById('bh-dots');
    if (r.img) { imgEl.src = r.img; imgEl.style.display = ''; }
    else        { imgEl.style.display = 'none'; }
    nameEl.textContent   = r.name;
    if (jpNameEl) jpNameEl.textContent = r.jpName || '';
    powerEl.textContent  = r.power.toUpperCase();
    descEl.innerHTML     = r.desc + '<br><span style="font-size:12px;opacity:0.7;">' + (r.jp || '') + '</span>';
    tipEl.textContent    = '\u{1F4A1} ' + (r.tip || '');
    dotsEl.innerHTML = '';
    ROSTER.forEach((_, i) => {
      const dot = document.createElement('div');
      Object.assign(dot.style, {
        width:'6px', height:'6px', borderRadius:'50%',
        background: i === helpIdx ? '#fff' : 'rgba(255,255,255,0.25)',
        cursor:'pointer', transition:'background 0.15s',
      });
      dot.onclick = () => { helpIdx = i; refreshHelp(); };
      dotsEl.appendChild(dot);
    });
  }
  function openHelp() {
    buildHelpModal();
    helpIdx = bst.sel;
    refreshHelp();
    helpEl.style.display = 'flex';
    helpOpen = true;
  }
  function closeHelp() {
    if (helpEl) helpEl.style.display = 'none';
    helpOpen = false;
  }

  // ── Boot ─────────────────────────────────────────────
  async function boot(){
    resize();
    readMutePreference();
    loadRoundRecords();
    loadRosterUnlocks();
    syncRosterUnlocks();
    gs.highScore=readHighScore();
    window.addEventListener('resize',resize);
    canvas.addEventListener('mousedown',  onDown);
    window.addEventListener('mousemove',  onMove);
    window.addEventListener('mouseup',    onUp);
    canvas.addEventListener('touchstart', onDown, {passive:false});
    window.addEventListener('touchmove',  onMove, {passive:false});
    window.addEventListener('touchend',   onUp,   {passive:false});
    await preload();
    loadRound(0);
    gs.phase=P.TITLE;
    requestAnimationFrame(tick);
  }

  boot();
})();
